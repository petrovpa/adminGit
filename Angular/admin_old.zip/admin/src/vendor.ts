// Импорт сторонних библиотек, например jQuery, Lodash
// Также можно импротировать js, ts, css, sass, ...

import 'pikaday';
import 'lodash';
