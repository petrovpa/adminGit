http://fontello.com
Settings -> import config.json