import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { SelectTreeComponent } from './select-tree.component';
import { TreeModule } from 'angular-tree-component';
import { FormControlModule } from '@app/components/form-control/src/form-control.module';
import { DropdownModule } from '@frontend/dropdown';

@NgModule({
  imports: [
    FormsModule,
    CommonModule,
    TreeModule,
    FormControlModule,
    DropdownModule.forRoot()
  ],
  declarations: [SelectTreeComponent],
  exports: [SelectTreeComponent]
})
export class SelectTreeModule { }
