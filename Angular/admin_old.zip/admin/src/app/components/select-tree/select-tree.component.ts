import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { AngularTree } from '@app/classes/angular-tree.class';
import * as _ from 'lodash';
import { Observable } from 'rxjs/Observable';
import { Subscription, BehaviorSubject } from 'rxjs';

@Component({
  selector: 'select-tree',
  templateUrl: './select-tree.component.html',
  styleUrls: ['./select-tree.component.scss']
})
export class SelectTreeComponent implements OnInit, OnDestroy {

  @Input() name: string;
  @Input() placeholder: string;
  @Input() required: boolean;
  @Input() options: any;
  @Input() selectedValue: BehaviorSubject<any>;
  @Input() nodes: AngularTree[];

  private sub: Subscription;

  status: { isOpen: boolean } = { isOpen: false };

  // открыт ли список
  private isOpen: boolean = false;

  private _value: any = { name: '' };
  public get value(): any {
    return this._value;
  }
  public set value(value: any) {
    this._value = value;
  }

  constructor() { }

  ngOnInit() {
    this.sub = this.selectedValue
      .subscribe((val: any) => this.value = val);
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

  /**
   * Обработчик события выбора элемента дерева
   * @param data {AngularTree} - выбранный элемент дерева
   */
  private onActivate(data: AngularTree) {
    if (data) {
      this.value = data;
      const onActivate = this.options && this.options.onActivate;
      if (_.isFunction(onActivate))
        onActivate(data);

      this.onOpenChange(false);
    }
  }

  private onClick($event: MouseEvent) {
    $event.preventDefault();
    $event.stopPropagation();
  }

  /**
   * Расскрытие списка
   */
  private toggleDropdown($event: MouseEvent) {
    $event.preventDefault();
    $event.stopPropagation();
    this.status.isOpen = !this.status.isOpen;
  }

  /**
   * Событие на раскрытие списка
   */
  private onOpenChange(value: boolean) {
    this.isOpen = value;
    this.status.isOpen = value;
  }

}
