export { JournalModule } from './journal.module';
export { JournalComponent } from './journal/journal.component';
