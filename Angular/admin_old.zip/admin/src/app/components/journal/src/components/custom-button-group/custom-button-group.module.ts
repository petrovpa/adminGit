import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomButtonGroupComponent } from './custom-button-group.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [CustomButtonGroupComponent],
  exports: [CustomButtonGroupComponent]
})
export class CustomButtonGroupModule { }
