import { Component, Input, OnInit, Output, EventEmitter, ViewEncapsulation } from '@angular/core';
import { NgForm } from '@angular/forms';
import * as _ from 'lodash';

import { Utils } from '@frontend/utils';

// local import
import { JournalService } from '../services/journal.service';

@Component({
  selector: 'journal-filter',
  templateUrl: './journal-filter.component.html',
  styleUrls: ['./journal-filter.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class JournalFilterComponent implements OnInit {

  /**
   * Параметры фильтра
   */
  @Input() params: any = {};

  /**
   * Скрывать ли фильтр
   */
  @Input() hideFilter: boolean = false;

  /**
   * Имя журнала и версия
   *
   * @type {string}
   */
  @Input() filterParamsId: string;

  /**
   * Значения фильтров
   */
  @Input() filterMap;

  /**
   * При выполнении поиска
   *
   */
  @Output() onDoFilter = new EventEmitter<any>();


  /**
   * Форма валидации
   * @type {boolean}
   */
  wasValidated: boolean = false;

  constructor(private journalService: JournalService) {
  }

  ngOnInit() {
  }

  /**
   * Не отправлять форму по Enter
   */
  enterFrom($event) {
    $event.preventDefault();
    return false;
  }

  /**
   * Фильтрация
   * @param $event
   * @param f
   */
  doFilter($event, f: NgForm) {
    this.wasValidated = true;

    if (f.valid) {

      //Сохранение фильтров
      const userParams = {
        journal: {}
      };

      userParams.journal[this.filterParamsId] = JSON.stringify(this.filterMap);
      this.journalService.saveUserParams(userParams).subscribe();

      let filterMapQuery = {};
      this.journalService.convertFilterMap(filterMapQuery, this.filterMap);

      this.onDoFilter.emit(filterMapQuery);
    }
  }

  /**
   * Очистка фильтра
   */
  clearFilter() {
    this.wasValidated = false;

    if (this.filterMap != null) {
      // очистка фильтра
      _.forEach(this.filterMap, (tableParams) => {
        _.forEach(tableParams, (fieldParam) => {
          Utils.deleteFromMap(fieldParam, ['value', 'valueStart', 'valueFinish']);
          if (fieldParam.isRequired) {
            fieldParam.isEnable = true;
          } else {
            fieldParam.isEnable = false;
          }
        });
      });

      const userParams = {
        journal: {}
      };

      userParams.journal[this.filterParamsId] = JSON.stringify(this.filterMap);

      this.journalService.delUserParams(userParams).subscribe();
    }
  }
}

