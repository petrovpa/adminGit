import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'custom-button-group',
  templateUrl: './custom-button-group.component.html',
  styleUrls: ['./custom-button-group.component.scss']
})
export class CustomButtonGroupComponent implements OnInit {

  @Input() buttons: any[];
  @Input() selected: any[];

  @Output() buttonClicked = new EventEmitter();

  public disabled(btn: any): boolean {
    const customDisabledFn = btn.disabled;
    const isCustomDisabled = (customDisabledFn && typeof customDisabledFn === 'function') ? customDisabledFn(this.selected) : false;
    return isCustomDisabled || (this.selected.length === 0 && btn.selectedRequired);
  }

  click(btn, selected){
    if (btn && selected) {
      btn.onClick(selected);
      this.buttonClicked.emit();
      this.selected.splice(0, this.selected.length);
    }
  }

  constructor() { }

  ngOnInit() {
  }

}
