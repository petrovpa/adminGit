import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-filter-handbook',
  templateUrl: './filter-handbook.component.html',
  styleUrls: ['./filter-handbook.component.scss']
})
export class FilterHandbookComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
