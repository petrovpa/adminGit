import { Component, Input, OnInit } from '@angular/core';
import {DATE_TYPE_LIST} from "../classes/filter-type-list";

@Component({
  selector: 'filter-date',
  templateUrl: './filter-date.component.html',
  styleUrls: ['./filter-date.component.scss']
})
export class FilterDateComponent implements OnInit {
  /**
   * Уникальное имя
   */
  @Input() name = {};
  /**
   * Параметр
   */
  @Input() namespace;

  /**
   * Заголовк чекбокса фильтра
   */
  @Input() title = {};

  /**
   * Текущая дата
   *
   */
  protected nowDate = new Date();
  private items: any;

  constructor() {
  }

  ngOnInit() {
    this.items = DATE_TYPE_LIST;
  }

  isDisabledBySelect(item: any){
    if (item && (item === 1)) {
      if (this.namespace && (this.namespace.type === 'isNull' || this.namespace.type === 'notIsNull')) {
        return true;
      }
    }
    if (item && (item === 2)){
      if (this.namespace && (this.namespace.type !== 'between') || (this.namespace.type === 'isNull' || this.namespace.type === 'notIsNull')){
        return true;
      }
    }
    return false;
  }

}
