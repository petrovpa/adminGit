export const STRING_TYPE_LIST = [
  {
    name: 'Содержит',
    sysname: 'like',
  },
  {
    name: 'Начинается с',
    sysname: 'beginLike'
  },
  {
    name: 'Заканчивается на',
    sysname: 'endLike'
  },
  {
    name: 'Равно',
    sysname: 'equal'
  },
  {
    name: 'Не равно',
    sysname: 'notEqual'
  },
  {
    name: 'Пусто',
    sysname: 'isNull',
    isInputDisabled: true
  },
  {
    name: 'Не пусто',
    sysname: 'notIsNull',
    isInputDisabled: true
  }
];

export const DATE_TYPE_LIST = [
  {
    name: 'Между',
    sysname: 'between'
  },
  {
    name: 'Равно',
    sysname: 'equal'
  },
  {
    name: 'Не равно',
    sysname: 'notEqual'
  },
  {
    name: 'Больше',
    sysname: 'more'
  },
  {
    name: 'Больше или равно',
    sysname: 'moreEqual'
  },
  {
    name: 'Меньше',
    sysname: 'less'
  },
  {
    name: 'Меньше или равно',
    sysname: 'lessEqual'
  },
  {
    name: 'Пусто',
    sysname: 'isNull'
  },
  {
    name: 'Не пусто',
    sysname: 'notIsNull'
  }
];
