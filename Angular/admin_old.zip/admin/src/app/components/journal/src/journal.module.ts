import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { DatatableModule } from '@frontend/datatable';
import { FormControlModule } from '@app/components/form-control/src/form-control.module';
import { TransformPipeModule } from '@frontend/transform-pipe';
import { FormDirectiveModule } from '@frontend/form-directive';

// local import
import { JournalComponent } from './journal/journal.component';
import { JournalService } from './services/journal.service';
import { JournalFilterComponent } from './journal-filter/journal-filter.component';
import { FilterDateComponent } from './filter-date/filter-date.component';
import { FilterTextComponent } from './filter-text/filter-text.component';
import { FilterHandbookComponent } from './filter-handbook/filter-handbook.component';
import { CustomButtonGroupModule } from './components/custom-button-group/custom-button-group.module';

@NgModule({
  imports: [
    CommonModule,
    DatatableModule,
    FormControlModule,
    TransformPipeModule,
    FormDirectiveModule,
    FormsModule,
    CustomButtonGroupModule
  ],
  declarations: [
    JournalComponent,
    JournalFilterComponent,
    FilterDateComponent,
    FilterTextComponent,
    FilterHandbookComponent
  ],
  providers: [
    JournalService
  ],
  exports: [
    JournalComponent
  ]
})
export class JournalModule {
}
