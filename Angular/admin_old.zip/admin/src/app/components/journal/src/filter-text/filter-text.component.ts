import { Component, OnInit, Input } from '@angular/core';
import { STRING_TYPE_LIST } from "../classes/filter-type-list";

@Component({
  selector: 'filter-text',
  templateUrl: './filter-text.component.html',
  styleUrls: ['./filter-text.component.scss']
})
export class FilterTextComponent implements OnInit {

  /**
   * Уникальное имя
   */
  @Input() name: string = new Date().getMilliseconds().toString();

  /**
   * Параметр
   */
  @Input() namespace;

  /**
   * Заголовк чекбокса фильтра
   */
  @Input() title = {};

  private items: any;

  constructor() {
  }

  ngOnInit() {
    this.items = STRING_TYPE_LIST;
  }

  isDisabledBySelect() {
    if (this.namespace && (this.namespace.type === 'isNull' || this.namespace.type === 'notIsNull')) {
      return true;
    }
    return false;
  }
}
