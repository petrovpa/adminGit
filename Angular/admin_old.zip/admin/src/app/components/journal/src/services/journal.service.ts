import { Injectable } from '@angular/core';
import { Logger } from '@frontend/logger';
import * as _ from 'lodash';

import { Utils } from '@frontend/utils';
import { RestService } from '@app/services/common/src';

@Injectable()
export class JournalService {

  /**
   * Тип фильтра
   *
   * @protected
   */
  protected filterExpType = {
    EQUAL_TO: 3,
    NOT_EQUAL_TO: 4,
    IS_NULL: 33,
    IS_NOT_NULL: 44,
    LESS_THAN: 5,
    GREATER_THAN: 6,
    LESS_THAN_EQUAL_TO: 7,
    GREATER_THAN_EQUAL_TO: 8,
    BETWEEN: 9,
    IN: 10,
    LIKE: 11,
    LIKE_IGNORE_CASE: 12,
    NOT_BETWEEN: 35,
    NOT_IN: 36,
    NOT_LIKE: 37,
    NOT_LIKE_IGNORE_CASE: 38
  };

  /**
   * Тип фильтра
   *
   * @protected
   */
  protected filterTypeMap = {
    between: {
      filterExpType: this.filterExpType.BETWEEN,
      paramPref: '',
      paramPost: '',
      valueName: 'value'
    },
    equal: {
      filterExpType: this.filterExpType.EQUAL_TO,
      paramPref: '',
      paramPost: '',
      valueName: 'value'
    },
    notEqual: {
      filterExpType: this.filterExpType.NOT_EQUAL_TO,
      paramPref: '',
      paramPost: '',
      valueName: 'value'
    },
    more: {
      filterExpType: this.filterExpType.GREATER_THAN,
      paramPref: '',
      paramPost: '',
      valueName: 'value'
    },
    moreEqual: {
      filterExpType: this.filterExpType.GREATER_THAN_EQUAL_TO,
      paramPref: '',
      paramPost: '',
      valueName: 'value'
    },
    less: {
      filterExpType: this.filterExpType.LESS_THAN,
      paramPref: '',
      paramPost: '',
      valueName: 'value'
    },
    lessEqual: {
      filterExpType: this.filterExpType.LESS_THAN_EQUAL_TO,
      paramPref: '',
      paramPost: '',
      valueName: 'value'
    },
    isNull: {
      filterExpType: this.filterExpType.IS_NULL,
      paramPref: '',
      paramPost: '',
      valueName: 'value'
    },
    notIsNull: {
      filterExpType: this.filterExpType.IS_NOT_NULL,
      paramPref: '',
      paramPost: '',
      valueName: 'value'
    },
    in: {
      filterExpType: this.filterExpType.IN,
      paramPref: '(',
      paramPost: ')',
      valueName: 'value'
    },
    like: {
      filterExpType: this.filterExpType.LIKE_IGNORE_CASE,
      paramPref: "'%",
      paramPost: "%'",
      valueName: 'value'
    },
    beginLike: {
      filterExpType: this.filterExpType.LIKE_IGNORE_CASE,
      paramPref: "'",
      paramPost: "%'",
      valueName: 'value'
    },
    endLike: {
      filterExpType: this.filterExpType.LIKE_IGNORE_CASE,
      paramPref: "'%",
      paramPost: "'",
      valueName: 'value'
    },
    notBetween: {
      filterExpType: this.filterExpType.NOT_BETWEEN,
      paramPref: '',
      paramPost: '',
      valueName: 'value'
    },
    notIn: {
      filterExpType: this.filterExpType.NOT_IN,
      paramPref: '(',
      paramPost: ')',
      valueName: 'value'
    },
    notlike: {
      filterExpType: this.filterExpType.NOT_LIKE_IGNORE_CASE,
      paramPref: "'%",
      paramPost: "%'",
      valueName: 'value'
    }
  };

  constructor(private logger: Logger,
    private restService: RestService) {
  }

  /**
   * Загрузка сохраненного фильтра пользователя
   *
   * @param {string} filterParamsId
   * @param params
   * @returns {any}
   */
  getUserParams(filterParamsId: string, params) {
    return this.restService.b2bCall('journal/dsB2B_GetUserParams', {
      'ENTITYKEY': filterParamsId,
      'ENTITYTYPE': 'journal'
    }).map((res) => {
      let filterMap = this.prepareUserParams(res, filterParamsId, params);

      if (!filterMap) {
        filterMap = this.initFilterStruct(params);
      }

      return filterMap;
    });
  }

  /**
   * Получение значений фильтров
   *
   * @param res
   * @param filterParamsId
   * @return any
   */
  private prepareUserParams(res, filterParamsId, params) {
    if (res && res.journal) {
      let filterMap = {};
      if (res.journal[filterParamsId]) {

        filterMap = JSON.parse(res.journal[filterParamsId]);

        _.forEach(params, (param) => {
          if (filterMap[param.TABLEALIAS][param.NAMESPACE] && param.ISREQUIRED) {
            filterMap[param.TABLEALIAS][param.NAMESPACE].isRequired = true;
          }
        });

        _.forEach(filterMap, (tableParams) => {
          _.forEach(tableParams, (fieldParam, key) => {
            if ((fieldParam.isRequired) && (fieldParam.isRequired === true)) {
              fieldParam.isEnable = true;
              if ((!fieldParam.isEnable) || (fieldParam.isEnable === false)) {

                Utils.deleteFromMap(fieldParam, ['value', 'valueStart', 'valueFinish']);
              }
            }
          });
        });
      }
      return filterMap;
    }
  }

  /**
   * Иницилизация фильтров
   *
   */
  private initFilterStruct(params) {
    let filterMap = {};
    _.forEach(params, (param) => {
      filterMap[param.TABLEALIAS] = filterMap[param.TABLEALIAS] || {};
      filterMap[param.TABLEALIAS][param.NAMESPACE] = {};
      this.setDefValues(filterMap[param.TABLEALIAS][param.NAMESPACE], param);
      // console.log('param ', filterMap);
    });
    console.log('params ', params);
    console.log('filterMap ', filterMap);
    return filterMap;
  }

  /**
   * Установка параметров фильтров по умолчанию
   *
   * @param {any} namespace
   * @param {any} param
   */
  private setDefValues(namespace, param) {
    if (namespace && param) {
      if (param.ISREQUIRED) {
        namespace.isEnable = true;
      } else {
        if (namespace.isEnable) {
          namespace.isEnable = false;
        }
      }

      namespace.tableAlias = param.TABLEALIAS;
      namespace.TYPESYSNAME = param.TYPESYSNAME;

      if (param.TYPESYSNAME === 'date') {
        namespace.valueFinish = '';
        namespace.valueStart = '';
        namespace.type = 'between';
      }

      if (param.TYPESYSNAME === 'string') {
        namespace.value = '';
        namespace.type = 'beginLike';
      }
    }
  }

  /**
   * Установка дополнительных параметров фильтров
  */
  convertFilterMap(filterParams, filterMap) {
    let queryFilterMap = filterMap;
    _.forEach(queryFilterMap, (tableFilter, tableName) => {
      _.forEach(tableFilter, (curFilterMap, fieldName) => {
        this.setFilterParamEx(filterParams, tableName, fieldName, curFilterMap);
      });
    });
  }

  /**
   * Установка дополнительных параметров фильтров
   *
   * @param {any} outParams
   * @param {any} tableName
   * @param {any} outName
   * @param {any} param
   */
  private setFilterParamEx(outParams, tableName, outName, param) {
    if (param && param.isEnable) {
      if (!outParams[tableName]) {
        outParams[tableName] = {};
      }
      let currentTableFilter = outParams[param.tableAlias],
        valueStr = param['valueStart'],
        valueStart = param['valueStart'],
        valueFinish = param['valueFinish'];

      // формирование параметров ограничений по типам
      if (param.TYPESYSNAME === 'date') {
        if (param.type === 'between') {
          valueStr = valueStart + ' AND ' + valueFinish;
        }
        param.value = valueStr;
      }
      this.formTypeFilterParamStructEx(param, currentTableFilter, outName);
    }
  }

  /**
   * Установка дополнительных параметров фильтров
   *
   * @param {any} param
   * @param {any} tableFilter
   * @param {any} outName
   */
  private formTypeFilterParamStructEx(param, tableFilter, outName) {
    const typeExpName = param.type;
    const filterType = this.filterTypeMap[typeExpName];
    const valueName = filterType.valueName;
    const value = filterType.paramPref + param[valueName] + filterType.paramPost;
    const expNum = filterType.filterExpType;
    this.formFilterParamStruct(tableFilter, expNum, outName, value);
  }

  /**
   * Установка дополнительных параметров фильтров
   *
   * @param {any} tableFilter
   * @param {any} expNum
   * @param {any} outName
   * @param {any} value
   */
  private formFilterParamStruct(tableFilter = {}, expNum, outName, value) {
    if (!tableFilter[expNum]) {
      tableFilter[expNum] = {};
    }
    tableFilter[expNum][outName] = value;
  }

  /**
   * Сохраненный фильтр пользователя
   * @param userParams
   * @returns {any}
   */
  saveUserParams(userParams) {
    return this.restService.b2bCall('journal/dsB2B_SetUserParams', {
      'USERPARAM': userParams
    });
  }

  /**
   * Удаление фильтра пользователя
   * @param userParams
   * @returns {any}
   */
  delUserParams(userParams) {
    return this.restService.b2bCall('journal/dsB2B_DeleteUserParams', {
      'USERPARAM': userParams
    });
  }

  /**
   * Загрузка параметров и инициализация директивы журнала
   *
   * @param {string} journalSysname
   */
  getJournal(journalSysname: string) {
    return this.restService.b2bCall('journal/dsB2B_JournalCustomBrowseListByParam', {
      'SYSNAME': journalSysname
    });
  }

  /**
   * Данные журнала
   * @param params
   */
  getDataJournal(params) {
    return this.restService.b2bCall('journal/dsB2B_JournalDataBrowseListByParamWrapper', params);
  }
}
