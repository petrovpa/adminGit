import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { Logger } from '@frontend/logger';
import * as _ from 'lodash';

// local import
import { JournalService } from '../services/journal.service';
import { Page } from '../classes/page';

export const VERSION = '1.1';

@Component({
  selector: 'journal',
  templateUrl: './journal.component.html',
  styleUrls: ['./journal.component.scss']
})
export class JournalComponent implements OnInit {
  @ViewChild('journalTable') table: any;

  /**
   * Имя журнала
   */
  get sysname(): string {
    return this._sysname;
  }

  @Input() set sysname(value: string) {
    this._sysname = value;
    this.filterParamsId = value + '-' + VERSION;
  }

  /**
   * Подробная информация
   */
  @Input() isExpand: boolean = false;

  /**
   * Сортировка по-умолчанию
   */
  @Input() defaultSort = [];

  /**
   * Кнопки журнала по-умолчанию
   * TODO: реализовать класс для OnClick действий
   */
  @Input() defaultJournalButtonsOnClick: any = {};

  private defaultButtonDisabled = (selected: any) => {
    return !(selected && selected.length !== 0);
  }
  // TODO: доделать
  // private btn
  // private addButton = { title: 'Добавить', class: 'table-button__add', iClass: 'b2b-icon-add', sysname: 'add', disabled: () => { } };
  // private removeButton = { title: 'Удалить', class: 'table-button__delete', iClass: 'b2b-icon-delete', sysname: 'remove', disabled: this.defaultButtonDisabled };

  /**
   * Кнопки журнала по-умолчанию. Здесь sysname = имени функции, которая должна вешаться на кнопку
   * из defaultJournalButtonsOnClick
   */
  @Input() defaultJournalButtons: any[] = [
    { title: 'Добавить', class: 'table-button__add', iClass: 'b2b-icon-add', sysname: 'add', disabled: () => { } }
  ];

  /**
   * Дополнительные кнопки журнала
   */
  @Input() customJournalButtons = [];

  private journalButtons = [...this.defaultJournalButtons, ...this.customJournalButtons];

  /**
   * События
   * @type {EventEmitter<any>}
   */
  @Output() onSelected = new EventEmitter();
  @Output() onDoubleClicked = new EventEmitter();

  private _sysname: string;
  private filterParamsId: string;

  /**
   * Параметры журнала
   */
  protected journalSettings;

  /**
   * Фильтр
   */
  protected filterMap = {};

  /**
   * Фильтр для запроса
   */
  protected filterMapQuery = {};

  /**
   * Выбранный элемент
   */
  protected selected = null;
  protected expanded: any = {};

  /**
   * Для таблицы
   */
  protected page = new Page();
  protected columns = [];
  protected rows = [];

  /**
   * Индикатор загрузки
   * @type {boolean}
   */
  public isLoading: boolean = true;
  protected isLoadingData: boolean = false;

  constructor(private logger: Logger,
    private journalService: JournalService) {
    // установка начальных данных для пагинации
    this.page.pageNumber = 0;
    this.page.size = 20;

    // TODO: доделать
    // this.defaultJournalButtons.forEach(btn => {

    // });
  }

  initDefaultJournalButtons() {
    if (this.defaultJournalButtons) {
      this.defaultJournalButtons.forEach((button: any) => {
        const sysname = button && button.sysname;
        if (this.defaultJournalButtonsOnClick) {
          button.onClick = this.defaultJournalButtonsOnClick[sysname];
        }
      });
    }
    this.journalButtons = [...this.defaultJournalButtons, ...this.customJournalButtons];
  }

  ngOnInit() {
    this.initDefaultJournalButtons();
    this.loadJournal();
  }

  /**
   * Загрузка журнала
   */
  private loadJournal() {
    this.journalService.getJournal(this.sysname).subscribe((res) => {
      this.logger.log('loadJournal', res);
      this.journalSettings = res;

      // формируем колонки
      this.columns = _.toArray(JSON.parse(res.SQLDATA));
      this.logger.log('columns is', this.columns);

      this.loadUserFilter();
    });
  }

  /**
   * Загрузка фильтра
   */
  private loadUserFilter() {
    this.journalService.getUserParams(this.filterParamsId, this.journalSettings.PARAMS).subscribe((filterMap) => {
      this.filterMap = filterMap;
      console.log(this.journalSettings.PARAMS);
      this.journalService.convertFilterMap(this.filterMapQuery, this.filterMap);

      this.afterLoading();
    });
  }

  /**
   * Окончание загрузки
   */
  private afterLoading() {
    // данные для таблицы загружены
    this.isLoading = false;

    // запрашиваем данные
    this.setPage(0);
  }

  /**
   * Получение данных
   */
  getData() {
    this.isLoadingData = true;

    const params = {
      sortModel: this.defaultSort,
      FILTERPARAMS: this.filterMapQuery,
      ROWSCOUNT: this.page.size,
      PAGE: this.page.pageNumber,
      JOURNALID: this.journalSettings.ID
    };

    this.journalService.getDataJournal(params).subscribe((res) => {
      this.page.totalElements = res.TOTALCOUNT;
      this.page.totalPages = Math.floor(res.TOTALCOUNT / this.page.size);

      this.rows = res.LISTRESULT;
      this.logger.log('rows is', this.rows);

      this.isLoadingData = false;
    });
  }

  /**
   * Выбор элемента
   */
  onDoubleClick() {
    this.logger.log('Event: doubleClicked', this.selected);
    this.onDoubleClicked.emit(this.selected);
  }

  /**
   * Выбор элемента
   * @param event
   */
  onSelect(event) {
    this.logger.log('Event: select', event);
    // выбираем строку
    this.selected = event.selected[0];

    // расскрытие подробной информации?
    if (this.isExpand) {
      // открываем
      if (this.selected) {
        this.table.rowDetail.toggleExpandRow(this.selected);
      }
    } else {
      this.onSelected.emit(event);
    }
  }

  /**
   * Событие на расскрытие
   * @param event
   */
  onDetailToggle(event) {
    // this.logger.log('Detail Toggled', event);
  }

  /**
   * События клика на страницу
   * @param pageInfo
   */
  onPage(pageInfo) {
    this.setPage(pageInfo.offset);
  }

  /**
   * Переход по страницам
   * @param pageNumber
   */
  setPage(pageNumber) {
    this.page.pageNumber = pageNumber;
    this.getData();
  }

  /**
   * Получаем фильтр
   */
  onFilter(filterMapQuery) {
    this.filterMapQuery = filterMapQuery;

    this.getData();
  }

}
