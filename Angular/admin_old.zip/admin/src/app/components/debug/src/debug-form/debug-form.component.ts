import { Component, Input, ElementRef } from '@angular/core';
import { NgForm } from '@angular/forms';
import { environment } from 'environments/environment';

@Component({
  selector: 'debug-form',
  templateUrl: './debug-form.component.html',
  styleUrls: ['./debug-form.component.scss']
})
export class DebugFormComponent {
  /**
   * Форма
   */
  @Input() form: NgForm;
  /**
   * Имя формы
   */
  @Input() name: string;

  private developerMode: boolean = false;

  constructor(private elementRef: ElementRef) {
    this.developerMode = !environment.production;
  }

  private log(name: any, value?: any) {
    console.log('name', this.name);
    console.log('elementRef', this.elementRef);
    console.log(name, value);
  }
}
