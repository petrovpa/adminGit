import { NgModule } from '@angular/core';
import { CommonModule, JsonPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { PrettyJsonModule, ɵc } from 'angular2-prettyjson';

import { DebugObjectComponent } from './debug-object/debug-object.component';
import { DebugFormComponent } from './debug-form/debug-form.component';
import { DebugMenuComponent } from './debug-menu/debug-menu.component';

const DEBUG_COMPONENTS = [
  DebugObjectComponent,
  DebugFormComponent,
  DebugMenuComponent
];

@NgModule({
  imports: [
    PrettyJsonModule,
    CommonModule,
    FormsModule
  ],
  declarations: DEBUG_COMPONENTS,
  providers: [
    { provide: JsonPipe, useClass: ɵc }
  ],
  exports: DEBUG_COMPONENTS
})
export class DebugModule {
}
