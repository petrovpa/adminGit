import { Component, Input, ViewEncapsulation } from '@angular/core';
import { environment } from 'environments/environment';

@Component({
  selector: 'debug-object',
  templateUrl: './debug-object.component.html',
  styleUrls: ['./debug-object.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class DebugObjectComponent {
  protected isOpen: boolean = false;
  protected developerMode: boolean = false;
  /**
   * Имя объекта
   */
  @Input() name: string;
  /**
   * Сам объект
   */
  @Input() obj: any;

  constructor() {
    this.developerMode = !environment.production;
  }

  /**
   * Переключалка
   */
  toggle() {
    this.isOpen = !this.isOpen;
  }
}
