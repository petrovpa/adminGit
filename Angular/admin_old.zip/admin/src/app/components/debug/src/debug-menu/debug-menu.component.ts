import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'debug-menu',
  templateUrl: './debug-menu.component.html',
  styleUrls: ['./debug-menu.component.scss']
})
export class DebugMenuComponent implements OnInit {
  @Input() namespace: any;
  @Input() itemslist: any;
  @Input() isView: any;
  @Input() isViewAll: any;
  @Input() isHideAll: any;
  @Input() isRoot: any;

  private isArray: boolean = false;
  private isObject: boolean = true;
  private isNull: boolean = true;

  constructor() {
  }

  ngOnInit() {
    if (this.isViewAll == null) {
      this.isViewAll = false;
    }
    if (this.isHideAll == null) {
      this.isHideAll = false;
    }


    this.isArray = false;
    this.isObject = true;
    this.isNull = true;
    if (this.itemslist != null) {
      this.isNull = false;
      if (this.isArrayf(this.itemslist)) {
        this.isArray = true;
        this.isObject = false;
      } else {
        this.isArray = false;
        this.isObject = this.isObjectf(this.itemslist);
      }
    }
  }

  copyToClipboard(text: any) {
    window.prompt("Copy to clipboard: Ctrl+C, Enter", JSON.stringify(text));
  }

  keys(): Array<any> {
    return Object.keys(this.itemslist);
  }

  toArray(val: any) {
    return Array.from(val);
  }

  isArrayf(ob: any) {
    return ob.constructor === Array;
  }

  isObjectf(ob: any) {
    return ob.constructor === Object;
  }

  showAll() {
    this.isViewAll = !this.isViewAll;
    this.isHideAll = false;
  }

  hideAll() {
    this.isViewAll = false;
    this.isHideAll = !this.isHideAll;
  }

  clickItem(item: any) {
    if (item.isView == null) {
      item.isView = true;
    } else {
      item.isView = !item.isView;
    }
  };

  trackByItem(item: any, index: any) {

    return this.namespace + '.' + index;
  }

  trackByKeyVal(key: any, val: any, index: any) {
    return this.namespace + '.' + index;
  }

  isSimple(val: any) {
    let res = true;
    if (val == null) {
      return true;
    }
    if (typeof val === 'undefined') {
      return true;
    }
    if (this.isArrayf(val)) {
      res = false;
    }
    if (this.isObjectf(val)) {
      res = false;
    }
    return res;
  }

  getTypeObj(val: any) {
    let res = 'simple';
    if (val == null) {
      return 'simple';
    }
    if (typeof val === 'undefined') {
      return 'simple';
    }
    if (this.isArrayf(val)) {
      res = 'array';
    }
    if (this.isObjectf(val)) {
      res = 'object';
    }
    return res;
  }
}
