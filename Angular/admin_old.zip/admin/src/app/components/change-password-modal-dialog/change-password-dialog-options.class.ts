export class ChangePasswordDialogOptions {
    modalDialogConfig: string;
    modalDialogTitle: string;
    labelTitle: string;
    onClickConfirmButton: Function;
}
