import { Component, OnInit, Inject, ViewChild, Input} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ChangePasswordDialogOptions } from './change-password-dialog-options.class';
import { ModalDialogComponent } from '@frontend/dialog-modal';

@Component({
    selector: 'change-password-dialog',
    templateUrl: './change-password-dialog.component.html',
    styleUrls: ['./change-password-dialog.component.scss']
})
export class ChangePasswordDialogComponent implements OnInit {
    @ViewChild('dialog') dialog: ModalDialogComponent;

    @Input() options: ChangePasswordDialogOptions = <ChangePasswordDialogOptions> {};

    private currentPassword: any = '';

    private newPassword: any = '';

    private retPassword: any = '';

    private isEqualPassword: boolean = false;

    private wasValidate: boolean = false;

    private repeatErrorMessage = 'Введённые пароли не совпадают';

    constructor() {
    }

    ngOnInit() {
    }

    private onPasswordChanged() {
        if (this.newPassword === this.retPassword) {
            this.isEqualPassword = true;
        } else {
            this.isEqualPassword = false;
        }
    }

    private onCheckRegExpPassword(event: any) {
        if (event) {
            this.repeatErrorMessage = event.errorMessage;
        }
    }
}
