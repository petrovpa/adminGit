import { Component, Input, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { MenuItem } from '@app/classes/menu-item.class';

@Component({
  selector: 'app-sidebar',
  templateUrl: './app-sidebar.component.html',
  styleUrls: [
    './app-sidebar.component.scss'
  ]
})

export class AppSidebarComponent implements OnInit {

  @Input() routes$: BehaviorSubject<MenuItem[]>;
  private _routes: MenuItem[];
  public get routes(): Observable<MenuItem[]> {
    return this.routes$.asObservable();
  }

  constructor() {
    if (this.routes$) {
      this.routes$.filter((v: any) => v.path !== '' && v.path !== '**' && typeof v.redirectTo !== 'undefined');
    }
  }

  ngOnInit() {
    this.routes$.subscribe((routes) => {
      console.log('__________MENU ROUTES', routes);
    });
  }
}
