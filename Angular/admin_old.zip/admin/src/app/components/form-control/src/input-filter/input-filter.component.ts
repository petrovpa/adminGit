import { Component, OnInit, Input, forwardRef } from '@angular/core';
import { NG_VALIDATORS, NG_VALUE_ACCESSOR } from '@angular/forms';
import { InputFieldComponent } from '../input-field/input-field.component';

@Component({
  selector: 'input-filter',
  template: `
  <span class="form-control__container">
    <input #textInput="ngModel" class="form-control"
           [type]="_type"
           [id]="id"
           [name]="name"
           [(ngModel)]="value"
           [attr.minlength]="minLength"
           [attr.maxlength]="maxLength"
           [pattern]="pattern"
           [attr.autocomplete]="autocomplete"
           [placeholder]="placeholder"
           [inputFilter]="filter"
           [required]="required"
           [disabled]="disabled"
           [readonly]="readonly"
           [ngClass]="styleClass"
           [customValidatorFn]="customValidatorFn"
           (ngModelChange)="change($event)"
           (input)="input($event)"
           (blur)="blur($event)"
           (focus)="focus($event)"
           (keydown)="onKeydown($event)"
           (onFilterValue)="filterValue($event)">
    <validation-message *ngIf="errorMessage" [control]="textInput" [customMessage]="errorMessageCustom"></validation-message>
    <span class="form-control__alert"><alert-control *ngIf="isShowAlert" type="danger">{{alertMessage}}</alert-control></span>
  </span>
  `,
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => InputFilterComponent),
    multi: true,
  }, {
    // для возможности корректно реализовать интерфейс Validator
    provide: NG_VALIDATORS,
    useExisting: forwardRef(() => InputFilterComponent),
    multi: true,
  }]
})
export class InputFilterComponent extends InputFieldComponent implements OnInit {
  /**
   * Получаем текст сообщения
   */
  @Input() alertMessage = 'Недопустимый символ';

  /**
   * Время автоскрытия
   */
  @Input() alertTime: number = 5;

  /**
   * Показывать ли сообщение
   */
  isShowAlert: boolean = false;

  /**
   * Таймер автоскрытия
   */
  alertTimer;

  ngOnInit() {
    if (!this.filter) {
      console.warn('Input filter required filter param');
    }
  }

  /**
   * Показ ошибки ввода
   * @type {boolean}
   */
  filterValue($event: boolean) {
    this.isShowAlert = $event;

    this.clearAlertTimer();

    // скрываем через 5 секунд
    this.alertTimer = setTimeout(() => {
      this.isShowAlert = false;
      clearTimeout(this.alertTime);
    }, this.alertTime * 1000);
  }

  /**
   * Потеря фокуса
   */
  blur($event) {
    this.clearAlertTimer();
    this.isShowAlert = false;
  }

  /**
   * Уничтожаем таймер автоскрытия
   */
  private clearAlertTimer() {
    if (this.alertTimer) {
      clearTimeout(this.alertTime);
    }
  }
}
