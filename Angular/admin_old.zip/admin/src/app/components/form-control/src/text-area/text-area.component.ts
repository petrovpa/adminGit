import { Component, forwardRef, Input } from '@angular/core';

import { ControlInputBase } from '../base/control-input-base';
import { NG_VALIDATORS, NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
  selector: 'text-area',
  template: `
    <span class="form-control__container">
      <textarea #textInput="ngModel" class="form-control"
                [id]="id"
                [name]="name"
                [(ngModel)]="value"
                [attr.autocomplete]="autocomplete"
                [attr.minlength]="minLength"
                [attr.maxlength]="maxLength"
                [attr.pattern]="pattern"
                [placeholder]="placeholder"
                [required]="required"
                [disabled]="disabled"
                [readonly]="readonly"
                [ngClass]="styleClass"
                [customValidatorFn]="customValidatorFn"
                (ngModelChange)="change($event)"
                (input)="input($event)"
                (blur)="blur($event)"
                (focus)="focus($event)"></textarea>
        <validation-message *ngIf="errorMessage" [control]="textInput" [customMessage]="errorMessageCustom"></validation-message>
      </span>
  `,
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => TextAreaComponent),
    multi: true,
  }, {
    // для возможности корректно реализовать интерфейс Validator
    provide: NG_VALIDATORS,
    useExisting: forwardRef(() => TextAreaComponent),
    multi: true,
  }]
})
export class TextAreaComponent extends ControlInputBase {
  /**
   * @input {any} The minimum length
   */
  @Input() minLength: number | string = null;
  /**
   * @input {any} The maximum length
   */
  @Input() maxLength: number | string = null;
  /**
   * An HTML form with an input field that can contain only three letters (no numbers or special characters):
   * pattern="[A-Za-z]{3}"
   * @type {null}
   */
  @Input() pattern: number | string = null;
}
