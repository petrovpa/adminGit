import { ControlValueAccessor } from '@angular/forms';

export abstract class ValueAccessorBase<T> implements ControlValueAccessor {
  protected innerValue: T;
  protected changed = [];
  protected touched = [];

  /**
   *  Value set and get
   * @returns {T}
   */
  get value(): T {
    return this.innerValue;
  }

  set value(value: T) {
    if (this.innerValue !== value) {
      this.innerValue = value;
      // FIXME: валидация срабатывает на следующем цикле
      setTimeout(() => this.callChanged(value));
      this.callChanged(value)
    }
  }

  /**
   * Writes a new value to the element.
   */
  writeValue(value: T) {
    this.value = value;
  }

  /**
   * Registers a callback function that should be called when the control's value
   * changes in the UI.
   */
  registerOnChange(fn: (value: T) => void) {
    this.changed.push(fn);
  }

  /**
   * Registers a callback function that should be called when the control receives
   * a blur event.
   */
  registerOnTouched(fn: () => void) {
    this.touched.push(fn);
  }

  callTouched() {
    this.touched.forEach(f => f());
  }

  callChanged(value: T) {
    this.changed.forEach(f => f(value));
  }
}
