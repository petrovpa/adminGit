import { Component, forwardRef } from '@angular/core';
import { InputFieldComponent } from '../input-field/input-field.component';
import { NG_VALIDATORS, NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
  selector: 'input-phone',
  template: `
  <span class="form-control__container">
    <input #textInput="ngModel" class="form-control"
         type="text"
         [id]="id"
         [name]="name"
         [(ngModel)]="value"
         [textMask]="{mask: phoneMask}"
         [attr.autocomplete]="autocomplete"
         placeholder="(___) ___-__-__"
         onlyNum
         [required]="required"
         [disabled]="disabled"
         [ngClass]="styleClass"
         [customValidatorFn]="customValidatorFn"
         (ngModelChange)="change($event)"
         (focus)="focus($event)"
         (blur)="blur($event)"
         (keyup.enter)="enter($event)">
    <validation-message *ngIf="errorMessage" [control]="textInput" [customMessage]="errorMessageCustom"></validation-message>
  </span>
  `,
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => InputPhoneComponent),
    multi: true,
  }, {
    // для возможности корректно реализовать интерфейс Validator
    provide: NG_VALIDATORS,
    useExisting: forwardRef(() => InputPhoneComponent),
    multi: true,
  }]
})
export class InputPhoneComponent extends InputFieldComponent {
  phoneMask = ['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, '-', /\d/, /\d/];
}
