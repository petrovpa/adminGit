import { Component, forwardRef, Input, SimpleChanges } from '@angular/core';
import { InputFieldComponent } from '../input-field/input-field.component';
import { NG_VALIDATORS, NG_VALUE_ACCESSOR } from '@angular/forms';

const CITIZENSHIP_RUSSIAN_SYSNAME = 'russian';

@Component({
  selector: 'input-name',
  template: `
  <span class="form-control__container">
    <input #textInput="ngModel" [class]="'form-control' + (styleClass ? ' ' + styleClass : '')"
           type="text"
           [id]="id"
           [name]="name"
           [(ngModel)]="value"
           [placeholder]="placeholder"
           [attr.minlength]="minLength"
           [attr.maxlength]="maxLength"
           [inputFilter]="nameInputFilter"
           [attr.pattern]="namePattern"
           [attr.autocomplete]="autocomplete"
           capitalizeFirst
           [required]="required"
           [disabled]="disabled"
           [ngClass]="{'is-invalid': isCorrected}"
           [customValidatorFn]="customValidatorFn"
           (ngModelChange)="change($event)"
           (input)="input($event)"
           (blur)="blur($event)"
           (focus)="focus($event)"
           (onFilterValue)="onFilterValue($event)">
    <validation-message *ngIf="errorMessage" [control]="textInput"
                        [customMessage]="errorMessageCustom"></validation-message>
    <span class="form-control__alert">
      <alert-control [isOpen]="isCorrected" type="danger">{{filterErrorMessage}}</alert-control>
    </span>
  </span>
  `,
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => InputNameComponent),
    multi: true,
  }, {
    // для возможности корректно реализовать интерфейс Validator
    provide: NG_VALIDATORS,
    useExisting: forwardRef(() => InputNameComponent),
    multi: true,
  }]
})
export class InputNameComponent extends InputFieldComponent {
  /**
   * Type of national name
   *
   * @param {string} value
   */
  private _citizenship: string = CITIZENSHIP_RUSSIAN_SYSNAME;
  @Input()
  set citizenship(value: string) {
    if ((value) && (value !== this.citizenship)) {
      this._citizenship = value;
      // уведомление об изменении значения подписчиков ValueAccessor/Base
      // (для вызова валидации текущего компонента и др.)
      this.callChanged(this.value);
    }
  }

  get citizenship(): string {
    return this._citizenship;
  }

  /**
   * Фильтр
   * @returns {RegExp}
   */
  get nameInputFilter(): RegExp {
    // согласно документу 'Страхователь и паспортные данные'
    // "• Буквы кириллицы"
    // "• Символ «пробел»"
    // "• Символ «-»"
    // "• Символ «’»"
    // "• Должно начинаться с буквы"
    return /(^[^А-Яа-яЁё])|([^А-Яа-яЁё\s\-\’\`\'])/;
  }

  /**
   * Ограничение
   * @returns {string}
   */
  get namePattern(): string {
    let regExp: RegExp;

    if (this.citizenship === CITIZENSHIP_RUSSIAN_SYSNAME) {
      regExp = /[А-Яа-яЁё\s\-']/;
    } else {
      regExp = /([A-Za-zА-Яа-яЁё\s\-'])/;
    }

    return regExp.source;
  }

  /**
   * СОобщение о некорректности ввода
   * @returns {string}
   */
  get filterErrorMessage(): string {
    let message: string;

    if (this.citizenship === CITIZENSHIP_RUSSIAN_SYSNAME) {
      message = 'ФИО гражданина РФ необходимо заполнять русскими буквами.';
    } else {
      message = 'Недопустимый символ.';
    }

    return message;
  }

  /**
   * таймер автоскрытия
   */
  timerAlert;

  /**
   * Скорректировано значение - выводим ошибку
   * @type {boolean}
   */
  isCorrected: boolean = false;

  /**
   * Показ ошибки ввода
   * @type {boolean}
   */
  onFilterValue($event: boolean) {
    this.isCorrected = $event;

    this.clearAlertTimer();

    // скрываем через 5 секунд
    this.timerAlert = setTimeout(() => {
      this.isCorrected = false;
      clearTimeout(this.timerAlert);
    }, 5000);
  }

  /**
   * Потеря фокуса
   */
  blur($event) {
    this.clearAlertTimer();
    this.isCorrected = false;
  }

  /**
   * Уничтожаем таймер автоскрытия
   */
  private clearAlertTimer() {
    if (this.timerAlert) {
      clearTimeout(this.timerAlert);
    }
  }
}
