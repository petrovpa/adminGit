import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { CurrencyMaskModule } from 'ng2-currency-mask';
import { TextMaskModule } from 'angular2-text-mask';

import { ValidatorsModule } from '@frontend/validators';
import { DropdownModule } from '@frontend/dropdown';
import { AlertModule } from '@frontend/alert';
import { DatepickerModule } from '@frontend/datepicker';
import { InputFormatModule } from '@frontend/input-format';

import { InputDatePickerComponent } from './input-datepicker/input-datepicker.component';
import { CheckboxComponent } from './checkbox/checkbox.component';
import { TextAreaComponent } from './text-area/text-area.component';
import { InputFieldComponent } from './input-field/input-field.component';
import { InputEmailComponent } from './input-email/input-email.component';
import { InputNameComponent } from './input-name/input-name.component';
import { InputNumberComponent } from './input-number/input-number.component';
import { InputPhoneComponent } from './input-phone/input-phone.component';
import { InputSnilsComponent } from './input-snils/input-snils.component';
import { InputSumComponent } from './input-sum/input-sum.component';
import { SelectComponent } from './select/select.component';
import { RadioButtonComponent } from './radio-button/radio-button.component';
import { InputMaskComponent } from './input-mask/input-mask.component';
import { AutocompleteComponent } from './autocomplete/autocomplete.component';
import { ValidationMessageComponent } from './validation-message/validation-message.component';
import { InputPercentComponent } from './input-percent/input-percent.component';
import { InputGenderComponent } from './input-gender/input-gender.component';
import { InputFilterComponent } from './input-filter/input-filter.component';

const FORM_CONTROL_FIELDS = [
  AutocompleteComponent,
  InputDatePickerComponent,
  CheckboxComponent,
  InputEmailComponent,
  InputFieldComponent,
  InputFilterComponent,
  InputMaskComponent,
  InputNameComponent,
  InputNumberComponent,
  InputPercentComponent,
  InputPhoneComponent,
  InputSnilsComponent,
  InputSumComponent,
  InputGenderComponent,
  RadioButtonComponent,
  SelectComponent,
  TextAreaComponent,
  ValidationMessageComponent
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    AlertModule,
    CurrencyMaskModule,
    DatepickerModule,
    TextMaskModule,
    InputFormatModule,
    ValidatorsModule,
    DropdownModule.forRoot()
  ],
  declarations: FORM_CONTROL_FIELDS,
  exports: FORM_CONTROL_FIELDS
})
export class FormControlModule {
}
