import { Component, Input, Output, EventEmitter, forwardRef, ChangeDetectorRef, OnInit } from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor, FormControl } from '@angular/forms';

export const CHECKBOX_VALUE_ACCESSOR: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => CheckboxComponent),
  multi: true
};

@Component({
  selector: 'checkbox',
  template: `
  <div class="form-check" [ngClass]="styleClass">
    <span class="form-control__container">
      <input #checkbox
             type="checkbox"
             class="form-check-input"
             [attr.id]="id"
             [name]="name"
             [value]="value"
             [checked]="checked"
             [attr.disabled]="disabled?'':null"
             (focus)="onFocus($event)" (blur)="onBlur($event)" (click)="onClick($event, checkbox, true)">
      <label class="form-check-label"
             *ngIf="label"
             [attr.for]="id">{{label}}</label>
    </span>
  </div>
  `,
  providers: [CHECKBOX_VALUE_ACCESSOR]
})
export class CheckboxComponent implements ControlValueAccessor, OnInit {
  // Label of the checkbox.
  @Input() label: string;
  // Value of the checkbox.
  @Input() value: any;
  // Name of the checkbox group.
  @Input() name: string;
  // When present, it specifies that the element should be disabled.
  @Input() disabled: boolean;
  // Identifier of the focus input to match a label defined for the component.
  @Input() id: string;
  // Allows to select a boolean value instead of multiple values.
  @Input() binary: boolean = true;
  // Style class of the component.
  @Input() styleClass: string;

  @Input() formControl: FormControl;

  @Output() onChange: EventEmitter<any> = new EventEmitter();

  model: any;

  onModelChange: Function = () => { };

  onModelTouched: Function = () => { };

  focused: boolean = false;

  checked: boolean = false;

  constructor(private cd: ChangeDetectorRef) { }

  ngOnInit() {
    if (!this.name) {
      this.name = new Date().getMilliseconds().toString();
    }

    if (!this.id) {
      this.id = 'checkbox-' + this.name;
    }
  }

  onClick(event, checkbox, focus: boolean) {
    if (this.disabled) {
      return;
    }

    this.checked = !this.checked;
    this.updateModel();

    if (focus) {
      checkbox.focus();
    }
  }

  updateModel() {
    if (!this.binary) {
      if (this.checked)
        this.addValue();
      else
        this.removeValue();

      this.onModelChange(this.model);

      if (this.formControl) {
        this.formControl.setValue(this.model);
      }
    } else {
      const value = this.checked ? 1 : 0;
      this.onModelChange(value);
    }

    this.onChange.emit(this.checked);
  }

  handleChange(event) {
    this.checked = event.target.checked;
    this.updateModel();
  }

  isChecked(): boolean {
    if (this.binary)
      return !!this.model;
    else
      return this.model && this.model.indexOf(this.value) > -1;
  }

  removeValue() {
    this.model = this.model.filter(val => val !== this.value);
  }

  addValue() {
    if (this.model)
      this.model = [...this.model, this.value];
    else
      this.model = [this.value];
  }

  onFocus(event) {
    this.focused = true;
  }

  onBlur(event) {
    this.focused = false;
    this.onModelTouched();
  }

  writeValue(model: any): void {
    this.model = model;
    this.checked = this.isChecked();
    this.cd.markForCheck();
  }

  registerOnChange(fn: Function): void {
    this.onModelChange = fn;
  }

  registerOnTouched(fn: Function): void {
    this.onModelTouched = fn;
  }
}
