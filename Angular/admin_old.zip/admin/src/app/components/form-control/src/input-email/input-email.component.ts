import { Component, forwardRef } from '@angular/core';
import { InputFieldComponent } from '../input-field/input-field.component';
import { NG_VALIDATORS, NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
  selector: 'input-email',
  template: `
  <span class="form-control__container">
    <input #textInput="ngModel" class="form-control"
           type="email"
           [id]="id"
           [name]="name"
           [(ngModel)]="value"
           [attr.minlength]="minLength"
           [attr.maxlength]="maxLength"
           [attr.autocomplete]="autocomplete"
           [disabled]="disabled"
           [required]="required"
           [placeholder]="placeholder"
           [inputFilter]="emailInputFilter"
           customEmail
           [ngClass]="styleClass"
           [customValidatorFn]="customValidatorFn"
           (ngModelChange)="change($event)"
           (keyup.enter)="enter($event)"
           (paste)="false">
    <validation-message *ngIf="errorMessage" [control]="textInput" [customMessage]="errorMessageCustom"></validation-message>
  </span>
  `,
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => InputEmailComponent),
    multi: true,
  }, {
    // для возможности корректно реализовать интерфейс Validator
    provide: NG_VALIDATORS,
    useExisting: forwardRef(() => InputEmailComponent),
    multi: true,
  }]
})
export class InputEmailComponent extends InputFieldComponent {
  // emailPattern = /[A-Za-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[A-Za-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?\.)+[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?/;
  emailInputFilter = /((^[^A-Za-z0-9])|([^A-Za-z0-9\\s\\@\-\\_\\.]))/;
}
