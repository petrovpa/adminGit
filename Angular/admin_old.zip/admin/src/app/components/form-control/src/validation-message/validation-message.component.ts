import { Component, Input, OnInit } from '@angular/core';
import { AbstractControl } from '@angular/forms';

import {DefaultErrorMessages, ValidationMessageProvider} from './validation-message';

@Component({
  selector: 'validation-message',
  template: '<span class="invalid-validate form-control__message" *ngIf="errorMessage !== null">{{errorMessage}}</span>'
})
export class ValidationMessageComponent implements OnInit {
  /**
   * Input control
   */
  @Input() control: AbstractControl;
  /**
   * Custom messages
   */
  private _customMessage: { [key: string]: string };
  get customMessage(): { [p: string]: string } {
    return this._customMessage;
  }
  @Input() set customMessage(value: { [p: string]: string }) {
    this._customMessage = value;
    this.messageProvider.updateMessages(Object.assign({}, DefaultErrorMessages, value))
  }

  private messageProvider: ValidationMessageProvider;

  constructor() {
    this.messageProvider = new ValidationMessageProvider(DefaultErrorMessages);
  }

  ngOnInit(): void {
  }

  get errorMessage(): string {
    if (this.control && this.control.errors) {
      for (let errorPropertyName in this.control.errors) {
        if (this.control.errors.hasOwnProperty(errorPropertyName)) {
          return this.messageProvider.getErrorMessage(errorPropertyName, this.control.errors[errorPropertyName]);
        }
      }
    }
    return null;
  }
}
