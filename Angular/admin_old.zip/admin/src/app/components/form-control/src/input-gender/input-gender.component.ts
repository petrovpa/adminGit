import {
  Component,
  Optional,
  Inject,
  Input,
  ViewChild, EventEmitter, forwardRef, Output, OnInit
} from '@angular/core';

import {
  NgModel,
  NG_VALUE_ACCESSOR,
  NG_VALIDATORS,
  NG_ASYNC_VALIDATORS, FormControl,
} from '@angular/forms';

import { ElementBase } from '../base';

export const GENDER_VALUE_ACCESSOR: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => InputGenderComponent),
  multi: true
};

@Component({
  selector: 'input-gender',
  template: `
  <ng-container *ngFor="let item of genders">
  <div class="form-check" [ngClass]="styleClass">
      <span class="form-control__container">
        <input type="radio"
               class="form-check-input"
               [ngClass]="{
                'is-invalid':alertError
               }"
               [attr.id]="getInputId(item.value)"
               [name]="name"
               [(ngModel)]="value"
               [value]="item.value"
               [attr.disabled]="disabled?'':null"
               [required]="required"
               [checked]="isSelect(item.value)"
               (change)="changeValue(item.value)">
      <label [attr.for]="getInputId(item.value)"><span class="form-check-text">{{item.name}}</span></label>
      </span>
    </div>
  </ng-container>
  <span class="form-control__alert"><alert-control [isOpen]="alertError" type="danger">{{alertError}}</alert-control></span>
  `,
  providers: [GENDER_VALUE_ACCESSOR],
})
export class InputGenderComponent extends ElementBase<any> implements OnInit {
  /**
   * Имя поля
   */
  @Input() name: string;
  /**
   * Блокировка
   * @type {boolean}
   */
  @Input() disabled: boolean = false;
  /**
   * Обязательность
   * @type {boolean}
   */
  @Input() required: boolean = false;
  /**
   * Класс стиля
   */
  @Input() styleClass: string;
  /**
   * Всплывающее сообщение
   */
  @Input() alertError: string;

  // Models
  @ViewChild(NgModel) model: NgModel;
  @Input() formControl: FormControl;

  @Output() onChange: EventEmitter<any> = new EventEmitter();

  get value(): any {
    return this.innerValue;
  }

  set value(value: any) {
    if (this.innerValue !== value) {
      this.innerValue = value;
      this.callChanged(value)
    }
  }

  /**
   * Список пола
   */
  genders = [
    { value: 0, name: 'Мужской' },
    { value: 1, name: 'Женский' }
  ];

  constructor( @Optional() @Inject(NG_VALIDATORS) validatorList: Array<any>,
    @Optional() @Inject(NG_ASYNC_VALIDATORS) asyncValidatorList: Array<any>) {
    super(validatorList, asyncValidatorList);
  }

  ngOnInit() {
    if (!this.name) {
      this.name = 'gender-' + new Date().getMilliseconds().toString();
    }
  }

  /**
   * Идентификатор
   * @param value
   * @returns {string}
   */
  protected getInputId(value): string {
    return this.name + '-' + value
  }

  /**
   * Выбран?
   * @returns {boolean}
   */
  protected isSelect(itemValue) {
    return this.value === itemValue;
  }

  /**
   * Изменение значения
   * @param value
   */
  protected changeValue(value: any) {
    this.onChange.emit(value);
  }
}
