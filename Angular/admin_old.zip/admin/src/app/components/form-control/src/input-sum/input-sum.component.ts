import { Component, forwardRef, Input } from '@angular/core';
import { InputFieldComponent } from '../input-field/input-field.component';
import { NG_VALIDATORS, NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
  selector: 'input-sum',
  template: `
  <span class="form-control__container">
      <input #textInput="ngModel" class="form-control"
             type="text"
             [id]="id"
             [name]="name"
             [(ngModel)]="value"
             currencyMask
             [options]="sumOptions"
             [attr.minlength]="minLength"
             [attr.maxlength]="maxLength"
             [attr.step]="step"
             [minNumber]="minNumber"
             [maxNumber]="maxNumber"
             [placeholder]="placeholder"
             [attr.autocomplete]="autocomplete"
             [required]="required"
             [disabled]="disabled"
             [ngClass]="styleClass"
             [customValidatorFn]="customValidatorFn"
             (ngModelChange)="change($event)"
             (blur)="blur($event)"
             (focus)="focus($event)"
             (keyup.enter)="enter($event)">
      <validation-message *ngIf="errorMessage" [control]="textInput" [customMessage]="errorMessageCustom"></validation-message>
  </span>
  `,
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => InputSumComponent),
    multi: true,
  }, {
    // для возможности корректно реализовать интерфейс Validator
    provide: NG_VALIDATORS,
    useExisting: forwardRef(() => InputSumComponent),
    multi: true,
  }]
})
export class InputSumComponent extends InputFieldComponent {
  /**
   * Настройки ввода суммы
   * Подробнее о доступных параметрах - см. https://github.com/cesarrew/ng2-currency-mask#options.
   */
  @Input() sumOptions: any = {prefix: '', suffix: '', thousands: ' ', decimal: '.', precision: 0, align: 'left'};
  /**
   * @input {any} Шаг увеличения значения
   */
  @Input() step: number = 1;
  /**
   * @input {any} Минимальное значение
   */
  @Input() minNumber: number | string = null;
  /**
   * @input {any} Максимальное значение
   */
  @Input() maxNumber: number | string = null;

  /**
   * уведомление об изменении значения подписчиков ValueAccessor/Base (для вызова валидации текущего компонента и др.)
   * @param $event
   */
  change($event) {
    if (isNaN($event)) this.value = null;

    this.callChanged($event);
    // уведомление об изменении значения внешних подписчиков текущего компонента
    this.onChange.emit($event);
  }
}
