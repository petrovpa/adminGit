import {
  Component,
  EventEmitter,
  forwardRef,
  Input,
  OnInit,
  OnDestroy,
  Output,
  HostListener,
  ViewChild,
  ElementRef,
  Renderer2
} from '@angular/core';
import { NG_VALUE_ACCESSOR, NG_VALIDATORS, AbstractControl, ValidationErrors, NgModel } from '@angular/forms';
import { Observable } from 'rxjs/Observable';

import { ValueAccessorValidatorBase } from '../base/index';

@Component({
  selector: 'autocomplete',
  template: `
    <div class="form-control__container" [ngClass]="styleClass">
      <div class="autocomplete">
        <div class="form-control__icon">
          <span (click)="clickToInput()" *ngIf="visibleIconSearch">
            <i class="search"
                  [hidden]="!isHide()"
                  [ngClass]="{'form-control__icon_disabled': disabled}"></i>
          </span>

          <span *ngIf="isOpened" class="autocomplete__input-end"
                [ngClass]="{'autocomplete__input-end_disabled': disabled}">
            <i class="close"
                  [hidden]="isHide()"
                  (mouseover)="over()"
                  (mouseleave)="leave()"
                  (click)="removeValue()"></i>
          </span>

          <input class="form-control"
                 [ngClass]="{'form-control_required': required,
                             'form-control_focused': isOpened && !validate(null),
                             'form-control_active': isOpened && filteredOptions && filteredOptions.length,
                             'form-control_disabled': disabled}"
                 *ngIf="value"
                 #input
                 type="text"
                 [(ngModel)]="value[nameField]"
                 [name]="name"
                 (ngModelChange)="inputFieldChange($event)"
                 (focus)="doOpen()"
                 [required]="required"
                 [readonly]="disabled"
                 [disabled]="disabled"
                 [placeholder]="(innerValue || disabled) ? '' : placeholder">
        </div>

        <div class="autocomplete-block">
          <div id="dropList" *ngIf="isOpenedFn()" class="autocomplete-list">
            <div *ngFor="let option of filteredOptions;">
              <a id="dropItem" (click)="onSelectEvent(option)" class="autocomplete-list__item"
                  [class.autocomplete-list__item_disabled]="isDisabled(option)"
                 [ngClass]="{'autocomplete-list__item_active': isAcive(option)}">
                {{ option[nameField] }}
              </a>
            </div>
          </div>
        </div>

        <alert-control *ngIf="isError" type="danger">
          {{errorMessage}}
        </alert-control>
      </div>
    </div>
  `,
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => AutocompleteComponent),
      multi: true
    }, {
      // для возможности корректно реализовать интерфейс Validator
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => AutocompleteComponent),
      multi: true,
    }
  ]
})
export class AutocompleteComponent extends ValueAccessorValidatorBase<any> implements OnInit, OnDestroy {
  /**
   * Options object for this `ngModel` instance
   */
  @ViewChild(NgModel) model: NgModel;
  /**
   * Название поля
   */
  @Input() name: string;
  /**
   * Обязательность поля
   * @type {boolean}
   */
  @Input() required = false;
  /**
   * Блокировка поля
   * @type {boolean}
   */
  @Input() disabled = false;
  /**
   * Список
   * @type {any[]}
   */
  @Input() items: any[] = [];
  /*
  private _items: any[] = [];
  @Input() set items(value: any[]){
    this._items = value;
  };
  get items(): any[] {
    return this._items;
  }
  */
  /**
   * Класс для стилизации
   */
  @Input() styleClass: string;
  /**
   * Ключ -> значения списка
   * @type {string}
   */
  @Input() nameField = 'name';
  @Input() sysnameField = 'sysname';
  /** Имя поля, отвечающего за блокирование элемента в списке */
  @Input() disabledField = 'isDisabled';
  /**
   * Подсказка
   * @type {string}
   */
  @Input() placeholder = '';
  /**
   * Функция сортировки
   */
  @Input() orderFn: (data: any) => any;
  /**
   * Показывать ли иконку у поля
   * @type {boolean}
   */
  @Input() visibleIconSearch: boolean = false;
  /**
   * Сообщение об ошибке
   * @type {string}
   */
  @Input() errorMessage = 'Пожалуйста, выберите значение из списка';
  /**
   * Подгрузка данных через сервисы
   */
  @Input() serviceCaller: ServiceCaller;
  @Input() isDisabledSelectValueOnBlur = false;
  @Input() sequenceSize = 0;
  @Input() clsName;
  /**
   * Событие
   * @type {EventEmitter<any>}
   */
  @Output() onChange = new EventEmitter();
  @Output() onSelect = new EventEmitter();
  @Output() onInputBlur = new EventEmitter();

  public hoverRemItem = false;
  public isOpened: boolean = false;
  public isError: boolean = false;
  public activePosition: number;
  public filteredOptions: any = [];

  private activeEvent = new EventEmitter();

  @ViewChild('input') input: ElementRef;

  get nativeElement(): any {
    return this.element && this.element.nativeElement;
  }

  /**
   * Значение
   * @returns {any}
   */
  get value(): any {
    if (!this.innerValue) {
      this.innerValue = {};
    }
    return this.innerValue;
  }

  set value(v: any) {
    if (!this.innerValue) {
      this.innerValue = {};
    }

    const inVal = this.innerValue,
          field = this.nameField,
          sysname = this.sysnameField,
          changedData: boolean = (v && ((v[field] !== inVal[field]) || (v[sysname] !== inVal[sysname]))),
          isEmptyObj: boolean = (v && (Object.keys(v).length === 0));

    this.isError = (isEmptyObj || (v == null));
    if (changedData || isEmptyObj) {
      this.innerValue = v;
      // первая вставка данных - инициализация.
      // по идее криво, но пойдет
      this.callChanged(v);
      this.onChange.emit(v);
      this.updateFilteredOptions(v[field]);
    }
  }

  constructor(private renderer: Renderer2,
              private element: ElementRef) {
    super();
  }

  @HostListener('window:click', ['$event'])
  onWindowClick(event: MouseEvent) {
    if (this.isOpened) {
      if (this.nativeElement && event) {
        const target = event.target;
        const isContains = this.nativeElement.contains(target);
        if (!isContains) {
          this.doClose();
        }
      }
    }
  }

  @HostListener('window:keydown', ['$event'])
  keyboardInput(event: KeyboardEvent) {
    if (this.isOpened) {
      const size = this.filteredOptions.length - 1;
      const dropList = document.getElementById('dropList');
      const itemList = document.getElementById('dropItem');

      switch (event.code) {
        // сбрасываем фокус по нажатию таба
        case 'Tab': {
          this.doClose();
          break;
        }

        // ездим по списку по стрелке вверх
        case 'ArrowUp': {
          this.activePosition = this.activePosition - 1 < 0 ? size : this.activePosition - 1;
          break;
        }

        // ездим по списку по стрелке вниз
        case 'ArrowDown': {
          this.activePosition = this.activePosition + 1 > size ? 0 : this.activePosition + 1;
          break;
        }

        // принимаем выбор по одному из двух ентеров
        case 'Enter': {
          break;
        }

        case 'NumpadEnter': {
          this.onSelectEvent(this.filteredOptions[this.activePosition]);
          break;
        }
      }
      // +1 - бордер
      if (itemList && itemList.clientHeight) {
        dropList.scrollTop = (itemList.clientHeight + 1) * (this.activePosition - 2);
      }
    }
  }

  onBlur() {
    this.callTouched();
  }

  onSelectEvent(option: any) {
    if (this.isDisabled(option)) {
      // если элемент отмечен как заблокированный, то позволять выбирать его не следует
      return;
    }
    // если не положить option в value, то сначала будет вызван OnSelect, а потом OnChange.
    // И если, к примеру в компоненте адреса, событие, к примеру очиска, навешена на OnChange,
    // то изменение сделанные через селект - затрутся, что полный отстой.
    Object.assign(this.value, option);
    this.onSelect.emit(option);
    this.isOpened = false;
    const field = this.nameField;
    this.isError = ((option == null) || (Object.keys(option).length === 0));
    this.updateFilteredOptions(option[field]);
  }

  ngOnInit() {
    if (this.clsName) {
      console.error(
        'AutocompleteInputComponent: clsName is specified ('
        + this.clsName
        + ') but correct HandbookService support is not implemented!'
      );
    }
  }

  private isAcive(data: any): boolean {
    return this.filteredOptions[this.activePosition] === data;
  }

  private isDisabled(option) {
    let isDisabled = option[this.disabledField];
    if (isDisabled === undefined) {
      isDisabled = false;
    }
    return isDisabled;
  }

  clickToInput() {
    this.input.nativeElement.focus();
  }

  doClose() {
    this.isOpened = false;
    if (this.filteredOptions.length === 1) {
      let onlyOption = this.filteredOptions[0];
      if (this.isDisabled(onlyOption)) {
        onlyOption = {};
      }
      Object.assign(this.value, onlyOption);
      this.onSelectEvent(this.value);
    }
  }

  doOpen() {
    this.isOpened = true;
    this.activePosition = -1;
    this.activeEvent.emit();
    this.updateFilteredOptions(this.innerValue[this.nameField]);
  }

  /**
   * Открыт ли список
   * @returns {boolean}
   */
  public isOpenedFn() {
    const notEmpty: boolean = this.filteredOptions && this.filteredOptions.length > 0;
    return this.isOpened && notEmpty;
  }

  /**
   * Обновление списка
   * @param data
   */
  public updateValue(data: any) {
    this.items = [];
    this.updateFilteredOptions(data[this.nameField], data);
  }

  /**
   * Параметры фильтра
   * @param filterString
   * @param data
   */
  protected updateFilteredOptions(filterString: any = '', data?: any) {
    if (filterString.length >= this.sequenceSize) {
      if (this.serviceCaller) {
        this.serviceCaller.call(filterString).subscribe(res => {
          this.items = res;
          this.filteredOptions = this.filter(filterString);
          if (data) {
            this.value = data;
          }
        });
      } else {
        this.filteredOptions = this.filter(filterString);
      }
    } else {
      this.filteredOptions = [];
    }
  }

  private waitInit = false;

  /**
   * Изменение поля
   * @param event
   */
  protected inputFieldChange(event: any) {
    const notNull: boolean = event != null;
    const typeIsString: boolean = (typeof event === 'string');
    if (this.waitInit && notNull && typeIsString) {
      this.updateFilteredOptions(event);
      this.value[this.nameField] = event;
      this.value[this.sysnameField] = '';
      this.isError = true;
      this.onChange.emit(this.value);
      if (!this.isOpened && this.validate(null).autocompleteInputError) {
        this.doOpen();
      }
    }
    this.waitInit = true;
  }

  /**
   * Фильтр
   * @param val
   * @returns {any[]}
   */
  protected filter(val: any): any[] {
    if (!this.items) {
      return [];
    }
    if (!val || typeof val === 'object') {
      val = '';
    }
    let data: any[] = this.items.filter(item =>
      new RegExp(`^${val}`, 'gi').test(item[this.nameField])
    );
    if (this.orderFn) {
      data = this.orderFn(data);
    }
    return data;
  }

  /**
   * Удаление значения
   */
  public removeValue() {
    const clearedValue = {};
    this.writeValue(clearedValue);
    this.onChange.emit(null);
  }

  /**
   * Наведение
   */
  protected over() {
    this.hoverRemItem = true;
  }

  /**
   * Убрали наведение
   */
  protected leave() {
    this.hoverRemItem = false;
  }

  /**
   * Скрыть
   * @returns {boolean}
   */
  protected isHide() {
    return !(this.isOpened || this.hoverRemItem);
  }

  /**
   * Валидация
   * @param {AbstractControl} control
   * @returns {ValidationErrors | null}
   */
  public validate(control: AbstractControl): ValidationErrors | null {
    const isValid: boolean = this.innerValue && this.innerValue[this.sysnameField] && (this.innerValue[this.sysnameField] !== '');
    return isValid ? null : { autocompleteInputError: true };
  }

  ngOnDestroy() {
  }
}

export interface ServiceCaller {
  call(inputStr: string): Observable<any>;
}
