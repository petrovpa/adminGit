import { Input, ViewChild, Output, OnDestroy, SimpleChanges, OnChanges, EventEmitter, Component, forwardRef } from '@angular/core';
import { NG_VALIDATORS, NG_VALUE_ACCESSOR, NgModel } from '@angular/forms';

import { Subject } from 'rxjs/Subject';

import { isArray, isPresent, isString, isTrueProperty } from '../utils/utils';
import { ValidatorFunction } from '@frontend/validators';
import { ValueAccessorValidatorBase } from './value-accessor-validator';

export class ControlInputBase extends ValueAccessorValidatorBase<string> implements OnDestroy, OnChanges {
  protected _readonly: boolean = false;
  protected _required: boolean = false;
  protected _disabled: boolean = false;
  protected _onDestroy = new Subject<void>();
  protected _id: string;
  protected _name: string;
  protected _focused = false;

  /**
   * Options object for this `ngModel` instance
   */
  @ViewChild(NgModel) model: NgModel;
  /**
   * Name input
   */
  @Input()
  get name(): string {
    return this._name;
  }

  set name(value: string) {
    this._name = value;
  }
  /**
   * Unique HTML element
   * @type {string}
   */
  @Input()
  get id() {
    if (this._id) {
      return this._id;
    }

    return this._name;
  }

  set id(val: string) {
    this._id = val;
  }
  /**
   * @input {boolean} If true, the user cannot modify the value.
   */
  @Input()
  get readonly() {
    return this._readonly;
  }

  set readonly(val: boolean) {
    this._readonly = isTrueProperty(val);
  }
  /**
   * Required params
   *
   * @input {boolean} required state
   */
  @Input()
  get required() {
    return this._required;
  }

  set required(val: boolean) {
    this._required = isTrueProperty(val);
  }
  /**
   * Disabled params
   *
   * @input {boolean} disabled state
   */
  @Input()
  get disabled() {
    return this._disabled;
  }

  set disabled(val: boolean) {
    this._disabled = isTrueProperty(val);
  }
  /**
   * Style class
   * @type {string}
   */
  @Input() styleClass: string;
  /**
   * @input {string} Instructional text that shows before the input has a value.
   */
  @Input() placeholder: string = '';
  /**
   * @input {string} Set the input's autocomplete property. Values: `"on"`, `"off"`. Default `"off"`.
   */
  @Input() autocomplete: string = 'off';
  /**
   * Show error text
   * @type {string}
   */
  @Input() errorMessage: boolean = false;
  /**
   * Other text custom
   * @type {string}
   */
  @Input() errorMessageCustom = {};
  /**
   * Validators function
   *
   * @type {null}
   */
  @Input() customValidatorFn: ValidatorFunction = null;
  /**
   * Очистка при блокировке
   * @type {boolean}
   */
  @Input() isClearOnDisable = false;
  /**
   * Events
   * @type {EventEmitter<any>}
   */
  @Output() onChange = new EventEmitter();
  @Output() onFocus = new EventEmitter();
  @Output() onBlur = new EventEmitter();
  @Output() onEnter = new EventEmitter();

  /**
   * уведомление об изменении значения подписчиков ValueAccessor/Base (для вызова валидации текущего компонента и др.)
   * @param $event
   */
  change($event) {
    this.callChanged($event);
    // уведомление об изменении значения внешних подписчиков текущего компонента
    this.onChange.emit($event);
  }

  /**
   * Event input
   */
  public input($event: UIEvent) {
    // this.value = ev.target.value;
  }

  /**
   * Event blur
   */
  public blur($event: UIEvent) {
    this._focused = false;
    // уведомление об изменении значения подписчиков ValueAccessor/Base (для вызова валидации текущего компонента и др.)
    // (требуется дополнительное из-за некоторых сторонних директив, например textMask)
    this.callChanged(this.value);
    // уведомление о потере фокуса внешних подписчиков текущего компонента
    this.onBlur.emit();
  }

  /**
   * Event focus
   */
  public focus($event: UIEvent) {
    this._focused = true;
    this.onFocus.emit($event);
  }

  /**
   * Event keyup.enter
   */
  public enter($event: UIEvent) {
    this.onEnter.emit($event);
  }

  /**
   * Event onSelectEv
   */
  public selectEv($event) {
    this.writeValue($event);
    // вызов события изменения значения
    // (поскольку событие onSelectEv является внешним и не приводит к срабатыванию ngModelChange в шаблоне на input)
    this.onChange.emit($event);
  }

  /**
   * Событие изменения Angular
   * @param {SimpleChanges} changes
   */
  ngOnChanges(changes: SimpleChanges) {
    if (this.isClearOnDisable) {
      // Проверка свойства disabled
      const disable: boolean = changes && changes.disabled && changes.disabled.currentValue;
      if (disable) {
        this.value = '';
      }
    }
  }

  /**
   * Clear value
   */
  clearTextInput() {
    this.value = '';
  }

  /**
   * Есть значение?
   */
  hasValue(): boolean {
    const val = this.value;
    if (!isPresent(val)) {
      return false;
    }
    if (isArray(val) || isString(val)) {
      return val.length > 0;
    }
    return true;
  }

  /**
   * @hidden
   */
  ngOnDestroy() {
    super.ngOnDestroy();
    this._onDestroy.next();
    this._onDestroy = null;
  }
}
