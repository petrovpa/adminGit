import { Component, forwardRef, Input } from '@angular/core';
import { InputFieldComponent } from '../input-field/input-field.component';
import { NG_VALIDATORS, NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
  selector: 'input-number',
  template: `
  <span class="form-control__container">
    <span class="form-control__number">
      <span class="form-control__number-title" *ngIf="postTitle">{{postTitle}}</span>
      <span *ngIf="showContr" (click)="clickMinus()" class="form-control__number-icon"
            [ngClass]="{'form-control__number_disabled': minValueCheck}">
          <i class="icon-minus"></i>
      </span>

      <input #numberInput="ngModel" class="form-control"
             type="text"
             [id]="id"
             [name]="name"
             [(ngModel)]="value"
             [attr.minlength]="minLength"
             [attr.maxlength]="maxLength"
             [attr.step]="step"
             [minNumber]="minNumber"
             [maxNumber]="maxNumber"
             onlyNum
             [inputFilter]="filter"
             [attr.pattern]="pattern"
             [attr.autocomplete]="autocomplete"
             [placeholder]="placeholder"
             [required]="required"
             [disabled]="disabled"
             [readonly]="readonly"
             [ngClass]="styleClass"
             [customValidatorFn]="customValidatorFn"
             (ngModelChange)="change($event)"
             (input)="input($event)"
             (blur)="blur($event)"
             (focus)="focus($event)"
             (keyup.enter)="enter($event)">

      <span class="form-control__number-title form-control__number-title_last" *ngIf="lastTitle">{{lastTitle}}</span>
      <span *ngIf="showContr" (click)="clickPlus()" class="form-control__number-icon"
            [ngClass]="{'form-control__number_disabled': maxValueCheck}">
          <i class="icon-plus"></i>
      </span>
    </span>
   <validation-message *ngIf="errorMessage" [control]="numberInput"
                       [customMessage]="errorMessageCustom"></validation-message>
  </span>
  `,
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => InputNumberComponent),
    multi: true,
  }, {
    // для возможности корректно реализовать интерфейс Validator
    provide: NG_VALIDATORS,
    useExisting: forwardRef(() => InputNumberComponent),
    multi: true,
  }]
})
export class InputNumberComponent extends InputFieldComponent {
  /**
   * @input {any} Шаг увеличения значения
   */
  @Input() step: number = 1;
  /**
   * @input {any} Минимальное значение
   */
  @Input() minNumber: number | string = null;
  /**
   * @input {any} Максимальное значение
   */
  @Input() maxNumber: number | string = null;
  /**
   * Кнопки увеличения, уменьшения значения
   */
  @Input() postTitle: string;
  @Input() lastTitle: string;
  @Input() showContr: boolean;

  /**
   * This is minimal value?
   *
   * @returns {boolean}
   */
  get minValueCheck(): boolean {
    let result: boolean = true;
    if (this.value != undefined) {
      let inVal: number = Number.parseInt(this.value.toString());
      result = (this.minNumber != null) && (this.minNumber >= inVal);
    }
    return result;
  }

  /**
   * This is max value?
   *
   * @returns {boolean}
   */
  get maxValueCheck(): boolean {
    let result: boolean = true;
    if (this.value != undefined) {
      let inVal: number = Number.parseInt(this.value.toString());
      result = (this.maxNumber != null) && (this.maxNumber <= inVal);
    }
    return result;
  }

  /**
   * Increment
   */
  private clickPlus() {
    if (!this.value) {
      this.value = (this.minNumber ? this.minNumber : 0).toString();
    }
    let inVal: number = Number.parseInt(this.value);
    if (inVal < this.maxNumber) {
      inVal += this.step;
    }
    this.value = inVal.toString();
    this.change(this.value);
  }

  /**
   * Decrement
   */
  private clickMinus() {
    if (!this.value) {
      const val = (this.minNumber ? this.minNumber : 0);
      this.value = val.toString();
    }
    let inVal: number = Number.parseInt(this.value);
    if (inVal > this.minNumber) {
      inVal -= this.step;
    }
    this.value = inVal.toString();
    this.change(this.value);
  }
}
