import {
  Component,
  Optional,
  Inject,
  Input,
  ViewChild, EventEmitter, forwardRef, Output, OnInit
} from '@angular/core';

import {
  NgModel,
  NG_VALUE_ACCESSOR,
  NG_VALIDATORS,
  NG_ASYNC_VALIDATORS, FormControl,
} from '@angular/forms';

import { ElementBase } from '../base';

export const RADIOBUTTON_VALUE_ACCESSOR: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => RadioButtonComponent),
  multi: true
};

@Component({
  selector: 'radio-button',
  template: `
  <div class="form-check" [ngClass]="styleClass">
    <span class="form-control__container">
      <input type="radio"
             class="form-check-input"
             [attr.id]="inputId"
             [name]="name"
             [(ngModel)]="value"
             [value]="itemValue"
             [attr.disabled]="disabled?'':null"
             [required]="required"
             [checked]="isSelect()"
             (change)="changeValue(value)">
    <label *ngIf="label"
           [attr.for]="inputId"><span class="form-check-text">{{label}}</span></label>
    </span>
  </div>
  `,
  providers: [RADIOBUTTON_VALUE_ACCESSOR],
})
export class RadioButtonComponent extends ElementBase<any> implements OnInit {
  private checked;

  /**
   * Название
   */
  @Input() label: string;
  /**
   * Значение
   */
  @Input() itemValue: any;
  /**
   * Имя поля
   */
  @Input() name: string;
  /**
   * Идентифкатор поля
   */
  @Input() inputId: string;
  /**
   * Блокировка
   * @type {boolean}
   */
  @Input() disabled: boolean = false;
  /**
   * Обязательность
   * @type {boolean}
   */
  @Input() required: boolean = false;
  /**
   * Класс стиля
   */
  @Input() styleClass: string;

  // Models
  @ViewChild(NgModel) model: NgModel;
  @Input() formControl: FormControl;

  @Output() onChange: EventEmitter<any> = new EventEmitter();

  get value(): any {
    return this.innerValue;
  }

  set value(value: any) {
    if (this.innerValue !== value) {
      this.innerValue = value;
      this.callChanged(value)
    }
  }

  constructor( @Optional() @Inject(NG_VALIDATORS) validatorList: Array<any>,
    @Optional() @Inject(NG_ASYNC_VALIDATORS) asyncValidatorList: Array<any>) {
    super(validatorList, asyncValidatorList);
  }

  ngOnInit() {
    if (!this.name) {
      this.name = 'radio-' + new Date().getMilliseconds().toString();
    }

    if (!this.inputId) {
      this.inputId = this.name + '-id-' + this.itemValue;
    }

    this.checked = this.isSelect();
  }

  /**
   * Выбран?
   * @returns {boolean}
   */
  isSelect() {
    return this.value === this.itemValue;
  }

  /**
   * Изменение значения
   * @param value
   */
  changeValue(value: any) {
    this.checked = this.isSelect();

    this.onChange.emit(value);
  }
}
