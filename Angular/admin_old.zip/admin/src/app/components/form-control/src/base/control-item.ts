import { ElementRef, Input, Renderer2 } from '@angular/core';

export class ControlItem {
  static ids: number = -1;

  /** @hidden */
  _theme: string;

  /** @hidden */
  _elementRef: ElementRef;

  /** @hidden */
  _renderer: Renderer2;

  /** @hidden */
  _color: string;

  /** @hidden */
  _componentName: string;

  /**
   * @input {string} The color to use from your Sass `$colors` map.
   * Default options are: `"primary"`, `"secondary"`, `"danger"`, `"success"`, and `"info"`.
   */
  @Input()
  set color(val: string) {
    this._setColor(val);
  }

  get color(): string {
    return this._color;
  }

  /**
   * @input {string} The mode determines which platform styles to use.
   * Possible values are: `"default"` and etc
   */
  @Input()
  set theme(val: string) {
    this._setTheme(val);
  }

  get theme(): string {
    return this._theme;
  }

  constructor(elementRef: ElementRef, renderer: Renderer2, componentName?: string) {
    this._elementRef = elementRef;
    this._renderer = renderer;
    this._componentName = componentName;
  }

  setElementClass(className: string, isAdd: boolean) {
    if (isAdd) {
      this._renderer.addClass(this._elementRef.nativeElement, className);
    } else {
      this._renderer.removeClass(this._elementRef.nativeElement, className);
    }
  }

  setElementAttribute(attributeName: string, attributeValue: any) {
    this._renderer.setAttribute(this._elementRef.nativeElement, attributeName, attributeValue);
  }

  setElementStyle(property: string, value: string) {
    this._renderer.setStyle(this._elementRef.nativeElement, property, value);
  }

  /** @hidden */
  _setColor(newColor: string, componentName?: string) {
    if (componentName) {
      // This is needed for the item-radio
      this._componentName = componentName;
    }
    if (this._color) {
      this.setElementClass(`form-control_${this._theme}-${this._color}`, false);
    }
    if (newColor) {
      this.setElementClass(`form-control_${this._theme}-${newColor}`, true);
      this._color = newColor;
    }
  }

  /** @hidden */
  _setTheme(newTheme: string) {
    if (this._theme) {
      this.setElementClass(`form-control_${this._theme}`, false);
    }
    if (newTheme) {
      this.setElementClass(`form-control_${newTheme}`, true);
    }
  }

  /** @hidden */
  _setComponentName() {
    this.setElementClass(this._componentName, true);
  }

  /** @hidden */
  getElementRef(): ElementRef {
    return this._elementRef;
  }

  /** @hidden */
  getNativeElement(): any {
    return this._elementRef.nativeElement;
  }
}
