import { ControlValueAccessor, NgControl } from '@angular/forms';
import { AfterContentInit, ElementRef, EventEmitter, Input, OnDestroy, Output, Renderer2 } from '@angular/core';
import { ControlItem } from './control-item';
import { TimeoutDebouncer } from '../utils/debouncer';
import { deepCopy, isArray, isPresent, isString, isTrueProperty, isUndefined } from '../utils/utils';

export class ControlInputValueBase<T> extends ControlItem {
  _id: string;
  disabled: boolean;
  value: T;
}

export class ControlInputValueAccessor<T> extends ControlInputValueBase<T> implements ControlValueAccessor, AfterContentInit, OnDestroy {
  _value: T;
  _onChanged: Function;
  _onTouched: Function;
  _isFocus: boolean = false;
  _disabled: boolean = false;
  _debouncer: TimeoutDebouncer = new TimeoutDebouncer(0);
  _init: boolean = false;
  _initModel: boolean = false;

  _id: string;

  protected changed = [];
  protected touched = [];

  /**
   * Events
   * @type {"events".internal.EventEmitter}
   */
  @Output() onBlur: EventEmitter<ControlInputValueAccessor<T>> = new EventEmitter();
  @Output() onChange: EventEmitter<ControlInputValueAccessor<T>> = new EventEmitter();
  @Output() onEnter: EventEmitter<ControlInputValueAccessor<T>> = new EventEmitter();
  @Output() onFocus: EventEmitter<ControlInputValueAccessor<T>> = new EventEmitter();
  @Output() onInput: EventEmitter<ControlInputValueAccessor<T>> = new EventEmitter();
  @Output() onSelectEv: EventEmitter<ControlInputValueAccessor<T>> = new EventEmitter();

  /**
   * @input {boolean} If true, the user cannot interact with this element.
   */
  @Input()
  get disabled(): boolean {
    return this._disabled;
  }

  set disabled(val: boolean) {
    this.setDisabledState(val);
  }

  constructor(elementRef: ElementRef,
              renderer: Renderer2,
              name: string,
              private _defaultValue: T,
              public _item: ControlItem,
              public _ngControl: NgControl) {
    super(elementRef, renderer, name);
    this._value = deepCopy(this._defaultValue);

    if (name) {
      this._id = name + '-' + (++ControlItem.ids);
    }

    // If the user passed a ngControl we need to set the valueAccessor
    if (_ngControl) {
      _ngControl.valueAccessor = this;
    }
  }

  get value(): T {
    return this._value;
  }

  set value(val: T) {
    if (this._writeValue(val)) {
      this.onChangeControl();
      this._fireControlChange();
    }
  }

  // 1. Updates the value
  // 2. Calls _inputUpdated()
  // 3. Dispatch onChange events
  setValue(val: any) {
    this.value = val;
  }

  /**
   * @hidden
   */
  setDisabledState(isDisabled: boolean) {
    this._disabled = isDisabled = isTrueProperty(isDisabled);
    if (this._item) {
      this._item.setElementClass(`form-control_disabled`, isDisabled);
    }
  }

  /**
   * @hidden
   */
  writeValue(val: any) {
    if (this._writeValue(val)) {
      if (this._initModel) {
        this._fireControlChange();
      } else if (this._init) {
        // ngModel fires the first time too late, we need to skip the first ngModel update
        this._initModel = true;
      }
    }

  }

  /**
   * @hidden
   */
  _writeValue(val: any): boolean {
    if (isUndefined(val)) {
      return false;
    }
    const normalized = (val === null)
      ? deepCopy(this._defaultValue)
      : this._inputNormalize(val);

    const notUpdate = isUndefined(normalized) || !this._inputShouldChange(normalized);
    if (notUpdate) {
      return false;
    }

    // console.debug('value changed:', normalized, this);
    this._value = normalized;
    if (this._init) {
      this._inputUpdated();
    }
    return true;
  }

  /**
   * @hidden
   */
  _fireControlChange() {
    if (this._init) {
      this._debouncer.debounce(() => {
        this.onChange.emit(this._inputChangeEvent());
        this._initModel = true;
      });
    }
  }

  /**
   * @hidden
   */
  registerOnChange(fn: Function) {
    this._onChanged = fn;
  }

  /**
   * @hidden
   */
  registerOnTouched(fn: any) {
    this._onTouched = fn;
  }

  callTouched() {
    this.touched.forEach(f => f());
  }

  callChanged(value: T) {
    this.changed.forEach(f => f(value));
  }

  /**
   * @hidden
   */
  _initialize() {
    if (this._init) {
      return;
    }
    this._init = true;
    if (isPresent(this._value)) {
      this._inputUpdated();
    }
  }

  /**
   * @hidden
   */
  _fireFocus() {
    if (this._isFocus) {
      return;
    }
    this._setFocus(true);
    this.onFocus.emit(this);
  }

  /**
   * @hidden
   */
  _fireBlur() {
    if (!this._isFocus) {
      return;
    }

    this._setFocus(false);
    this._fireTouched();
    this.onBlur.emit(this);
  }

  /**
   * @hidden
   */
  _fireTouched() {
    if (this._onTouched) {
      this._onTouched();
    }
  }

  /**
   * @hidden
   */
  _fireEnter() {
    this.onEnter.emit(this);
  }

  /**
   * @hidden
   */
  private _setFocus(isFocused: boolean) {
    this._isFocus = isFocused;
    const item = this._item;
    if (item) {
      item.setElementClass('form-control_has-focus', isFocused);
    }
    this._inputUpdated();
  }

  /**
   * @hidden
   */
  private onChangeControl() {
    if (this._onChanged) {
      this._onChanged(this._inputNgModelEvent());
    }
  }

  /**
   * @hidden
   */
  isFocus(): boolean {
    return this._isFocus;
  }

  /**
   * @hidden
   */
  hasValue(): boolean {
    const val = this._value;
    if (!isPresent(val)) {
      return false;
    }
    if (isArray(val) || isString(val)) {
      return val.length > 0;
    }
    return true;
  }

  /**
   * @hidden
   */
  focusNext() {
    // TODO: next focus form element
  }

  /**
   * @hidden
   */
  ngOnDestroy() {
    this._init = false;
  }

  /**
   * @hidden
   */
  ngAfterContentInit() {
    this._initialize();
  }

  /**
   * @hidden
   */
  initFocus() {
    const elem = this._elementRef.nativeElement.querySelector('button');
    if (elem) {
      elem.focus();
    }
  }

  /**
   * @hidden
   */
  _inputNormalize(val: any): T {
    return val;
  }

  /**
   * @hidden
   */
  _inputShouldChange(val: T): boolean {
    return this._value !== val;
  }

  /**
   * @hidden
   */
  _inputChangeEvent(): any {
    return this;
  }

  /**
   * @hidden
   */
  _inputNgModelEvent(): any {
    return this._value;
  }

  /**
   * @hidden
   */
  _inputUpdated() {
    const item = this._item;
    if (item) {
      setControlCss(item, this._ngControl);
      let hasValue = this.hasValue();
      item.setElementClass('form-control_has-value', hasValue);
    }
  }
}

function setControlCss(element: ControlItem, control: NgControl) {
  if (!control) {
    return;
  }
  element.setElementClass('ng-untouched', control.untouched);
  element.setElementClass('ng-touched', control.touched);
  element.setElementClass('ng-pristine', control.pristine);
  element.setElementClass('ng-dirty', control.dirty);
  element.setElementClass('ng-valid', control.valid);
  element.setElementClass('ng-invalid', !control.valid);
}
