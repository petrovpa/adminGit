import { Component, forwardRef, Input } from '@angular/core';
import { NG_VALIDATORS, NG_VALUE_ACCESSOR } from '@angular/forms';
import { ControlInputBase } from '../base';

@Component({
  selector: 'input-field',
  template: `
  <span class="form-control__container">
    <input #textInput="ngModel" class="form-control"
           [type]="_type"
           [id]="id"
           [name]="name"
           [(ngModel)]="value"
           [attr.minlength]="minLength"
           [attr.maxlength]="maxLength"
           [pattern]="pattern"
           [attr.autocomplete]="autocomplete"
           [placeholder]="placeholder"
           [inputFilter]="filter"
           [required]="required"
           [disabled]="disabled"
           [readonly]="readonly"
           [ngClass]="styleClass"
           [customValidatorFn]="customValidatorFn"
           (ngModelChange)="change($event)"
           (input)="input($event)"
           (blur)="blur($event)"
           (focus)="focus($event)"
           (keydown)="onKeydown($event)">
    <validation-message *ngIf="errorMessage" [control]="textInput" [customMessage]="errorMessageCustom"></validation-message>
  </span>
  `,
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => InputFieldComponent),
    multi: true,
  }, {
    // для возможности корректно реализовать интерфейс Validator
    provide: NG_VALIDATORS,
    useExisting: forwardRef(() => InputFieldComponent),
    multi: true,
  }]
  // encapsulation: ViewEncapsulation.None,
  // changeDetection: ChangeDetectionStrategy.OnPush,
  // inputs: ['value']
})
export class InputFieldComponent extends ControlInputBase {
  _clearOnEdit: boolean = false;
  _didBlurAfterEdit: boolean;
  _type: string = 'text';

  /**
   * @input {string} The type of control to display. The default type is text.
   * Possible values are: `"text"`, `"password"`, `"custom-email"`, `"number"`, `"search"`, `"tel"`, or `"url"`.
   */
  @Input()
  get type() {
    return this._type;
  }

  set type(val: any) {
    this._type = val;
  }

  /**
   * @input {any} The minimum length
   */
  @Input() minLength: number | string = null;
  /**
   * @input {any} The maximum length
   */
  @Input() maxLength: number | string = null;
  /**
   * An HTML form with an input field that can contain only three letters (no numbers or special characters):
   * pattern="[A-Za-z]{3}"
   * @type {null}
   */
  @Input() pattern: number | string = null;
  /**
   * @input {boolean} If true, the value will be cleared after focus upon edit.
   * Defaults to `true` when `type` is `"password"`, `false` for all other types.
   */
  @Input()
  get clearOnEdit() {
    return this._clearOnEdit;
  }

  set clearOnEdit(val: boolean) {
    this._clearOnEdit = val;
  }
  /**
   * Filter data
   */
  @Input() filter: any;
  /**
  * Trims an input value, and sets it to the model and element.
  *
  * @param {string} value - input value
  */
  private trimValue(value: string): void {
    if (value && value.trim) {
      this.value = value.trim();
    }
  }
  /**
   * @hidden
   */
  onKeydown($event: any) {
    if ($event && this._clearOnEdit) {
      this.checkClearOnEdit($event.target.value);
    }
  }
  /**
   * Check if we need to clear the text input if clearOnEdit is enabled
   * @hidden
   */
  checkClearOnEdit(_: string) {
    if (!this._clearOnEdit) {
      return;
    }

    // Did the input value change after it was blurred and edited?
    if (this._didBlurAfterEdit && this.hasValue()) {
      // Clear the input
      this.clearTextInput();
    }

    // Reset the flag
    this._didBlurAfterEdit = false;
  }

  // ngOnInit() {
  //   // console.log('ngOnInit this', this);
  // }
  //
  // ngAfterViewInit() {
  //   // console.log('ngAfterViewInit this', this)
  // }
}
