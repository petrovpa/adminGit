import { Component, forwardRef, Input } from '@angular/core';
import { NG_VALIDATORS, NG_VALUE_ACCESSOR } from '@angular/forms';
import { InputFieldComponent } from '../input-field/input-field.component';

@Component({
  selector: 'input-mask',
  template: `
  <span class="form-control__container">
    <input #textInput="ngModel" class="form-control"
           [type]="_type"
           [id]="id"
           [name]="name"
           [(ngModel)]="value"
           [textMask]="{mask: mask, guide: guideMask, placeholder: maskPlaceholder}"
           [attr.minlength]="minLength"
           [attr.maxlength]="maxLength"
           [pattern]="pattern"
           [attr.autocomplete]="autocomplete"
           [placeholder]="placeholder"
           [required]="required"
           [disabled]="disabled"
           [readonly]="readonly"
           [ngClass]="styleClass"
           [customValidatorFn]="customValidatorFn"
           (ngModelChange)="change($event)"
           (input)="input($event)"
           (blur)="blur($event)"
           (focus)="focus($event)"
           (keydown)="onKeydown($event)">
    <validation-message *ngIf="errorMessage" [control]="textInput" [customMessage]="errorMessageCustom"></validation-message>
  </span>
  `,
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => InputMaskComponent),
    multi: true,
  }, {
    // для возможности корректно реализовать интерфейс Validator
    provide: NG_VALIDATORS,
    useExisting: forwardRef(() => InputMaskComponent),
    multi: true,
  }]
})
export class InputMaskComponent extends InputFieldComponent {
  /**
   * Параметры маски
   */
  @Input() mask: any[];
  @Input() maskPlaceholder: string;
  @Input() guideMask = true;
}
