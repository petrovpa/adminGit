import { NgModel, Validator, AbstractControl, ValidationErrors } from '@angular/forms';
import { ValueAccessorBase } from './value-accessor';
import { AfterViewInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';

export abstract class ValueAccessorValidatorBase<T> extends ValueAccessorBase<T> implements Validator, AfterViewInit, OnDestroy {

  protected abstract model: NgModel;
  protected typeSource = 'ValueAccessorValidatorBase';

  private statusChangesSubs: any = null;

  private get logPrefix() {
    const modelName = this && this.model && this.model.name;
    return '[' + this.typeSource + '] (' + modelName + ') ';
  }

  protected log(objName: string, obj: any) {
    console.log(this.logPrefix + objName + ':', obj);
  }

  protected err(errorStr: string) {
    console.warn(this.logPrefix + 'error: ' + errorStr);
  }

  public validate(control: AbstractControl): ValidationErrors | null {
    return null || (this.model && this.model.control && this.model.control.errors);
  }

  private unsubscribe(subs: Subscription) {
    if (subs) {
      subs.unsubscribe();
    }
  }

  ngAfterViewInit() {
    if (this.model && this.model.control) {
      this.unsubscribe(this.statusChangesSubs);
      this.statusChangesSubs = this.model.control.statusChanges.subscribe((event: any) => {
        setTimeout(() => {
          this.callChanged(this.value);
        });
      });
    } else {
      this.err('Unable to get this.model.control on ngAfterViewInit!');
    }

    // уведомление об изменении значения подписчиков ValueAccessor/Base (для вызова валидации текущего компонента и др.)
    // требуется для валидации после установки значений вложенного контрола (из-за некоторых сторонних директив, например textMask)
    this.callChanged(this.value);
  }

  ngOnDestroy() {
    this.unsubscribe(this.statusChangesSubs);
  }
}
