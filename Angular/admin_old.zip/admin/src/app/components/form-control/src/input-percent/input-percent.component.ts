import { Component, forwardRef, Input } from '@angular/core';
import { InputFieldComponent } from '../input-field/input-field.component';
import { NG_VALIDATORS, NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
  selector: 'input-percent',
  template: `
  <span class="form-control__container">
      <input #textInput="ngModel" class="form-control"
             type="text"
             [id]="id"
             [name]="name"
             [(ngModel)]="value"
             percent
             [attr.step]="step"
             [minNumber]="minNumber"
             [maxNumber]="maxNumber"
             [placeholder]="placeholder"
             [attr.autocomplete]="autocomplete"
             [required]="required"
             [disabled]="disabled"
             [ngClass]="styleClass"
             [customValidatorFn]="customValidatorFn"
             (ngModelChange)="change($event)"
             (blur)="blur($event)"
             (focus)="focus($event)"
             (keyup.enter)="enter($event)">
      <validation-message *ngIf="errorMessage" [control]="textInput" [customMessage]="errorMessageCustom"></validation-message>
  </span>
  `,
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => InputPercentComponent),
    multi: true,
  }, {
    // для возможности корректно реализовать интерфейс Validator
    provide: NG_VALIDATORS,
    useExisting: forwardRef(() => InputPercentComponent),
    multi: true,
  }]
})
export class InputPercentComponent extends InputFieldComponent {
  /**
   * @input {any} Шаг увеличения значения
   */
  @Input() step: number = 1;
  /**
   * @input {any} Минимальное значение
   */
  @Input() minNumber: number | string = null;
  /**
   * @input {any} Максимальное значение
   */
  @Input() maxNumber: number | string = null;
}
