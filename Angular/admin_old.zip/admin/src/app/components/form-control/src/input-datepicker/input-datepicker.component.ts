import { Component, ElementRef, EventEmitter, forwardRef, Input, Output, ViewChild } from '@angular/core';
import { InputFieldComponent } from '../input-field/input-field.component';
import { NG_VALIDATORS, NG_VALUE_ACCESSOR } from '@angular/forms';
import * as moment from 'moment';
import { DATE_FORMAT } from '@frontend/datepicker';

@Component({
  selector: 'input-datepicker',
  template: `
  <span class="form-control__container">
      <span class="form-control__icon">
        <input #dateInput="ngModel" #datePicker class="form-control"
               type="text"
               [id]="id"
               [name]="name"
               [(ngModel)]="value"
               [placeholder]="placeholder || 'дд.мм.гггг'"
               [attr.pattern]="datePattern"
               [textMask]="{mask: dateMask}"
               pikaday
               [datepickerContainerId]="datePickerContainer()"
               [minDate]="minDate"
               [maxDate]="maxDate"
               [minYear]="minYear"
               [maxYear]="maxYear"
               [minAge]="minAge"
               [maxAge]="maxAge"
               [minYearDelta]="minYearDelta"
               [maxYearDelta]="maxYearDelta"
               [attr.autocomplete]="autocomplete"
               [required]="required"
               [disabled]="disabled"
               [readonly]="readonly"
               [ngClass]="styleClass"
               [customValidatorFn]="customValidatorFn"
               (input)="input($event)"
               (blur)="blur($event)"
               (focus)="focus($event)"
               (keyup.enter)="enter($event)"
               (onSelectEv)="selectEv($event)"
               (onCorrected)="onCorrected($event)">
              <i class="tick" (click)="toggle()"></i>
      </span>
    <span [id]="datePickerContainer()"></span>
    <validation-message *ngIf="errorMessage" [control]="dateInput"
                        [customMessage]="errorMessageCustom"></validation-message>
    <span class="form-control__alert"><alert-control  [isOpen]="isCorrected" type="danger">Дата не верна. Исправлено.</alert-control></span>
  </span>
  `,
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => InputDatePickerComponent),
    multi: true,
  }, {
    // для возможности корректно реализовать интерфейс Validator
    provide: NG_VALIDATORS,
    useExisting: forwardRef(() => InputDatePickerComponent),
    multi: true,
  }]
})
export class InputDatePickerComponent extends InputFieldComponent {
  // показан ли календарь
  public isShown: boolean = false;

  @ViewChild('datePicker')
  public dateInput: ElementRef;

  /**
   * Маска
   *
   * @type {(RegExp | string)[]}
   */
  @Input() dateMask: any = [/[0-3]/, /\d/, '.', /[0-1]/, /\d/, '.', /[1-2]/, /\d/, /\d/, /\d/];

  /**
   * Ограничение
   * @type {RegExp}
   */
  @Input() datePattern: any = /(0[1-9]|1[0-9]|2[0-9]|3[01]).(0[1-9]|1[012]).[0-9]{4}/;

  /**
   * Минимальные, максимальные значения дат
   */
  @Input() minDate: string;
  @Input() maxDate: string;
  @Input() minYear: number;
  @Input() maxYear: number;
  @Input() minAge: number;
  @Input() maxAge: number;
  @Input() minYearDelta: number;
  @Input() maxYearDelta: number;

  /**
   * Событие
   * @type {EventEmitter<any>}
   */
  @Output() onDateChange = new EventEmitter();

  get value(): any {
    return this.innerValue;
  }

  set value(value: any) {
    if (this.innerValue !== value) {
      this.innerValue = value;
      this.callChanged(value);

      this.onDateChange.emit(value);
    }
  }

  /**
   * Для вывода сообщения о корректности даты
   * @type {boolean}
   */
  public isCorrected: boolean = false;
  public timerAlert;

  // ngOnInit() {
  //   this.change(this.value);
  // }

  /**
   * Контейнер для календаря
   */
  datePickerContainer() {
    return this.id + '_datepicker';
  }

  /**
   * Показ и скрытие календаря по кнопке
   */
  toggle() {
    if (this.isShown) {
      this.dateInput.nativeElement.blur();
    } else {
      this.dateInput.nativeElement.click();
    }

    this.isShown = !this.isShown;
  }

  /**
   * Выбрали поле ввода
   */
  focus($event) {
    this.isShown = true;
    this.onFocus.emit($event);
  }

  /**
   * Ушли с поля ввода
   */
  blur($event) {
    if (this.value) {
      if (!moment(this.value, DATE_FORMAT, true).isValid()) {
        this.onCorrected(true);

        this.value = null;
      }
    }

    this.isShown = false;
    this.onBlur.emit($event);
  }

  /**
   * Дата скорректирована
   * @param {boolean} isCorrected
   */
  onCorrected(isCorrected: boolean) {
    this.isCorrected = isCorrected;

    if (this.timerAlert) {
      clearTimeout(this.timerAlert);
    }

    // скрываем через 5 секунд
    if (this.isCorrected) {
      this.timerAlert = setTimeout(() => {
        this.isCorrected = false;
        clearTimeout(this.timerAlert);
      }, 5000);
    }
  }

  datepickerChange($event) {
    this.change($event);
  }

  /**
   * уведомление об изменении значения подписчиков ValueAccessor/Base (для вызова валидации текущего компонента и др.)
   * @param $event
   */
  // change($event) {
  //   // console.log('datepicker change', $event);
  //
  //   this.callChanged($event);
  //   // уведомление об изменении значения внешних подписчиков текущего компонента
  //   this.onChange.emit($event);
  // }
}
