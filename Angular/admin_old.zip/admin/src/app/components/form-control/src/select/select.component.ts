import { Component, Input, OnInit, AfterViewInit, Output, EventEmitter, forwardRef, ChangeDetectorRef } from '@angular/core';
import { NG_VALIDATORS, NG_VALUE_ACCESSOR } from '@angular/forms';
import { ControlInputBase } from '../base/control-input-base';
import { isPresent, isTrueProperty } from '../utils/utils';
import * as _ from 'lodash';

@Component({
  selector: 'input-select',
  template: `
    <div class="form-control__container">
      <div class="form-control__select">
        <div class="dropdown" dropdown
             [isOpen]="status.isOpen"
             (isOpenChange)="onOpenChange($event)"
             [ngClass]="styleClass"
             [isDisabled]="disabled">
          <div dropdownToggle class="form-control"
               [ngClass]="{'form-control_disabled': disabled}">
            <div class="form-control__value">{{selectItem ? selectItem[nameField] : ''}}&nbsp;</div>
          </div>
          <input type="text" [name]="name" [(ngModel)]="value" hidden>
          <ul *dropdownMenu class="dropdown-menu" role="menu">
            <li class="form-control__icon">
              <i class="tick tick-revert" *ngIf="isOpen"></i>
            </li>
            <li *ngFor="let choice of items; trackBy: trackByFn">
              <a class="dropdown-item" (click)="onSelectEvent(choice)">{{choice[nameField]}}</a>
            </li>
          </ul>
          <span class="form-control__icon">
            <i class="tick" *ngIf="!isOpen" (click)="toggleDropdown($event)"></i>
          </span>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .dropdown > .form-control,
    .dropdown-item {
        cursor: pointer;
    }
  `],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => SelectComponent),
    multi: true,
  }, {
    // для возможности корректно реализовать интерфейс Validator
    provide: NG_VALIDATORS,
    useExisting: forwardRef(() => SelectComponent),
    multi: true,
  }],
})
export class SelectComponent extends ControlInputBase implements OnInit, AfterViewInit {
  /**
   * Имя компонента справочника
   *
   */
  @Input() name: string;

  /**
   * По умоолчанию выбирать первый элемент из списка
   */
  @Input() selectFirstByDefault = true;

  /**
   * Справочник
   *
   * @type {any[]}
   */
  @Input() items: any = [];

  /**
   * Имя поля в справочнике для отображения
   *
   * @type {string}
   */
  @Input() nameField = 'name';

  /**
   * Системное имя поля в справочнике
   *
   * @type {string}
   */
  @Input() sysnameField = 'sysname';

  /**
   * Выбранный элемент
   */
  @Input() selectedItem: {
    key: any,
    item: any,
  };

  /**
   * Заблокировано
   */
  @Input()
  get disabled() {
    return this._disabled || _.isUndefined(this.items) || _.size(this.items) < 2;
  }

  set disabled(val: boolean) {
    this._disabled = isTrueProperty(val);
  }

  /**
   * Выбран элемент
   *
   * @type {EventEmitter<any>}
   */
  @Output() onSelect = new EventEmitter();

  status: { isOpen: boolean } = { isOpen: false };

  // открыт ли список
  isOpen: boolean = false;

  get value(): any {
    return this.innerValue;
  }

  set value(value: any) {
    // выбираем значение из списка
    if (isPresent(value)) {
      const findElem = this.items.find(item => item[this.sysnameField] == value),
            findElemIndex = this.items.findIndex(item => item[this.sysnameField] == value);

      this.selectItem = findElem;
      this.setSelectedItem(findElemIndex, findElem);
    }

    if (this.innerValue !== value) {
      this.innerValue = value;
      this.callChanged(value);
    }
  }

  selectItem;

  constructor(protected ref: ChangeDetectorRef) {
    super();
  }

  /**
   * Инициализация
   */
  ngOnInit() {
    if (this.selectFirstByDefault) {
      // HUCK: change detection not work
      setTimeout(() => this.selectFirst());
      this.selectFirst();
    }
  }

  ngAfterViewInit() {
  }

  trackByFn($index, item) {
    return $index; // or item.id
  }

  /**
   * Установка значение
   *
   * @param selectItem
   */
  setValue(selectItem: any) {
    if (selectItem) {
      this.value = selectItem[this.sysnameField];

      const findElemIndex = this.items.findIndex(item => item[this.sysnameField] == this.value);
      this.setSelectedItem(findElemIndex, selectItem);
    }
  }

  /**
   * Установка объекта с выбранным элементом
   *
   * @param key
   * @param item
   */
  setSelectedItem(key, item) {
    if (this.selectedItem) {
      this.selectedItem.key = key;
      this.selectedItem.item = item;
    }
  }

  /**
   * Выбираем первый элемент
   */
  selectFirst() {
    if (this.value == null) {
      const firstItem = this.items && this.items[0];
      if (firstItem) {
        this.selectItem = firstItem;
        this.setValue(firstItem);
        this.change(this.value);
      }
    }
  }

  /**
   * При выборе элемента справочника
   *
   * @param item
   */
  onSelectEvent(item: any) {
    this.setValue(item);
    this.selectItem = item;
    this.onSelect.emit(this.value);
    this.change(this.value);
  }

  /**
   * уведомление об изменении значения подписчиков ValueAccessor/Base (для вызова валидации текущего компонента и др.)
   * @param event
   */
  change(event: any): void {
    this.callChanged(event);
    // уведомление об изменении значения внешних подписчиков текущего компонента
    this.onChange.emit();
  }

  /**
   * Расскрытие списка
   */
  toggleDropdown($event: MouseEvent) {
    $event.preventDefault();
    $event.stopPropagation();
    this.status.isOpen = !this.status.isOpen;
  }

  /**
   * Событие на раскрытие списка
   */
  onOpenChange(value: boolean) {
    this.isOpen = value;
    this.status.isOpen = value;
  }
}
