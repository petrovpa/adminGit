/** @hidden */
export function isUndefined(val: any): val is undefined {
  return typeof val === 'undefined';
}

/** @hidden */
export function isPresent(val: any): val is any {
  return val !== undefined && val !== null;
}

/** @hidden */
export function isObject(val: any): val is object {
  return typeof val === 'object';
}

/** @hidden */
export function isArray(val: any): val is any[] {
  return Array.isArray(val);
}

/** @hidden */
export function isString(val: any): val is string {
  return typeof val === 'string';
}

/** @hidden */
export function deepCopy(obj: any) {
  return JSON.parse(JSON.stringify(obj));
}

/** @hidden */
export function isTrueProperty(val: any): boolean {
  if (typeof val === 'string') {
    val = val.toLowerCase().trim();
    return (val === 'true' || val === 'on' || val === '');
  }
  return !!val;
}
