import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { ModalDialogComponent } from '@frontend/dialog-modal';
import { GroupModalDialogOptions } from './modal-dialog-group-options.class';
import { NgForm } from '@angular/forms';
import * as _ from 'lodash';
import { RestApiService } from '@app/services/rest-api.service';
import { AngularTree } from '@app/classes/angular-tree.class';
import { Helper } from '@app/classes/helper.class';

@Component({
  selector: 'add-modal-dialog-group',
  templateUrl: './modal-dialog-group.component.html',
  styleUrls: ['./modal-dialog-group.component.scss']
})
export class ModalDialogGroupComponent implements OnInit {

  @ViewChild('dialog') dialog: ModalDialogComponent;
  @Input() options: GroupModalDialogOptions = new GroupModalDialogOptions();

  private _group: any;
  public get group(): any {
    return this._group;
  }
  public set group(value: any) {
    this._group = value;
  }

  private _groupTree: AngularTree[];
  public get groupTree(): AngularTree[] {
    return this._groupTree;
  }
  public set groupTree(value: AngularTree[]) {
    console.log('groupTree ', value);
    this._groupTree = value;
  }

  private _defaultOptionsMap = {
    modalDialogTitle: 'Добавить'
  };

  constructor(private adminService: RestApiService) { }

  ngOnInit() {
    this.getGroupsTree();
    _.forIn(this._defaultOptionsMap, this.initOptionByDefault);
  }

  /**
   * Инициализация опции по умолчанию
   * @param value {any} - значение по умолчанию
   * @param option {string} - имя опции
   */
  private initOptionByDefault = (value: any, option: string) => {
    if (_.isUndefined(this.options[option])) {
      this.options[option] = value;
    }
  }

  /**
   * Получение дерева групп
   */
  private getGroupsTree() {
    return this.adminService.getGroupsTree()
      .subscribe(groupTree => this.groupTree = AngularTree.createNewArray(groupTree));
  }

  /**
   * Обработчик выбора группы
   * @param group {any} - выбранная группа
   */
  private selectGroup(group: any) {
    this.group = group;
  }

}
