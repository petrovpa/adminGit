import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ModalDialogService } from '@frontend/dialog-modal';
@Component({
  selector: 'dropdown-list',
  templateUrl: './dropdown-list.component.html',
  styleUrls: ['./dropdown-list.component.scss']
})
export class DropdownListComponent implements OnInit {

  /**
   * Имя компонента
   *
   */
  @Input() name: string;

  /**
   * Заголовок dropdown
   *
   */
  @Input() dropdownTitle: string;

  /**
   * Заголовок addButton
   *
   */
  @Input() addButtonTitle: string;

  /**
   * Namespace
   *
   */
  @Input() namespace: any = [];

  /**
   * Лист
   *
   * @type {any[]}
   */
  @Input() dropDownList: any = [];

  /**
   * Имя поля в листе для отображения
   *
   * @type {string}
   */
  @Input() nameField: string;

  /**
   * Системное имя поля в листе
   *
   * @type {string}
   */
  @Input() sysnameField: string;

  /**
   * Заблокировано
   */
  @Input() isFormDisabled = false;

  /**
   * Обработчик добавления элемента
   *
   * @type {EventEmitter<any>}
   */
  @Output() onAdd = new EventEmitter();

  /**
   * Обработчик удаления элемента
   *
   * @type {EventEmitter<any>}
   */
  @Output() onDelete = new EventEmitter();

  private selectedItem: any;

  constructor(private dialogService: ModalDialogService) { }

  ngOnInit() {
    if (this.dropDownList.length === 1) {
      this.selectedItem = this.dropDownList[0];
    }
  }

  delete(index) {
    // this.namespace.splice(index, 1);
    const deletedItem = this.namespace[index];
    if (deletedItem) {
      this.onDelete.emit(deletedItem);
    }
  }

  add() {
    if (this.isItemAlreadyAdded()) {
      this.showErrorDialog('Такой элемент уже добавлен');
    } else {
      if (this.selectedItem) {
        this.onAdd.emit(this.selectedItem);
      } else {
        this.showErrorDialog('Не выбран ни один элемент');
      }
    }
  }

  onSelect(event) {
    this.selectedItem = this.dropDownList.find((item) => item[this.sysnameField] === event);
  }

  isItemAlreadyAdded() {
    const element = this.namespace.find((item) => item[this.sysnameField] === this.selectedItem[this.sysnameField]);
    return element ? true : false;
  }

  /**
   * Показываем диалоговое окно
   * @param {string} message
   */
  showErrorDialog(message: string) {
    this.dialogService.alert(message);
  }

}
