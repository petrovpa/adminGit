export class AddModalDialogOptions {
    modalDialogConfig: string;
    modalDialogTitle: string;
    labelTitle: string;
    inputSelectItems: any[];
    inputSelectNameField: string;
    inputSelectSysnameField: string;
    onClickAddButton: Function;
}