import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FormControlModule } from '@app/components/form-control/src/form-control.module';
import { FormControlLabelModule } from '@frontend/form-control-label';
// FIXME: import from package
import { DialogModule } from '@frontend/dialog-modal';
import { AddModalDialogComponent } from './add-modal-dialog.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    FormControlModule,
    FormControlLabelModule,
    DialogModule
  ],
  declarations: [AddModalDialogComponent],
  exports: [AddModalDialogComponent]
})
export class AddModalDialogModule { }
