import { Mappable } from './mappable.class';

export class RequestMappable extends Mappable {
  private _params: string;
  private _sessionid: string;

  constructor(params: any, sessionid: string) {
    super();
    this.params = params;
    this.sessionid = sessionid;
  }

  public get params(): any {
    return this._params;
  }

  public set params(value: any) {
    this._params = value;
  }

  public get sessionid(): string {
    return this._sessionid;
  }

  public set sessionid(value: string) {
    this._sessionid = value;
  }
}
