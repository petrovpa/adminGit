import { Inject, Injectable, InjectionToken } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { SessionService } from '../session/session.service';
import { RequestMappable } from '../classes/request-mappable.class';
import { IRestConfig, RestType } from './rest-config';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/finally';
import 'rxjs/add/observable/throw';

import { EventsService } from '../events/events.service';
import { Logger } from '@frontend/logger';
import { CallExtParams } from '../classes/call-ext-params.class';

// REST конфигурация
export const REST_CONFIG = new InjectionToken<IRestConfig>('REST_CONFIG');

@Injectable()
export class RestService {
  // количество активных запросов
  private countRequest = 0;

  // заголовки для запросов
  private readonly urlencodedHeaders: HttpHeaders;
  private readonly jsonHeaders: HttpHeaders;

  // имя сессии
  private readonly SESSIONID = 'SESSIONID';

  // текст ошибки по умолчанию
  private restError: string = 'При вызове сервиса произошла ошибка!';

  constructor(@Inject(REST_CONFIG) private config: IRestConfig,
    private logger: Logger,
    private eventsService: EventsService,
    private sessionService: SessionService,
    private httpClient: HttpClient) {
    this.urlencodedHeaders = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' });
    this.jsonHeaders = new HttpHeaders({ 'Content-Type': 'application/json; charset=UTF-8' });
  }

  /**
   * Подготовка структуры
   *
   * @param params
   */
  private prepareToCallMap(params: any) {
    const paramsMap: any = {
      obj: {}
    };

    if (params != null) {
      paramsMap.obj = (<any>Object).assign({}, params);
    }

    paramsMap.obj[this.SESSIONID.toLowerCase()] = this.sessionService.sessionId;
    return paramsMap;
  }

  /**
   * Проверка ответа на исключение
   *
   * @param methodName
   * @param error
   * @param showError
   */
  private checkRestError(methodName: string, error: string, showError: boolean) {
    if (error) {
      if (error === 'Время сессии истекло' || error === 'Пользователь не представился') {
        this.sessionService.sessionId = null;
        this.eventsService.publish('request:session expired');
      }

      // отсылаем сообщение об ошибке
      this.requestError(methodName, error, showError);

      return true;
    }

    return false;
  }

  /**
   * Вызов сервиса
   *
   * @param {string} methodName
   * @param {string} restPath
   * @param body
   * @param mapResponse
   * @param callParams
   *    hideLoader - показывать ли загрузку
   *    showError - показывать ли сообщение об ошибке, модальное окно
   * @returns {Observable<any>}
   */
  private call(methodName: string, restPath: string, headers: any, body: any, mapResponse: Function, callParams: CallExtParams = <CallExtParams>{}): any {
    // показывать ли сообщение об ошибке
    let showError = callParams.hasOwnProperty('showError') ? callParams.showError : this.config.showError;

    // отсылаем событие о начале запроса
    if (!callParams.hideLoader) {
      this.countRequest++;
      this.eventsService.publish('request:start', this.countRequest);
    }

    this.logger.info('doCall', methodName);
    this.logger.info('body', body);

    const url = restPath + methodName;

    const options = {
      headers: headers,
      body: body,
      withCredentials: true
    };

    return this.httpClient.request('POST', url, options)
      .map((response: any) => mapResponse(response, methodName, showError))
      .catch(error => this.handleError(methodName, error, showError))
      .finally(() => {
        if (!callParams.hideLoader) {
          this.countRequest--;
          // отсылаем событие что запрос завершен
          this.eventsService.publish('request:finished', this.countRequest);
        }
      });
  }

  /**
   * JSON обработка ответа сервера
   * @param response - ответ сервера
   */
  private jsonMapResponse = (response: any, methodName: string, showError: boolean): any => {
    const result = JSON.parse(JSON.stringify(response));
    // let resultObj = null;
    // if (result) {
    //   if (result.Status !== 'ERROR') {
    //     resultObj = result.Result;
    //   } else {
    //     const message = result.Error || this.restError;
    //     resultObj = {
    //       Error: message
    //     };
    //   }
    // }

    // return resultObj;
    let error;

    if (result) {
      //error = result.Error || (result.Result && result.Result.Error);
      if (result.Status === 'ERROR') {
        error = result.Error || this.restError;
      }

      return this.processResponce(methodName, error, showError, result);
    }
    else {
      return null;
    }
  }

  private processResponce(methodName, error, showError, result) {
    // анализ ошибки
    if (!this.checkRestError(methodName, error, showError)) {

      // сессия может быть в разных местах!
      if (result.hasOwnProperty(this.SESSIONID)) {
        this.sessionService.sessionId = result[this.SESSIONID];
      } else {
        if (result['Result'] && result['Result'].hasOwnProperty(this.SESSIONID)) {
          this.sessionService.sessionId = result['Result'][this.SESSIONID];
        }
      }

      return result['Result'];
    } else {
      // возвращаем ошибку
      return {
        Error: error
      };
    }
  }

  /**
   * URLENCODED обработка ответа сервера
   * @param response - ответ сервера
   * @param methodName - имя вызванного метода сервера
   * @param showError - признак необходимости показа окна с ошибкой
   */
  private urlencodedMapResponse = (response: any, methodName: string, showError: boolean): any => {
    if (response.hasOwnProperty('resultJson')) {
      const result = JSON.parse(response['resultJson']);

      // получаем ошибку
      let error = result.Error || (result.Result && result.Result.Error);
      if (result.Status === 'ERROR') {
        error = result.Reason ? result.Reason : this.restError;
      }

      return this.processResponce(methodName, error, showError, result);
    }
  }

  /**
   * JSON вызов метода сервера
   *
   * @param {string} methodName - имя метода
   * @param {string} restPath - путь до rest сервиса
   * @param params - входные параметры вызова
   * @param callParams - расширенные параметры вызова
   *    hideLoader - показывать ли загрузку
   *    showError - показывать ли сообщение об ошибке, модальное окно
   * @returns {Observable<any>}
   */
  private jsonCall(methodName: string, restPath: string, params: any, callParams: CallExtParams = <CallExtParams>{}): any {
    const body: RequestMappable = new RequestMappable(params, this.sessionService.sessionId);
    return this.call(methodName, restPath, this.jsonHeaders, body.toJson(), this.jsonMapResponse, callParams);
  }

  /**
   * URLENCODED вызов метода сервера
   *
   * @param {string} methodName - имя метода
   * @param {string} restPath - путь до rest сервиса
   * @param params - входные параметры вызова
   * @param callParams - расширенные параметры вызова
   *    hideLoader - показывать ли загрузку
   *    showError - показывать ли сообщение об ошибке, модальное окно
   * @returns {Observable<any>}
   */
  private urlencodedCall(methodName: string, restPath: string, params: any, callParams: CallExtParams = <CallExtParams>{}): any {
    const body = (!callParams.isStrictParams) ?
      new HttpParams().set('params', JSON.stringify(this.prepareToCallMap(params))) :
      new HttpParams({ fromObject: params });
    return this.call(methodName, restPath, this.urlencodedHeaders, body, this.urlencodedMapResponse, callParams);
  }

  /**
   * Вызов сервиса B2B
   *
   * @param {string} methodName
   * @param params
   * @param callParams
   *    hideLoader - показывать ли загрузку
   *    showError - показывать ли сообщение об ошибке, модальное окно
   * @returns {Observable<any>}
   */
  b2bCall(methodName: string, params: any, callParams: CallExtParams = <CallExtParams>{}): any {
    return this.urlencodedCall(methodName, this.config.restPath, params, callParams);
  }

  /**
   * Вызов сервиса ADMRESTWS
   *
   * @param {string} methodName
   * @param params
   * @param callParams
   *    hideLoader - показывать ли загрузку
   *    showError - показывать ли сообщение об ошибке, модальное окно
   * @returns {Observable<any>}
   */
  adminCall(methodName: string, params: any, callParams: CallExtParams = <CallExtParams>{}): any {
    return this.jsonCall(methodName, this.config.restPath, params, callParams);
  }

  /**
   * Вызов сервиса pa2ws
   *
   * @param {string} methodName
   * @param params
   * @param callParams
   * @returns {any}
   */
  pa2wsCall(methodName: string, params: any, callParams: any = {}): any {
    return this.jsonCall(methodName, this.config.restPath, params, callParams);
  }

  /**
   * Общий вызов
   * @param {string} methodName
   * @param params
   * @param {RestCallExtParams} callParams
   */
  doCall(methodName: string, params: any, callParams: CallExtParams = <CallExtParams>{}) {
    switch (this.config.restType) {
      case RestType.URLENCODED:
        return this.urlencodedCall(methodName, this.config.restPath, params, callParams);
      case RestType.JSON:
        return this.jsonCall(methodName, this.config.restPath, params, callParams);
    }
  }

  /**
   * Обрабортка ошибки http запроса
   *
   * @param methodName
   * @param error
   * @param showError
   * @returns {any}
   */
  private handleError(methodName: string, error: any, showError: boolean) {
    let message;
    if (error instanceof HttpErrorResponse) {
      message = error['message'] || this.restError;
      this.requestError(methodName, message, showError);
      return Observable.throw({
        Error: message
      });
    }

    message = error || this.restError;
    this.requestError(methodName, message, showError);
    return Observable.throw({
      Error: message
    });
  }

  /**
   * Обработка сообщения об ошибке
   * @param methodName
   * @param message
   * @param showError
   */
  private requestError(methodName: string, message: string, showError: boolean = false) {
    this.logger.error('doCall: ' + methodName, message);
    // отсылаем событие об ошибке
    if (showError) {
      this.eventsService.publish('request:error', message);
    }
  }
}
