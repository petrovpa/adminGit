import { Injectable } from '@angular/core';
import { SessionStorage } from 'ngx-webstorage';

@Injectable()
export class SessionService {
  /**
   * Cессия
   */
  @SessionStorage('sessionId')
  public sessionId: string;

  /**
   * Фио
   */
  @SessionStorage('userFIO')
  public userFIO: string;

  /**
   * Роли
   */
  @SessionStorage('roleList')
  public roleList: any[];

  constructor() {
  }

  /**
   * Проверяет имеет ли пользователь роль
   * @param roleSysName
   */
  isUserHasRole(roleSysName: string) {
    if (this.roleList) {
      for (let i = 0; i < this.roleList.length; i++) {
        const bean = this.roleList[i];
        if (bean.ROLESYSNAME === roleSysName) {
          return true;
        }
      }
    }
    return false;
  };
}
