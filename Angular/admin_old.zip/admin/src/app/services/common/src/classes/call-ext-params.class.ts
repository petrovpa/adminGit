export class CallExtParams {
    // показывать модальное окно с ошибкой вызова rest-сервиса
    showError?: boolean;
    // скрывать основной прогресс-бар
    hideLoader?: boolean;
    // использовать входные параметры вызова rest-сервиса напрямую (необорачивая params в объектом obj)
    isStrictParams?: boolean;
}