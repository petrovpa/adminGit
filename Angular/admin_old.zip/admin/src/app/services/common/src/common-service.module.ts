import { InjectionToken, ModuleWithProviders, NgModule } from '@angular/core';
import { EventsService } from './events/events.service';
import { RestService, REST_CONFIG } from './rest/rest.service';
import { SessionService } from './session/session.service';
import { RestConfig } from './rest/rest-config';
import { WindowRef } from './winref/window-ref.service';

export const DOCUMENT = new InjectionToken<Document>('DocumentToken');

@NgModule({
  imports: []
})
export class CommonServiceModule {
  static forRoot(config: any): ModuleWithProviders {
    return {
      ngModule: CommonServiceModule,
      providers: [
        EventsService,
        SessionService,
        RestService,
        { provide: REST_CONFIG, useValue: config },
        { provide: RestConfig, useFactory: provideConfig, deps: [REST_CONFIG] },
        WindowRef,
        { provide: DOCUMENT, useFactory: _document, deps: [] }
      ],
    };
  }
}

export function provideConfig(config: any) {
  return new RestConfig(config);
}

export function _document(): any {
  return document;
}
