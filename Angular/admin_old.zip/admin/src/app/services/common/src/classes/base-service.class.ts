export class BaseService {
    /**
     * Очистка ссылок на экземпляра общих сущностей
     */
    clean = () => {
        // пробегаемся по полям экземпляра сущности,
        // ищем proto и вызываем setter = null
        const entity = this;
        for (const key in entity) {
            if (key) {
                let proto = entity;
                while (proto) {
                    const descriptor = Object.getOwnPropertyDescriptor(proto, key);
                    if (descriptor && descriptor.set) {
                        entity[key] = null;
                        proto = null;
                    } else {
                        proto = Object.getPrototypeOf(proto);
                    }
                }
            }
        }
    }
}