export enum RestType { URLENCODED = 0, JSON = 1 }

export interface IRestConfig {
  restPath?: string;
  admRestPath?: string;
  restType?: RestType;
  showError: boolean;
}

export declare class RestConfig {
  restPath: string;
  admRestPath: string;
  restType: RestType;
  showError: string;
  constructor(config?: IRestConfig);
}
