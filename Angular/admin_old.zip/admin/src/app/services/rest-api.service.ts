import 'rxjs/add/observable/of';

import { Injectable } from '@angular/core';
import { CreateAccountRequest } from '@app/classes/create-account-request.class';
import { UpdateAccountRequest } from '@app/classes/update-account-request.class';
import { RestService, CallExtParams } from '@app/services/common/src';
import isArray from 'lodash-es/isArray';
import isUndefined from 'lodash-es/isUndefined';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class RestApiService {
  constructor(private restService: RestService) {
  }

  // кэш данных справочников
  private cacheData: any = {};

  //#region Аккаунт пользователя
  /**
   * Создание/обновление аккаунта пользователя (если передан USERID, то обновление, иначе создание)
   * @param account {CreateAccountRequest} - создаваемый аккаунт пользователя
   */
  createAccount(account: CreateAccountRequest) {
    return this.restService.adminCall('admrestgate/accountCreate', new CreateAccountRequest(account));
  }

  /**
   * Обновление аккаунта пользователя
   * @param account {UpdateAccountRequest} - обновляемый аккаунт пользователя
   */
  updateAccount(account: UpdateAccountRequest) {
    return this.restService.adminCall('admrestgate/accountUpdate', new UpdateAccountRequest(account));
  }

  /**
   * Обновление статуса аккаунта пользователя
   *
   * @param {number} userAccountId
   * @param {number} userId -
   * @param {string} status - новый статус пользователя
   */
  updateAccountStatus(userAccountId: number, userId: number, status: string) {
    const params = {
      USERACCOUNTID: userAccountId,
      USERID: userId,
      STATUS: status
    };
    return this.restService.adminCall('admrestgate/accountUpdateStatus', params);
  }

  /**
   * Получение информации о пользователе
   * @param userAccountId {number} - идентификатор аккаунта пользователя
   */
  getUserInfoByAccountId(userAccountId: number) {
    return this.restService.adminCall('admrestgate/getUserInfoByAccountId', {USERACCOUNTID: userAccountId});
  }

  /**
   * Получение списка департаментов
   */
  getDepartmentList() {
    if (this.cacheData.departmentsList) {
      return Observable.of(this.cacheData.departmentsList);
    }
    return this.restService.b2bCall('department/dsGetDepartmentList', {}).map(departmentsList => {
      if (departmentsList) {
        this.cacheData.departmentsList = departmentsList;
      }
      return departmentsList;
    });
  }

  /**
   * Получение списка в виде дерева всех подразделений
   * @param departmentId {number} - идентификатор департамента
   */
  getDepartmentTree(departmentId?: number) {
    const params = isUndefined(departmentId) ? {} : {DEPARTMENTID: departmentId};
    return this.restService.adminCall('admrestgate/departmentTree', params);
  }

  /**
   * Смена пароля
   * @param userAccountId {number} - идентификатор аккаунта пользователя
   * @param newPassword {string} - новый пароль
   */
  changePassword(userAccountId, newPassword) {
    return this.restService.adminCall('admrestgate/dsAdminUserChangePass', {NEWPASS: newPassword, USERACCOUNTID: userAccountId});
  }

  //#endregion

  //#region Роли пользователя
  /**
   * Получение списка доступных ролей по идентификатору аккаунта
   * @param userAccountId {number} - идентификатор аккаунта пользователя
   */
  getRoleAvailableListByAccountId(userAccountId: number) {
    return this.restService.adminCall('admrestgate/getRoleAvailableListByAccountId', {USERACCOUNTID: userAccountId});
  }

  /**
   * Получение списка ролей пользователя
   * @param userAccountId {number} - идентификатор аккаунта пользователя
   */
  getUserRoleList(userAccountId: number) {
    return this.restService.adminCall('admrestgate/roleListByAccountId', {USERACCOUNTID: userAccountId});
  }

  /**
   * Получение списка всех ролей
   * @param userAccountId {number} - идентификатор аккаунта пользователя
   */
  getRoleList(userAccountId: number) {
    return this.restService.adminCall('admrestgate/roleListAbsentFromUser', {USERACCOUNTID: userAccountId});
  }

  /**
   * Добавление роли пользователю
   * @param userAccountId {number} - идентификатор аккаунта пользователя
   * @param roleId {number} - идентификатор роли
   */
  addRoleToUser(userAccountId: number, roleId: number) {
    return this.restService.adminCall('admrestgate/roleUserAdd', {USERACCOUNTID: userAccountId, ROLEID: roleId});
  }

  /**
   * Удаление роли пользователя
   * @param userAccountId {number} - идентификатор аккаунта пользователя
   * @param roleId {number} - идентификатор роли
   */
  removeUserRole(userAccountId: number, roleId: number) {
    return this.restService.adminCall('admrestgate/roleUserRemove', {USERACCOUNTID: userAccountId, ROLEID: roleId});
  }

  //#endregion

  //#region Профильные права
  /**
   * Добавление права пользователю
   * @param
   */
  addRightToUser(userAccountId: number, rightSysname: string, department: any) {
    return this.restService.adminCall('admrestgate/addProfileRightToAccount', {
      USERACCOUNTID: userAccountId,
      RIGHTSYSNAME: rightSysname,
      DEPARTMENTID: department.id,
      DEPARTMENTFULLNAME: department.name
    });
  }

  /**
   * Получение списка прав пользователя по идентификатору аккаунта
   * @param userAccountId {number} - идентификатор аккаунта пользователя
   */
  getRightListByAccountId(userAccountId: number) {
    return this.restService.adminCall('admrestgate/getRightListByAccountId', {USERACCOUNTID: userAccountId});
  }

  /**
   * Получение списка доступных прав по идентификатору аккаунта
   * @param userAccountId {number} - идентификатор аккаунта пользователя
   */
  getRightAvailableListByAccountId(userAccountId: number) {
    return this.restService.adminCall('admrestgate/getRightAvailableListByAccountId', {USERACCOUNTID: userAccountId});
  }

  /**
   * Удаление права пользователя
   * @param userId {number} - идентификатор аккаунта пользователя
   * @param rightId {number} - идентификатор права
   */
  removeUserRight(userAccountId: number, rightId: number) {
    return this.restService.adminCall('admrestgate/rightRemoveByRightId', {USERACCOUNTID: userAccountId, RIGHTID: rightId});
  }

  //#endregion

  //#region Группы пользователей
  /**
   * Добавление пользователей в группу
   * @param userId {number} - идентификатор пользователя
   * @param groupId {number} - идентификатор группы для добавления пользователя
   */
  addUserToGroup(userId: number, groupId: number) {
    return this.restService.adminCall('admrestgate/groupUserAdd', {USERID: userId, GROUPID: groupId});
  }

  /**
   * Удаление пользователя из группы
   * @param userId {number} - идентификатор аккаунта пользователя
   * @param groupId {number} - идентификатор группы
   */
  removeUserFromGroup(userId: number, groupId: number) {
    return this.restService.adminCall('admrestgate/groupUserRemove', {USERID: userId, GROUPID: groupId});
  }

  /**
   * Получение списка груп пользователя по идентификатору аккаунта
   * @param userAccountId {number} - идентификатор аккаунта пользователя
   */
  getGroupListByAccountId(userAccountId: number) {
    return this.restService.adminCall('admrestgate/getGroupListByAccountId', {USERACCOUNTID: userAccountId});
  }

  /**
   * Получение иерархической структуры всех групп
   */
  getGroupsTree() {
    return this.restService.adminCall('admrestgate/userGroupsTree', {});
  }

  //#endregion

  /**
   * Метод получания списка пользователей из active directory
   * @param userPrincipalNameSearch строка поиска ADUSERPRINCIPALNAME
   * @param callParams расширенные параметры вызова сервиса
   */
  getActiveDirectoryUserList(userPrincipalNameSearch: string, callParams?: CallExtParams) {
    return this.restService
      .adminCall('active-directory/getActiveDirectoryUserList', {ADUSERPRINCIPALNAME: `${userPrincipalNameSearch}*`, ISNEEDBLOCKED: true}, callParams)
      .map(res => isArray(res) ? res : []);
  }
}
