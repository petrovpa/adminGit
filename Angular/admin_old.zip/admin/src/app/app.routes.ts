import { Routes } from '@angular/router';
import { Page404Component } from './layouts/page404/page404.component';

export const MAIN_ROUTES: Routes = [
  {
    path: '',
    loadChildren: './layouts/admin/admin.module#AdminModule',
    data: {
      menu: [
        { path: ['/userAccountsJournal'], title: 'Журнал пользователей' },
        { path: ['/passwordSettings'], title: 'Настройки паролей' }
      ]
    }
  },
  { path: '', redirectTo: '', pathMatch: 'full' },
  { path: '**', component: Page404Component },
];
