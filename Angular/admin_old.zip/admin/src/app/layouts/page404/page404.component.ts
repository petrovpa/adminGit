import {Component} from '@angular/core';

@Component({
    templateUrl: 'page404.component.html',
    styleUrls: ['page404.component.scss']
})
export class Page404Component {

    constructor() {
    }
}
