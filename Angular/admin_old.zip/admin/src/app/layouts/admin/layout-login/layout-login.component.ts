import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './layout-login.component.html',
  styleUrls: ['./layout-login.component.scss'],

})
export class LayoutLoginComponent implements OnInit {

  constructor() {}


  ngOnInit() {}

}
