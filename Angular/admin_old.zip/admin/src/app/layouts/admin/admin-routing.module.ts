import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AuthGuard } from './guard/auth.guard';
import { LayoutLoginComponent } from './layout-login/layout-login.component';
import { LayoutMainComponent } from './layout-main/layout-main.component';

export const ADMIN_ROUTES: Routes = [
  {
    path: '',
    component: LayoutMainComponent,
    children: [
      // { path: 'welcome', component: WelcomeComponent },
      {
        path: 'userAccountsJournal',
        loadChildren: 'app/pages/user-accounts-journal/user-accounts-journal.module#UserAccountsJournalModule'
      },
      {
        path: 'userAccountEdit',
        loadChildren: 'app/pages/user-accounts-edit/user-accounts-edit.module#UserAccountsEditModule',
        data: {
          menu: [
            { title: 'Общая информация', path: ['/userAccountEdit/main'] },
            { title: 'Связь с AD', path: ['/userAccountEdit/activeDirectory'] },
            { title: 'Роли', path: ['/userAccountEdit/role'] },
            { title: 'Группы', path: ['/userAccountEdit/group'] },
            { title: 'Профильные права', path: ['/userAccountEdit/profileRight'] }
          ]
        }
      },
      {
        path: 'passwordSettings',
        loadChildren: 'app/pages/password-settings/password-settings.module#PasswordSettingsModule'
      },
      { path: '', redirectTo: '', pathMatch: 'full' }
    ],
    canActivate: [AuthGuard]
  },
  {
    path: '',
    component: LayoutLoginComponent,
    data: {
      title: 'B2B Администрирование'
    },
    loadChildren: 'app/pages/auth/auth.module#AuthModule'
  }
];

@NgModule({
  imports: [RouterModule.forChild(ADMIN_ROUTES)],
  exports: [RouterModule]
})
export class AdminRoutingModule {}
