import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { MenuModule } from '@frontend/menu';
import { AlertModule } from '@frontend/alert';
import { LoginService } from '@app/pages/auth/services/login.service';
import { DialogModule } from '@frontend/dialog-modal';

import { AuthGuard } from './guard/auth.guard';
import { AdminRoutingModule } from './admin-routing.module';

import { LayoutLoginComponent } from './layout-login/layout-login.component';
import { LayoutMainComponent } from './layout-main/layout-main.component';
import { AppFooterComponent } from './app-footer/app-footer.component';
import { AppHeaderComponent } from './app-header/app-header.component';
import { AppLoaderComponent } from './app-loader/app-loader.component';
import { WelcomeComponent } from '@app/pages/welcome/welcome.component';
import { AppSidebarComponent } from '@app/components/app-sidebar/app-sidebar.component';

console.log('ADMIN bundle loaded asynchronously');

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule,
    AdminRoutingModule,
    AlertModule.forRoot(),
    MenuModule.forRoot(),
    DialogModule.forRoot()
  ],
  declarations: [
    LayoutLoginComponent,
    LayoutMainComponent,
    AppFooterComponent,
    AppHeaderComponent,
    AppLoaderComponent,
    WelcomeComponent,
    AppSidebarComponent,
    WelcomeComponent
  ],
  providers: [
    LoginService,
    AuthGuard
  ]
})

export class AdminModule { }
