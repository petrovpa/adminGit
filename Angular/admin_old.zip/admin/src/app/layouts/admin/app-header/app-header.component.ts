import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { MENU } from './menu';
import { environment } from 'environments/environment';

import { MenuItem } from '@frontend/menu';
import { SessionService } from '@app/services/common/src';

@Component({
  selector: 'app-header',
  templateUrl: './app-header.component.html',
  styleUrls: ['./app-header.component.scss']
})
export class AppHeaderComponent implements OnInit {
  /**
   * Меню
   * @type {MenuItem[]}
   */
  protected menuList: MenuItem[] = MENU;

  /**
   * Имя пользователя
   */
  protected fio: string;

  constructor(private sessionService: SessionService,
              private router: Router) {
  }

  ngOnInit() {
    this.fio = this.sessionService.userFIO;
  }

  /**
   * Переходим на главную
   */
  openMain() {
    this.router.navigate(['']);
  }

  logout() {
    this.router.navigate(['/logout']);
  }
}
