import { MenuItem } from '@frontend/menu';

export const MENU: MenuItem[] = [
  {
    title: 'Выйти',
    url: '/logout',
    iconClass: 'b2b-icon-exit'
  }
];
