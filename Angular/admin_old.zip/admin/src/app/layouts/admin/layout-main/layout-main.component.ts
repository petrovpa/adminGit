import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { EventsService } from '@app/services/common/src';
import { NavigationStart, Router, ActivatedRoute, NavigationEnd, RouteConfigLoadEnd, UrlSegment, Route, RouterEvent } from '@angular/router';
import { environment } from 'environments/environment';
import { ModalAlertComponent } from '@frontend/dialog-modal';
import * as _ from 'lodash';
import 'rxjs/add/operator/take';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Helper } from '@app/classes/helper.class';
import { Observable } from 'rxjs/Observable';
import { MenuItem } from '@app/classes/menu-item.class';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/takeUntil';
import { Logger } from '@frontend/logger';

@Component({
  templateUrl: './layout-main.component.html',
  styleUrls: ['./layout-main.component.scss'],

})
export class LayoutMainComponent implements OnInit, OnDestroy {
  protected destroy$: Subject<boolean> = new Subject<boolean>();

  @ViewChild('alert') private modalAlert: ModalAlertComponent;
  // статус окна
  private showAlert: boolean = false;
  private routes$: BehaviorSubject<MenuItem[]> = new BehaviorSubject([]);

  constructor(
    private logger: Logger,
    private eventsService: EventsService,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) {
  }

  ngOnInit() {
    // DEBUG
    // TODO: исправить на нормальную инициализацию меню
    const debugMenu: MenuItem[] = [
      { path: ['userAccountsJournal'], title: 'Журнал пользователей' },
      { path: ['passwordSettings'], title: 'Настройки паролей' }
    ];
    this.routes$.next(debugMenu);

    this.router.events
      .takeUntil(this.destroy$)
      .filter((event) => {
        return ((event instanceof NavigationEnd) || (event instanceof RouteConfigLoadEnd));
      })
      .map(_ => this.activatedRoute)
      .map((route) => {
        while (route.firstChild) route = route.firstChild;
        return route;
      })
      .subscribe(route => {
        while (!_.isUndefined(route.parent) && !this.isCurrentComponent(route) && !this.getRouteMenu(route))
          route = route.parent;
        // создаем меню
        this.routes$.next(this.getMappedRoutes(route));
      });

    // сессия истекла - выходим
    this.eventsService.subscribe('request:session expired', () => {
      this.router.navigate(['/login'], {
        queryParams: {
          error: 'expired'
        }
      });
    });

    // вывод ошибки
    this.eventsService.subscribe('message:error', (message: string) => {
      this.showErrorDialog(message);
    });

    this.eventsService.subscribe('request:error', (message: string) => {
      this.showErrorDialog(message);
    });

    // this.eventsService.subscribe('login', _ => {
    //   // TODO: исправить на нормальную инициализацию меню
    //   // создаем меню
    //   const debugMenu: MenuItem[] = [
    //     { path: ['userAccountsJournal'], title: 'Журнал пользователей' },
    //     { path: ['passwordSettings'], title: 'Настройки паролей' }
    //   ];
    //   this.routes$.next(debugMenu);
    // });

    // this.routes$.subscribe(_ => this.logger.log('this.routes$ ', this.routes$.value));
  }

  ngOnDestroy() {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
  }

  /**
   * Проверка на наличие признака hasOwnMenu в роуте,
   * @param route {ActivatedRoute} - роут для поиска признака hasOwnMenu
   */
  private getRouteMenu(route: ActivatedRoute): MenuItem[] | undefined {
    return _.cloneDeep(Helper.get(['snapshot', 'data', 'menu'], route));
  }

  /**
   * Маппинг роутов для конструирования меню
   * @param route {ActivatedRoute} - роут
   */
  private getMappedRoutes(route): MenuItem[] {
    const routes: MenuItem[] = this.getRouteMenu(route);
    // если роут текущего компонента, то routes - это массив children из конфигурации роута,
    // иначе маппим массив роутов загруженного модуля
    if (!this.isCurrentComponent(route)) {
      const params = route.snapshot.params;

      if (!_.isEmpty(params) && _.isArray(routes)) {
        routes.forEach(m => {
          _.forIn(params, (param: any) => {
            if (!_.includes(m.path, param))
              m.path.push(param);
          });
        });
      }

    }
    return routes || [];
  }

  /**
   * Проверка является ли имя компонента роута именем текущего компонента
   * @param route {ActivatedRoute} - роут для проверки имени компонента
   */
  private isCurrentComponent(route: ActivatedRoute) {
    const routeComponent = route && route.component || {};
    return (routeComponent['name'] === 'LayoutMainComponent');
  }

  /**
   * Показываем диалоговое окно
   * @param {string} message
   */
  showErrorDialog(message: string) {
    if (!this.showAlert) {
      this.showAlert = true;
      this.modalAlert.setMessage(message);
      this.modalAlert.show();
    }
  }

  /**
   * Закрыли окно об ошибке
   */
  onAlertConfirmed() {
    this.showAlert = false;
  }
}
