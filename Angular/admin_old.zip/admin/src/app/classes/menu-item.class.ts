
export class MenuItem {
    path: string[];
    title: string;
    icon?: string;
}