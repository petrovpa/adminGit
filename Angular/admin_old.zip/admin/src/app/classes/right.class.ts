export class Right {
  RIGHTID: number;
  RIGHTNAME: string;
  RIGHTSYSNAME: string;
}
