export class Department {
    name: string;
    hid: number;
}