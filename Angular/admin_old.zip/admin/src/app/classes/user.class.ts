import { CoreUseraccount } from './core-useraccount.class';

export class User extends CoreUseraccount {
    ACCSTATUS: string;
    DEPARTMENTID: number;
    DEPARTMENTSHORTNAME: string;
    EMAIL: string;
    EMPLOYEEID: number;
    PHONE1: string;
    PHONE2: string;
    POSITION: string;
    USERNAME: string;
    FIRSTNAME: string;
    LASTNAME: string;
    MIDDLENAME: string;
    RETPASSWORD: string;
}
