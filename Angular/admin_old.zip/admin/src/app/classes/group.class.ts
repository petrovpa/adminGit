export class Group {
    USERGROUPID: number;
    PROJECTID: number;
    GROUPNAME: string;
    DESCRIPTION: string;
    PARENTGROUP: number;
}