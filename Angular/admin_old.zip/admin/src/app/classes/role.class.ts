export class Role {
    DESCRIPTION: string;
    PROJECTID: number;
    ROLEID: number;
    ROLENAME: string;
    ROLESYSNAME: string;
    ROLEVIEWNAME: string;
}
