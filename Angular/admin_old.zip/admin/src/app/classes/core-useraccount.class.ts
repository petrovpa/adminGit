export class CoreUseraccount {
    USERACCOUNTID: any;
    USERID: number;
    LOGIN: string;
    PASSWORD: string;
    STATUS: string;
    CREATIONDATE: string;
    LASTLOGINEVENT: number;
    PREFLANGUAGE: number;
    AUTHMETHOD: number;
    DESCRIPTION: string;
    FAILEDLOGINS: number;
    PWDEXPDATE: string;
    LASTLOGOUTEVENT: number;
    LOGOUTDUETO: number;
    EXTERNALID: string;
    ISCONCURRENT: number;
    ACCOUNTNAME: string;
}
