import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from 'environments/environment';

import { RestService, SessionService, EventsService } from '@app/services/common/src';
import { Logger } from '@frontend/logger';

@Injectable()
export class LoginService {
  private loggedIn = false;

  /**
   * Редирект на страницу
   *
   * @type {string}
   * @private
   */
  private _redirectURL = '';
  get redirectURL(): string {
    return this._redirectURL;
  }
  set redirectURL(value: string) {
    this._redirectURL = value;
  }

  constructor(private logger: Logger,
    private restService: RestService,
    private sessionService: SessionService,
    private eventsService: EventsService,
    private router: Router) {
    this.loggedIn = this.isLoggedIn();
  }

  /**
   * Авторизация
   *
   * @param {string} login
   * @param {string} password
   */
  public login(login: string, password: string) {
    const params = {
      login: login,
      password: password
    };

    return this.restService.b2bCall('login/dsLogin', params, { hideLoader: true, showError: false }).map((res: any) => {
      this.logger.log('get result from dsLogin', res);

      if (!res.Error && this.sessionService.sessionId) {
        this.setUserName(res);

        this.sessionService.roleList = res.ROLELIST;

        // событие об успешном входе
        this.eventsService.publish('login');

        return true;
      }

      return res.Error;
    });
  }

  /**
   * Восстановление пароля
   *
   * @param {string} email
   * @param {string} login
   */
  public restorePassword(email: string, login: string) {
    const params = {
      LOGIN: login,
      EMAIL: email
    };

    return this.restService.b2bCall('login/dsResetPassword', params, { showError: false }).map((res: any) => {
      this.logger.log('get result from dsLogin', res);

      if (!res.Error && this.sessionService.sessionId) {
        return true;
      }

      return res.Error;
    });
  }
  /**
   * Имя пользователя
   *
   * @param res
   */
  private setUserName(res) {
    this.sessionService.userFIO = (res.LASTNAME + ' ' + res.FIRSTNAME + ' ' + res.MIDDLENAME).trim();

    if (!this.sessionService.userFIO) this.sessionService.userFIO = null;
  }

  /**
   * Выход
   */
  public logout(): void {
    this.sessionService.sessionId = null;
    this.sessionService.userFIO = null;
    this.sessionService.roleList = null;
    this.loggedIn = false;
    // событие об выходе
    this.eventsService.publish('logout');
  }

  /**
   * Авторизован ли?
   *
   * @returns {any}
   */
  public isLoggedIn(): any {
    return !!this.sessionService.sessionId;
  }

  /**
   * Запрет доступа: окончание сесиии
   *
   * @param error
   */
  public unauthorizedAccess(error: any): void {
    this.logout();
    this.router.navigate(['/login']);
    // посылаем событие о необходимости повторно авторизоваться
    this.eventsService.publish('login:unauthorized access');
  }
}
