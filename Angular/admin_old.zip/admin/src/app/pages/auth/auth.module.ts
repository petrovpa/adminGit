import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { FormControlLabelModule } from '@frontend/form-control-label';

import { AuthRoutingModule } from './auth-routing.module';
import { LoginComponent } from './login/login.component';
import { RememberComponent } from './remember/remember.component';
import { LoginService } from './services/login.service';
import { LogoutComponent } from './logout/logout.component';
import { CollapseModule } from '@frontend/collapse';

console.log('Auth bundle loaded asynchronously');

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AuthRoutingModule,
    FormControlLabelModule,
    CollapseModule
  ],
  declarations: [
    LoginComponent,
    RememberComponent,
    LogoutComponent
  ],
  providers: [
    LoginService
  ]
})
export class AuthModule {
}
