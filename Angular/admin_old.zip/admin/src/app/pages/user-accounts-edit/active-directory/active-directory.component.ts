import { Component, Injector, OnInit } from '@angular/core';
import { ActiveDirectoryUser } from '@app/classes/active-directory-user.class';
import { BaseUserAccountComponent } from '@app/pages/user-accounts-edit/base/base.component';
import { UpdateAccountRequest } from '@app/classes/update-account-request.class';
import { ServiceCaller } from '@app/components/form-control/src/autocomplete/autocomplete.component';

import { Observable } from 'rxjs/Observable';
import { RestApiService } from '@app/services/rest-api.service';

@Component({
  selector: 'app-active-directory',
  templateUrl: './active-directory.component.html',
  styleUrls: ['./active-directory.component.scss']
})
export class ActiveDirectoryComponent extends BaseUserAccountComponent implements OnInit {

  adServiceCaller: ActiveDirectoryServiceCaller;

  selectedAdAccount: string;
  // выбранный аккаунт AD из поля "Поиск учетной записи AD"
  activeDirectoryUser: ActiveDirectoryUser;
  // список аккаунтов AD для поля "Поиск учетной записи AD"
  activeDirectoryUserList: ActiveDirectoryUser[] = [];
  // значение поля "Связанная учетная запись AD" (формат: ADUSERLOGIN (ADUSERPRINCIPALNAME))
  viewAdUserName: string;

  constructor(protected injector: Injector) {
    super(injector);
    this.adServiceCaller = new ActiveDirectoryServiceCaller(this.adminService);
  }

  ngOnInit() {
    this.activeDirectoryUser = new ActiveDirectoryUser({});
  }

  /**
   * Связать учетные записи ActiveDirectory и core_useraccount
   */
  bindAccounts() {
    const account: any = {
      ...this.activeDirectoryUser,
      USERACCOUNTID: this.userAccountId,
      USERID: this.userId
    };
    this.adminService.updateAccount(account);
  }

  /**
   * Удалить связь ActiveDirectory и core_useraccount
   */
  removeAccountBinding() {
    const account: any = {
      ADUSERLOGIN: null,
      ADUSERPRINCIPALNAME: null,
      USERACCOUNTID: this.userAccountId,
      USERID: this.userId
    };
    this.adminService.updateAccount(account);
  }

  /**
   * Установка отображаемого на интерфейсе значения для поля "Связанная учетная запись AD"
   * @param adAccount - аккаунт AD
   */
  private setViewAdUserName(adAccount: ActiveDirectoryUser) {
    this.viewAdUserName = `${adAccount.ADUSERLOGIN} (${adAccount.ADUSERPRINCIPALNAME})`;
  }

  /**
   * Обработчик события "Выбор связанного аккаунта AD"
   * @param adAccount выбранный аккаунт AD
   */
  activeDirectoryUserSelect(adAccount: ActiveDirectoryUser) {
    this.setViewAdUserName(adAccount);
  }

  /**
   * Функция поиска аккаунтов AD
   * @param term строка поиска
   */
  search = (term: string): Observable<ActiveDirectoryUser[]> =>
    this.adminService.getActiveDirectoryUserList(term)
      .map(res => res.map(item => new ActiveDirectoryUser(item)));

}

class ActiveDirectoryServiceCaller implements ServiceCaller {

  constructor(private adminService: RestApiService) {
  }

  call(inputStr: string): Observable<any> {
    if (!inputStr) {
      return Observable.of([]);
    }
    const callParams = {hideLoader: true}; // скрывать спиннер загрузки
    return this.adminService.getActiveDirectoryUserList(inputStr, callParams);
  }

}
