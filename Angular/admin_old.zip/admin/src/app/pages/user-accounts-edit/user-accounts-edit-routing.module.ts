import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ActiveDirectoryComponent } from '@app/pages/user-accounts-edit/active-directory/active-directory.component';

import { UserGroupComponent } from './group/group.component';
import { UserProfileRightComponent } from './profile-right/profile-right.component';
import { UserRoleComponent } from './role/role.component';
import { UserAccountEditGuard } from './user-account-edit.guard';
import { UserMainComponent } from './user-main/user-main.component';

export const UACCOUNTS_EDIT_ROUTES: Routes = [
  {
    path: 'main',
    component: UserMainComponent,
    data: {
      next: 'role/:userAccountId'
    }
  },
  {
    path: 'main/:userAccountId',
    component: UserMainComponent,
    data: {
      next: 'activeDirectory/:userAccountId'
    }
  },
  {
    path: 'activeDirectory',
    component: ActiveDirectoryComponent,
    canActivate: [UserAccountEditGuard]
  },
  {
    path: 'activeDirectory/:userAccountId',
    component: ActiveDirectoryComponent,
    data: {
      back: 'main/:userAccountId',
      next: 'role/:userAccountId'
    }
  },
  {
    path: 'role',
    component: UserRoleComponent,
    canActivate: [UserAccountEditGuard]
  },
  {
    path: 'role/:userAccountId',
    component: UserRoleComponent,
    data: {
      back: 'activeDirectory/:userAccountId',
      next: 'group/:userAccountId'
    }
  },
  {
    path: 'group',
    component: UserGroupComponent,
    canActivate: [UserAccountEditGuard]
  },
  {
    path: 'group/:userAccountId',
    component: UserGroupComponent,
    data: {
      back: 'role/:userAccountId',
      next: 'profileRight/:userAccountId'
    }
  },
  {
    path: 'profileRight',
    component: UserProfileRightComponent,
    canActivate: [UserAccountEditGuard]
  },
  {
    path: 'profileRight/:userAccountId',
    component: UserProfileRightComponent,
    data: {
      back: 'group/:userAccountId'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(UACCOUNTS_EDIT_ROUTES)],
  exports: [RouterModule]
})
export class UserAccountsEditRoutingModule {}
