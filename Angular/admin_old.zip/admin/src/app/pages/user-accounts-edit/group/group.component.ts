import { Component, OnInit } from '@angular/core';
import { BaseTableComponent } from '@app/pages/user-accounts-edit/base-table/base-table.component';
import { Group } from '@app/classes/group.class';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import * as _ from 'lodash';
import { AddModalDialogOptions } from '@app/components/add-modal-dialog/add-modal-dailog-options.class';
import { GroupModalDialogOptions } from '@app/components/modal-dialog-group/modal-dialog-group-options.class';
import { AngularTree } from '@app/classes/angular-tree.class';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/first';
import { User } from '@app/classes/user.class';

@Component({
  selector: 'group',
  templateUrl: './group.component.html',
  styleUrls: ['./group.component.scss']
})
export class UserGroupComponent extends BaseTableComponent implements OnInit {

  // признак загрузки списка групп пользователя
  private isGroupLoading: boolean = true;
  // список доступных групп пользователя
  private groupAvailableList: Group[];
  // список групп пользователя
  private groupList: Group[];
  // список всех групп
  private groupListFull: Group[];
  // namespace группы
  private groupNamespace: any[] = [];
  // кнопки таблицы групп пользователя
  private groupTableButtons: any[] = _.cloneDeep(this.tableButtons);
  // Обработчик события выбора записи из списка ролей пользователя
  private onGroupSelect(ev) { }
  // опции модального окна добавления группы
  private groupModalDialogOptions: GroupModalDialogOptions = new GroupModalDialogOptions(
    'Добавить в группу',
    'Группа'
  );

  ngOnInit() {
    this.initTables();
    this.userAccountId$
      .first().subscribe(this.getGroupListByAccountId);
    if (!this.userId) {
      this.adminService.getUserInfoByAccountId(this.userAccountId)
        .first()
        .subscribe((userInfo: User) => this.userId$.next(userInfo.USERID));
    }
  }

  /**
   * Инициализация таблиц Группы
   */
  private initTables() {
    this.groupTableButtons[0].onClick = this.onClickAddUserToGroup;
    this.groupTableButtons[1].onClick = this.removeUserFromGroup;
    this.groupModalDialogOptions.onClickAddButton = this.onAddUserToGroupModal;
  }

  /**
   * Получение списка всех групп в виде дерева
   */
  //getGroupList() {
  //  return this.adminService.getGroupsTree().map((groupListFull: Group[]) => this.groupListFull = groupListFull).toPromise();
  //}

  /**
   * Получение списка групп пользователя
   * @param userAccountId {number} - идентификатор аккаунта пользователя
   * @param onSuccess {Function} - дополнительный обработчик успешного результата
   */
  getGroupListByAccountId = (userAccountId: number, onSuccess?: Function) => {
    this.adminService.getGroupListByAccountId(userAccountId).map((groupList: Group[]) => {
      this.groupList = groupList;
      this.isGroupLoading = false;
    })
      .subscribe(onSuccess);
  }

  /**
   * Добавление пользователя в группу
   * @param selectedGroupId {number} - идентификатор добавляемой группы
   */
  addUserToGroup = (groupId: number) => {
    return this.adminService.addUserToGroup(this.userId, groupId);
  }

  /**
   * Обработчик onClickAddButton для groupModalDialogOptions
   *
   * @param group {any} - выбранная группа
   * @param modalForm {NgForm} - объект модальной формы групп
   */
  onAddUserToGroupModal = (group: any, modalForm: NgForm) => {
    const groupId = group && +group.id;
    if (!_.isUndefined(groupId)) {
      if (groupId === 0) {
        this.dialogService.alert('Нельзя добавить пользователя в корневую группу.');
      } else {
        this.addUserToGroup(groupId).subscribe(_ => this.getGroupListByAccountId(this.userAccountId, () => this.addDialog.dialog.close()));
      }
    }
  }

  /**
   * Обработчик события нажатия на кнопку добавления пользователя в группу (datatable)
   */
  onClickAddUserToGroup = async () => {
    this.groupModalDialogOptions = this.groupModalDialogOptions;
    this.addDialog.dialog.show();
    // await this.getGroupList();
    // if (this.groupListFull.length > 0) {
    //   this.addDialog.dialog.show();
    // } else {
    //   this.dialogService.alert('Отсутствуют доступные для добавления группы.');
    // }
  }

  /**
   * Удаление пользователя из группы
   * @param selectedList {any[]} - список выбранных групп
   */
  removeUserFromGroup = (selectedList: any[]) => {
    if (_.isArray(selectedList)) {
      try {
        const roleList$: Array<Observable<any>> =
          selectedList.map((group: any) => this.adminService.removeUserFromGroup(this.userId, group.USERGROUPID));
        Observable.forkJoin(...roleList$)
          .first()
          .subscribe(() => this.getGroupListByAccountId(this.userAccountId));
      } catch (e) {
        console.error('error in UserAccountsEditComponent UserFromGroup', e);
      }
    }
  }
}
