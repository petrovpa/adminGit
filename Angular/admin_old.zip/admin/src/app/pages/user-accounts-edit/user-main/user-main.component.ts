import 'rxjs/add/operator/first';

import { Component, Injector, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AngularTree } from '@app/classes/angular-tree.class';
import { Department } from '@app/classes/department.class';
import { User } from '@app/classes/user.class';
import {
  ChangePasswordDialogOptions,
} from '@app/components/change-password-modal-dialog/change-password-dialog-options.class';
import {
  ChangePasswordDialogComponent,
} from '@app/components/change-password-modal-dialog/change-password-dialog.component';
import { BaseUserAccountComponent } from '@app/pages/user-accounts-edit/base/base.component';
import * as _ from 'lodash';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Component({
  selector: 'user-main',
  templateUrl: './user-main.component.html',
  styleUrls: ['./user-main.component.scss']
})
export class UserMainComponent extends BaseUserAccountComponent implements OnInit, OnDestroy {
  @ViewChild('changeDialog') protected changeDialog: ChangePasswordDialogComponent;
  // дерево подразделений
  private departmentTree: any;
  // опции для компонента выбора департамента
  private departamentOptions: any = {
    /**
     * Обработчик выбора департамента
     * @param dep {any} - выбранный департамернт из дерева
     */
    onActivate: (dep: any) => {
      this.departmentItem.next(dep);
    }
  };
  // список подразделений
  private departmentList: Department[];
  // выбранное подразделение
  private departmentItem: BehaviorSubject<any> = new BehaviorSubject({});
  // модель страницы редактирования данных пользователя
  private user: User = new User();
  // флаг режима редактирования
  private isEditMode: boolean = false;

  protected wasValidated: boolean = false;

  protected isSavedChange: boolean = false;

  // опции модального окна смены пароля
  protected changePasswordDialogOptions: ChangePasswordDialogOptions = <ChangePasswordDialogOptions>{
    modalDialogTitle: 'Смена пароля',
    labelTitle: 'Смена пароля'
  };

  constructor(protected injector: Injector) {
    super(injector);
  }

  ngOnInit() {
    this.changePasswordDialogOptions.onClickConfirmButton = this.onConfirmChangePassword;

    this.loadDepartments();
    this.userAccountId$.first().subscribe(resId => {
      this.isEditMode = resId ? true : false;
      if (this.isEditMode) {
        this.getUserInfoByAccountId(resId);
        this.isSavedChange = true;
      }
    });
  }

  ngOnDestroy() {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
  }

  /**
   * Получение списка отделений
   */
  loadDepartments() {
    this.adminService.getDepartmentTree().subscribe(departmentTree => (this.departmentTree = AngularTree.createNewArray(departmentTree)));
    this.adminService.getDepartmentList().subscribe(departmentList => (this.departmentList = departmentList));
  }

  /**
   * Получение данных пользователя
   * @param userAccountId {number} - идентификатор аккаунта пользователя
   */
  getUserInfoByAccountId(userAccountId: number) {
    this.adminService.getUserInfoByAccountId(userAccountId).subscribe(userInfo => {
      this.user = userInfo;
      if (this.departmentList) {
        const department = this.departmentList.find((dep: any) => dep.hid === this.user.DEPARTMENTID);
        // устанавливам департамент пользователя
        this.departmentItem.next(department);
        // устанавливам идентификатора пользователя
        this.userId$.next(this.user.USERID);
      }
    });
  }

  /**
   * Создание или обновление пользователя
   */
  createOrUpdateUser(event, f: NgForm) {
    this.wasValidated = true;
    if (f.valid) {
      let departmentId: number;
      const departmentItem = this.departmentItem.getValue();
      if (departmentItem) {
        departmentId = _.isUndefined(departmentItem.id) ? +departmentItem.hid : +departmentItem.id;
      }
      if (!_.isUndefined(departmentId)) {
        this.user.DEPARTMENTID = departmentId;

        let params: any = { ...this.user };

        if (this.userAccountId) {
          this.adminService.updateAccount(params).subscribe(res => {
            //this.next(event, f);
          });
        } else {
          params = {
            ...params,
            BLOCKIFINACTIVE: 0,
            ISCONCURRENT: 1,
            OBJECTTYPE: 1
          };
          this.adminService.createAccount(params).subscribe((res: User) => {
            this.userAccountId$.next(res.USERACCOUNTID);
            //this.next(event, f);
            this.isSavedChange = true;
          });
        }
      } else {
        this.logger.warn('Отутствует DEPARTMENTID');
      }
    } else {
      this.dialogService.alert('Проверьте введенные данные');
    }
  }

  /**
   * Обработчик события нажатия на кнопку смены пароля
   */
  onChangePassword = async () => {
    this.changeDialog.dialog.show();
  };

  /**
   * Подтверждение смены пароля
   */
  onConfirmChangePassword = (currentPassword, newPassword, retPassword, f: NgForm) => {
    if (f.valid) {
      this.adminService.changePassword(this.userAccountId, newPassword).subscribe(() => this.changeDialog.dialog.close());
    } else {
      this.dialogService.alert('Заполнены не все поля');
    }
  };
}
