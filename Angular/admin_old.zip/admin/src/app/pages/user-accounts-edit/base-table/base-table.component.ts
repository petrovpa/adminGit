import { Component, OnInit, ViewChild } from '@angular/core';
import { AddModalDialogOptions } from '@app/components/add-modal-dialog/add-modal-dailog-options.class';
import { AddModalDialogComponent } from '@app/components/add-modal-dialog/add-modal-dialog.component';
import { BaseUserAccountComponent } from '@app/pages/user-accounts-edit/base/base.component';

@Component({
  selector: 'app-base-table',
  templateUrl: './base-table.component.html',
  styleUrls: ['./base-table.component.scss']
})
export class BaseTableComponent extends BaseUserAccountComponent implements OnInit {

  @ViewChild('addDialog') protected addDialog: AddModalDialogComponent;
  protected addModalDialogOptions: AddModalDialogOptions = new AddModalDialogOptions();

  protected tableButtons: any[] = [
    { title: 'Добавить', class: 'table-button__add', iClass: 'b2b-icon-add' },
    { title: 'Удалить', class: 'table-button__delete', iClass: 'b2b-icon-delete', selectedRequired: true }
  ];

  ngOnInit() { }

}
