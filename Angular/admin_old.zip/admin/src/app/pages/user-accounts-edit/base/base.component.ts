import 'rxjs/add/operator/takeUntil';

import { Component, Injector, OnDestroy, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { RestApiService } from '@app/services/rest-api.service';
import { ModalDialogService } from '@frontend/dialog-modal';
import { Logger } from '@frontend/logger';
import * as _ from 'lodash';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Subject } from 'rxjs/Subject';

@Component({
  selector: 'user-edit-base',
  templateUrl: './base.component.html',
  styleUrls: ['./base.component.scss']
})
export class BaseUserAccountComponent implements OnInit, OnDestroy {
  /**
   * Идет инициализация страницы
   * @type {boolean}
   */
  protected isLoading: boolean = true;
  /**
   * Обработка сервиса
   * @type {boolean}
   */
  protected isServiceInProgress: boolean = false;
  /**
   * Форма отправлена - проверка валидации
   * @type {boolean}
   */
  protected wasValidated: boolean = false;
  /**
   * Формы заблокированы для изменения
   * @type {boolean}
   */
  protected isFormDisabled: boolean = false;
  protected destroy$: Subject<boolean> = new Subject<boolean>();

  protected userAccountId$: BehaviorSubject<number> = new BehaviorSubject(null);
  protected get userAccountId(): number {
    return this.userAccountId$.value;
  }

  protected userId$: BehaviorSubject<number> = new BehaviorSubject(null);
  protected get userId(): number {
    return this.userId$.value;
  }

  /**
   * Сервисы
   */
  protected logger: Logger;
  protected router: Router;
  protected activatedRoute: ActivatedRoute;
  protected adminService: RestApiService;
  protected dialogService: ModalDialogService;

  constructor(protected injector: Injector) {
    this.logger = this.injector.get(Logger);
    this.router = this.injector.get(Router);
    this.activatedRoute = this.injector.get(ActivatedRoute);
    this.adminService = this.injector.get(RestApiService);
    this.dialogService = this.injector.get(ModalDialogService);

    this.activatedRoute.params.takeUntil(this.destroy$).subscribe(params => {
      if (params) {
        if (!_.isUndefined(params.userAccountId)) {
          const userAccountId = +params.userAccountId;
          this.userAccountId$.next(userAccountId);
        }
      }
    });
  }

  ngOnInit() {}

  ngOnDestroy() {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
  }

  /**
   * Продолжить (следующая страница)
   *
   * @param $event - событие (чтобы не выполнялись дефолтные действия по этому событию)
   * @param {NgForm} f форма для проверки валидности
   * @returns {boolean}
   */
  next($event, f: NgForm) {
    $event.preventDefault();

    // надо ли сохранять?
    if (!this.isFormDisabled) {
      this.wasValidated = true;

      // форма валидна?
      if (f.valid) {
        this.navigateNext();
      }
    } else {
      this.navigateNext();
    }
    return false;
  }

  back($event) {
    $event.preventDefault();
    this.navigateBack();
    return false;
  }

  /**
   * Переход на следующую страницу
   */
  protected navigateNext() {
    // определяем следующую страницу
    const navigateNext = this.activatedRoute.snapshot.data.next;
    if (navigateNext) {
      const nextPage = this.replaceRouteParams('/userAccountEdit/' + navigateNext);
      this.router.navigate([nextPage]);
    }
  }

  /**
   * Переход на предыдущую страницу
   */
  protected navigateBack() {
    // определяем следующую страницу
    const navigateBack = this.activatedRoute.snapshot.data.back;
    if (navigateBack) {
      const previousPage = this.replaceRouteParams('/userAccountEdit/' + navigateBack);
      this.router.navigate([previousPage], {
        queryParams: {
          back: true
        }
      });
    }
  }

  /**
   * Заменяем параметры в url
   *
   * @param url
   * @returns {any}
   */
  private replaceRouteParams(url) {
    return url.replace(':userAccountId', this.userAccountId);
  }
}
