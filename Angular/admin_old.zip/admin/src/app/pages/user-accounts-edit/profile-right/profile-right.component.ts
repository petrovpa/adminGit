import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { BaseTableComponent } from '@app/pages/user-accounts-edit/base-table/base-table.component';
import { Right } from '@app/classes/right.class';
import { User } from '@app/classes/user.class';
import * as _ from 'lodash';
import { AddModalDialogOptions } from '@app/components/add-modal-dialog/add-modal-dailog-options.class';
import { Observable } from 'rxjs/Observable';
import { Department } from '@app/classes/department.class';
import { ProfileRightModalDialogOptions } from './profile-right-dialogs/profile-right-add-modal-dialog/profile-right-modal-dialog-options.class';
import 'rxjs/add/operator/first';

@Component({
  selector: 'profile-right',
  templateUrl: './profile-right.component.html',
  styleUrls: ['./profile-right.component.scss']
})
export class UserProfileRightComponent extends BaseTableComponent implements OnInit {

  // признак загрузки списка групп пользователя
  private isRightLoading: boolean;
  // идентификатор выбранного права
  private selectedRightId: number;
  // список доступных прав пользователя
  private rightAvailableList: Right[];
  // список прав пользователя
  private rightList: Right[];
  // кнопки таблицы групп пользователя
  private rightTableButtons: any[] = _.cloneDeep(this.tableButtons);
  // опции модального окна добавления группы
  private rightModalDialogOptions: ProfileRightModalDialogOptions
    = new ProfileRightModalDialogOptions('Добавить права', 'Профильные права', 'RIGHTNAME', 'RIGHTSYSNAME');

  ngOnInit() {
    this.initTables();
    this.userAccountId$.first().subscribe(this.getRightListByAccountId);
  }

  /**
   * Инициализация таблицы Права
   */
  private initTables() {
    this.rightTableButtons[0].onClick = this.onClickAddRightToUser;
    this.rightTableButtons[1].onClick = this.removeUserRight;
    this.rightModalDialogOptions.onClickAddButton = this.onClickAddButton;
  }

  /**
   * Получение списка профильных прав пользователя
   * @param userAccountId {number} - идентификатор аккаунта пользователя
   * @param onSuccess {Function} - дополнительный обработчик успешного результата
   */
  getRightListByAccountId = (userAccountId: number, onSuccess?: Function) => {
    this.adminService.getRightListByAccountId(userAccountId)
      .map(rightList => this.rightList = rightList)
      .subscribe(onSuccess);
  }

  /**
   * Функция обработчик нажатия на кнопку добавления профильного права
   * @param selectedRightId {number} - идентификатор профильного права
   * @param department {any} - департамент на который назначаются права
   * @param modalForm {NgForm} - объект модальной формы добавления профильного права
   */
  onClickAddButton = (profileRightSysname: string, department: any, modalForm: NgForm) => {
    if (modalForm && modalForm.valid) {
      this.addRightToUser(profileRightSysname, department);
    }
  }

  /**
   * Добавление прав пользователю
   * @param selectedRightId {number} - идентификатор профильного права
   * @param department {any} - департамент на который назначаются права
   */
  addRightToUser = (selectedRightSysname: string, department: any) => {
    this.adminService.addRightToUser(this.userAccountId, selectedRightSysname, department)
      .subscribe(_ => this.getRightListByAccountId(this.userAccountId, () => this.addDialog.dialog.close()));
  }

  /**
   * Получение списка доступных прав по идентификатору аккаунта
   * @param userAccountId {number} - идентификатор аккаунта пользователя
   */
  getRightAvailableListByAccountId(userAccountId: number) {
    return this.adminService.getRightAvailableListByAccountId(userAccountId)
      .map((rightAvailableList: Right[]) => this.rightAvailableList = rightAvailableList).toPromise();
  }

  /**
   * Обработчик события нажатия на кнопку добавления профильного права пользователю
   */
  onClickAddRightToUser = async () => {
    this.addModalDialogOptions = this.rightModalDialogOptions;
    await this.getRightAvailableListByAccountId(this.userAccountId);
    if (this.rightAvailableList.length > 0) {
      this.rightModalDialogOptions.inputSelectItems = this.rightAvailableList;
      this.addDialog.dialog.show();
    } else {
      this.dialogService.alert('Отсутствуют доступные для добавления права.');
    }
  }

  /**
   * Удаление профильного права пользователя
   * @param selectedList {any[]} - список выбранных прав
   */
  removeUserRight = (selectedList: any[]) => {
    if (_.isArray(selectedList)) {
      try {
        const profileRight$: Array<Observable<any>> = selectedList.map((right: any) => this.adminService.removeUserRight(this.userAccountId, right.RIGHTID));
        Observable.forkJoin(...profileRight$)
          .first()
          .subscribe(() => this.getRightListByAccountId(this.userAccountId));
      } catch (e) {
        console.error('error in UserProfileRightComponent removeUserRight', e);
      }
    }
  }
}
