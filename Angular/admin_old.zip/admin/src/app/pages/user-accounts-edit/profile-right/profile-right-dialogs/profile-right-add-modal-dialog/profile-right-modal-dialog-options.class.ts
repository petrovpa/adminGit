import { Mappable } from '@app/services/common/src';

export class ProfileRightModalDialogOptions extends Mappable {
    private _modalDialogConfig: string;
    private _modalDialogTitle: string;
    private _inputSelectItems: any[];
    private _inputSelectNameField: string;
    private _inputSelectSysnameField: string;
    private _labelTitle: string;
    private _onClickAddButton: Function;

    constructor(
        modalDialogTitle: string = '',
        labelTitle: string = '',
        inputSelectNameField: string = '',
        inputSelectSysnameField: string = '',
        inputSelectItems: any[] = []) {

        super();
        this._inputSelectItems = inputSelectItems;
        this._modalDialogTitle = modalDialogTitle;
        this._labelTitle = labelTitle;
        this._inputSelectNameField = inputSelectNameField;
        this._inputSelectSysnameField = inputSelectSysnameField;
    }

    public get modalDialogConfig(): string {
        return this._modalDialogConfig;
    }

    public set modalDialogConfig(value: string) {
        this._modalDialogConfig = value;
    }

    public get modalDialogTitle(): string {
        return this._modalDialogTitle;
    }

    public get labelTitle(): string {
        return this._labelTitle;
    }

    public set labelTitle(value: string) {
        this._labelTitle = value;
    }

    public get onClickConfirmButton(): Function {
        return this._onClickAddButton;
    }

    public set onClickConfirmButton(value: Function) {
        this._onClickAddButton = value;
    }

    public get inputSelectItems(): any[] {
        return this._inputSelectItems;
    }

    public set inputSelectItems(value: any[]) {
        this._inputSelectItems = value;
    }

    public get onClickAddButton(): Function {
        return this._onClickAddButton;
    }

    public set onClickAddButton(value: Function) {
        this._onClickAddButton = value;
    }

    public get inputSelectNameField(): string {
        return this._inputSelectNameField;
    }

    public set inputSelectNameField(value: string) {
        this._inputSelectNameField = value;
    }

    public get inputSelectSysnameField(): string {
        return this._inputSelectSysnameField;
    }

    public set inputSelectSysnameField(value: string) {
        this._inputSelectSysnameField = value;
    }

}
