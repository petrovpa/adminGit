import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { ModalDialogComponent } from '@frontend/dialog-modal';
import { ProfileRightModalDialogOptions } from './profile-right-modal-dialog-options.class';
import * as _ from 'lodash';
import { RestApiService } from '@app/services/rest-api.service';
import { AngularTree } from '@app/classes/angular-tree.class';
import { Helper } from '@app/classes/helper.class';

@Component({
  selector: 'app-profile-right-add-modal-dialog',
  templateUrl: './profile-right-add-modal-dialog.component.html',
  styleUrls: ['./profile-right-add-modal-dialog.component.scss']
})
export class ProfileRightAddModalDialogComponent implements OnInit {

  @ViewChild('dialog') dialog: ModalDialogComponent;
  @Input() options: ProfileRightModalDialogOptions = new ProfileRightModalDialogOptions();

  private _selectedItemModel: any;
  public get selectedItemModel(): any {
    return this._selectedItemModel;
  }
  public set selectedItemModel(value: any) {
    this._selectedItemModel = value;
  }

  private _department: any;
  public get department(): any {
    return this._department;
  }
  public set department(value: any) {
    this._department = value;
  }

  private _departmentTree: AngularTree[];
  public get departmentTree(): AngularTree[] {
    return this._departmentTree;
  }
  public set departmentTree(value: AngularTree[]) {
    console.log('departmentTree ', value);
    this._departmentTree = value;
  }

  private _defaultOptionsMap = {
    modalDialogTitle: 'Добавить'
  };

  constructor(private adminService: RestApiService) {}

  ngOnInit() {
    this.getDepartmentTree();
    _.forIn(this._defaultOptionsMap, this.initOptionByDefault);
  }

  /**
   * Инициализация опции по умолчанию
   * @param value {any} - значение по умолчанию
   * @param option {string} - имя опции
   */
  private initOptionByDefault = (value: any, option: string) => {
    if (_.isUndefined(this.options[option])) {
      this.options[option] = value;
    }
  }

  /**
   * Получение дерева департаментов
   */
  private getDepartmentTree() {
    return this.adminService.getDepartmentTree()
      .subscribe(depTree => this.departmentTree = AngularTree.createNewArray(depTree));
  }

  /**
   * Обработчик выбора департамента
   * @param dep {any} - выбранный депертамент
   */
  private selectDepartment(dep: any) {
    this.department = dep;
  }

}
