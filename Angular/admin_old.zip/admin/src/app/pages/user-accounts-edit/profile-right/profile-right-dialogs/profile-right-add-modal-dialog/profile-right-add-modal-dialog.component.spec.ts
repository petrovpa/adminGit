import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfileRightAddModalDialogComponent } from './profile-right-add-modal-dialog.component';

describe('ProfileRightAddModalDialogComponent', () => {
  let component: ProfileRightAddModalDialogComponent;
  let fixture: ComponentFixture<ProfileRightAddModalDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfileRightAddModalDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfileRightAddModalDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
