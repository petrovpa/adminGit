import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserProfileRightComponent } from './profile-right.component';

describe('RightComponent', () => {
  let component: UserProfileRightComponent;
  let fixture: ComponentFixture<UserProfileRightComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserProfileRightComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserProfileRightComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
