import { Component, OnInit } from '@angular/core';
import { BaseTableComponent } from '@app/pages/user-accounts-edit/base-table/base-table.component';
import { Role } from '@app/classes/role.class';
import * as _ from 'lodash';
import { AddModalDialogOptions } from '@app/components/add-modal-dialog/add-modal-dailog-options.class';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/first';
import 'rxjs/add/observable/forkJoin';

@Component({
  selector: 'role',
  templateUrl: './role.component.html',
  styleUrls: ['./role.component.scss']
})
export class UserRoleComponent extends BaseTableComponent implements OnInit {

  // признак загрузки списка ролей пользователя
  private isRoleLoading: boolean;
  // идентификатор выбранной роли в модальном окне добавления роли
  private selectedRoleId: number;
  // список доступных ролей пользователя
  private roleAvailableList: Role[];
  // список ролей пользователя
  private roleList: Role[];
  // список всех ролей
  private roleListFull: Role[];
  // кнопки таблицы ролей пользователя
  private roleTableButtons: any[] = _.cloneDeep(this.tableButtons);

  // Обработчик события выбора записи из списка ролей пользователя
  private onRoleSelect(ev) {
  }

  // опции модального окна добавления роли
  private roleModalDialogOptions: AddModalDialogOptions = <AddModalDialogOptions>{
    modalDialogTitle: 'Добавить в роль',
    labelTitle: 'Роль',
    inputSelectNameField: 'ROLEVIEWNAME',
    inputSelectSysnameField: 'ROLEID'
  };

  ngOnInit() {
    this.initTable();
    this.userAccountId$.first().subscribe(this.getUserRoleListByUserAccountId);
  }

  /**
   * Инициализация таблиц Роли
   */
  private initTable() {
    this.roleTableButtons[0].onClick = this.onClickAddRoleToUser;
    this.roleTableButtons[1].onClick = this.removeUserRole;
    this.roleModalDialogOptions.onClickAddButton = this.addRoleToUser;
  }

  /**
   * Получение списка ролей пользователя
   * @param userAccountId {number} - идентификатор аккаунта пользователя
   */
  getUserRoleListByUserAccountId = (userAccountId: number) => {
    this.adminService.getUserRoleList(userAccountId).subscribe((roleList: Role[]) => this.roleList = roleList);
  };

  /**
   * Получение списка доступных ролей по идентификатору аккаунта
   * @param userAccountId {number} - идентификатор аккаунта пользователя
   */
  //getRoleAvailableListByAccountId(userAccountId: number) {
  //  return this.adminService.getRoleAvailableListByAccountId(userAccountId).map((roleAvailableList: Role[]) => this.roleAvailableList = roleAvailableList).toPromise();
  //}

  /**
   * Получение списка всех ролей
   */
  getRoleList(userAccountId: number) {
    return this.adminService.getRoleList(userAccountId)
      .map((roleListFull: Role[]) => this.roleListFull = roleListFull.map((role: Role) => {
        role.ROLEVIEWNAME = `${role.ROLENAME} (${role.ROLESYSNAME})`;
        return role;
      }))
      .toPromise();
  }

  /**
   * Добавление роли пользователю
   * @param selectedRoleId {number} - идентификатор добавляемой роли
   */
  addRoleToUser = (selectedRoleId: number) => {
    this.adminService.addRoleToUser(this.userAccountId, selectedRoleId)
      .subscribe(() => this.getUserRoleListByUserAccountId(this.userAccountId), this.addDialog.dialog.close());

  };

  /**
   * Обработчик события нажатия на кнопку добавления роли пользователю
   */
  onClickAddRoleToUser = async () => {
    this.addModalDialogOptions = this.roleModalDialogOptions;
    await this.getRoleList(this.userAccountId);
    if (this.roleListFull.length > 0) {
      this.roleModalDialogOptions.inputSelectItems = this.roleListFull;
      this.addDialog.dialog.show();
    } else {
      this.dialogService.alert('Отсутствуют доступные для добавления роли.');
    }
  };

  /**
   * Удаление роли пользователя
   * @param selectedList {any[]} - список выбранных ролей
   */
  removeUserRole = (selectedList: any[]) => {
    if (_.isArray(selectedList)) {
      try {
        // FIXME: доработать формирование списка потоков
        // вероятно в случае когда сервис не возвращает result (только status)
        // this.adminService.removeUserRole возвращает reject вместо resolve
        const roleList$: Array<Observable<any>> = selectedList.map((role: any) => this.adminService.removeUserRole(this.userAccountId, role.ROLEID));
        Observable.forkJoin(roleList$)
          .first()
          .subscribe(() => this.getUserRoleListByUserAccountId(this.userAccountId));
      } catch (e) {
        console.error('error in UserAccountsEditComponent removeUserRole', e);
      }
    }
  };
  /**
   * Удаление роли пользователя
   * @param selectedList {any[]} - список выбранных ролей
   */
  // removeUserRole = async (selectedList: any[]) => {
  //   if (_.isArray(selectedList)) {
  //     try {
  //       await selectedList.forEach(async (role: any) => {
  //         await this.adminService.removeUserRole(this.userAccountId, role.ROLEID).toPromise();
  //       });
  //       this.getUserRoleListByUserAccountId(this.userAccountId);
  //     } catch (e) {
  //       console.error('error in UserAccountsEditComponent removeUserRole', e);
  //     }
  //   }
  // }

}
