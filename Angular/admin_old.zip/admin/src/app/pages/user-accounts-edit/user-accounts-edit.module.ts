import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { FormControlModule } from '@app/components/form-control/src/form-control.module';
import { FormControlLabelModule } from '@frontend/form-control-label';
import { DatatableModule } from '@frontend/datatable';
import { DropdownListModule } from '@app/components/dropdown-list/dropdown-list.module';

import { UserMainComponent } from './user-main/user-main.component';
import { UserAccountsEditRoutingModule } from './user-accounts-edit-routing.module';
import { CustomButtonGroupModule } from '@app/components/custom-button-group/custom-button-group.module';
import { AddModalDialogModule } from '@app/components/add-modal-dialog/add-modal-dialog.module';
import { UserRoleComponent } from './role/role.component';
import { UserGroupComponent } from './group/group.component';
import { UserProfileRightComponent } from './profile-right/profile-right.component';
import { BaseUserAccountComponent } from './base/base.component';
import { BaseTableComponent } from './base-table/base-table.component';
import { UserAccountEditGuard } from './user-account-edit.guard';
import { ChangePasswordDialogModule } from '@app/components/change-password-modal-dialog/change-password-dialog.module';
import { ProfileRightDialogsModule } from '@app/pages/user-accounts-edit/profile-right/profile-right-dialogs/profile-right-dialogs.module';
import { ModalDialogGroupModule } from '@app/components/modal-dialog-group/modal-dialog-group.module';
import { SelectTreeModule } from '@app/components/select-tree/select-tree.module';
import { ActiveDirectoryComponent } from './active-directory/active-directory.component';

console.log('ACC EDIT bundle loaded asynchronously');

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    UserAccountsEditRoutingModule,
    FormControlModule,
    FormControlLabelModule,
    DatatableModule,
    DropdownListModule,
    CustomButtonGroupModule,
    AddModalDialogModule,
    ChangePasswordDialogModule,
    ProfileRightDialogsModule,
    ModalDialogGroupModule,
    SelectTreeModule
  ],
  declarations: [
    UserMainComponent,
    UserRoleComponent,
    UserGroupComponent,
    UserProfileRightComponent,
    BaseUserAccountComponent,
    BaseTableComponent,
    ActiveDirectoryComponent
  ],
  providers: [
    UserAccountEditGuard
  ]
})

export class UserAccountsEditModule { }
