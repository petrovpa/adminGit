import {Component, OnInit, ViewChild} from '@angular/core';
import {EventsService} from '@app/services/common/src';
import {NavigationStart, Router, NavigationExtras} from '@angular/router';
import {environment} from 'environments/environment';
import {User} from '@app/classes/user.class';
import {RestApiService} from "@app/services/rest-api.service";

const EDIT_USER_ROUTE = ['userAccountEdit', 'main'];

@Component({
  templateUrl: './user-accounts-journal.component.html',
  styleUrls: ['./user-accounts-journal.component.scss'],
  selector: 'user-accounts-journal',
})

export class UserAccountsJournalComponent {

  @ViewChild('journal') journal;

  private journalButtonsOnClick = {
    add: () => {
      console.log('EDIT_USER_ROUTE ', EDIT_USER_ROUTE);
      this.router.navigate([...EDIT_USER_ROUTE]);
    }
  };

  private journalCustomButtons = [
    {
      title: 'Блокировать',
      class: 'table-button__block',
      iClass: 'b2b-icon-block',
      sysname: 'block',
      onClick: (selected: any) => {
        let user: User;
        user = selected && selected[0];
        if (user) {
          const userAccountId = user.USERACCOUNTID;
          const userId = user.USERID;
          const status = 'BLOCKED';
          this.restService.updateAccountStatus(userAccountId, userId, status).subscribe((res: any) => {
            this.journal.getData();
          });
        }
      },
      disabled: (selected: any) => !(selected && selected[0] && selected[0].STATUS === 'ACTIVE')
    },
    {
      title: 'Разблокировать',
      class: 'table-button__unblock',
      iClass: 'b2b-icon-block-outline',
      sysname: 'unblock',
      onClick: (selected: any) => {
        let user: User;
        user = selected && selected[0];
        if (user){
          const userAccountId = user.USERACCOUNTID;
          const userId = user.USERID;
          const status = 'ACTIVE';
          this.restService.updateAccountStatus(userAccountId, userId, status).subscribe((res: any) => {
            this.journal.getData();
          });
        }
      },
      disabled: (selected: any) => {
        return !(selected && selected[0] && selected[0].STATUS === 'BLOCKED');
      }
    }
  ];

  constructor(private router: Router, private restService: RestApiService) {
  }

  /**
   * Переход на форму редактирования данных пользователя
   * @param user {User} - пользователь для редактирования
   */
  openUserAccount(user?: User) {
    const routeParams = [...EDIT_USER_ROUTE];
    if (user) {
      routeParams.push(user.USERACCOUNTID);
    }
    this.router.navigate(routeParams);
  }

}
