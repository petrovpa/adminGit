import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WelcomeComponent } from '@app/pages/welcome/welcome.component';
import { UserAccountsJournalComponent } from './user-accounts-journal/user-accounts-journal.component';

export const JOURNAL_ROUTES: Routes = [
  {
    path: '',
    component: UserAccountsJournalComponent,
    // pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forChild(JOURNAL_ROUTES)],
  exports: [RouterModule]
})
export class UserAccountsJournalRoutingModule { }
