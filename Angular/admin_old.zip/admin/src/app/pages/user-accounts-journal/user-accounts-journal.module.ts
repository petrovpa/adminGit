import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { UserAccountsJournalComponent } from './user-accounts-journal/user-accounts-journal.component';
import { UserAccountsJournalRoutingModule } from './user-accounts-journal-routing.module';
// FIXME: import from package
import { JournalModule } from '../../components/journal/src';

console.log('JOURNAL bundle loaded asynchronously');

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule,
    UserAccountsJournalRoutingModule,
    JournalModule
  ],
  declarations: [
    UserAccountsJournalComponent
  ]
})

export class UserAccountsJournalModule { }
