import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PasswordSettingsComponent } from './password-settings/password-settings.component';
import { FormsModule } from '@angular/forms';
import { PasswordSettingsService } from './password-settings.service';

import { FormControlModule } from '@app/components/form-control/src/form-control.module';
import { FormControlLabelModule } from '@frontend/form-control-label';
import { PasswordSettingsRoutingModule } from './password-settings-routing.module';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    FormControlModule,
    FormControlLabelModule,
    PasswordSettingsRoutingModule    
  ],
  providers: [
    PasswordSettingsService
  ],
  declarations: [PasswordSettingsComponent]
})
export class PasswordSettingsModule { }
