import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PasswordSettingsComponent } from './password-settings/password-settings.component';

const routes: Routes = [
    {
        path: '',
        component: PasswordSettingsComponent
      }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PasswordSettingsRoutingModule { }
