import { Component, OnInit } from '@angular/core';
import { PasswordSettingsService } from '../password-settings.service';
import { SettingsPassword } from '@app/classes/settings-password.class';
import { NgForm } from '@angular/forms';
import { ModalDialogService } from '@frontend/dialog-modal';
import { Router } from '@angular/router';

@Component({
  selector: 'app-password-settings',
  templateUrl: './password-settings.component.html',
  styleUrls: ['./password-settings.component.scss']
})
export class PasswordSettingsComponent implements OnInit {

  namespace: SettingsPassword = new SettingsPassword();

  wasValidated: boolean = false;

  constructor(private settingsService: PasswordSettingsService,
    private dialogService: ModalDialogService,
    private router: Router) { }

  ngOnInit() {
    this.settingsService.loadSettings().subscribe((res) => {
      if (!res) {
        //  this.showErrorDialog('Произошла ошибка сервиса');
      } else {
        if (res['Error']) {
          //this.showErrorDialog(res['Error']);
        } else {
          this.namespace = res;
        }
      }
    });
  }

  showErrorDialog(message) {
    this.dialogService.alert(message);
  }

  saveSettings(form: NgForm) {
    this.wasValidated = true;
    if (form.valid) {
      this.settingsService.saveSettings(this.namespace).subscribe((res) => {
        if (res && res['Error']) {
          //  this.showErrorDialog(res['Error']);
        } else {
          this.router.navigate(['']);
        }
      });
    } else {
      this.showErrorDialog('Проверьте введенные данные');
    }
  }

}
