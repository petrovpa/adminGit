import { NgModule, TemplateRef, isDevMode, LOCALE_ID } from '@angular/core';
import { JsonPipe, registerLocaleData } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule, PreloadAllModules } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoggerModule, Level } from '@frontend/logger';

// Cтили
import '../styles/styles.scss';

import { environment } from 'environments/environment';
import { MAIN_ROUTES } from './app.routes';

// Языковая поддержка
import localeRu from '@angular/common/locales/ru';

// Модули
import { Ng2Webstorage } from 'ngx-webstorage';
import { CommonServiceModule } from '@app/services/common/src';

// Компоненты
import { Page404Component } from './layouts/page404/page404.component';
import { AppComponent } from './app.component';
import { RestApiService } from '@app/services/rest-api.service';

registerLocaleData(localeRu);

type StoreType = {
  restoreInputValues: () => void,
  disposeOldHosts: () => void
};

@NgModule({
  bootstrap: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    LoggerModule.forRoot(environment.logLevel),
    CommonServiceModule.forRoot({
      restPath: environment.restPath,
      admRestPath: environment.restPath,
      showError: true
    }),
    Ng2Webstorage.forRoot({
      prefix: 'admin',
      separator: '.',
      caseSensitive: true
    }),
    RouterModule.forRoot(MAIN_ROUTES, {
      useHash: false,
      // будут медленные переходы между страницами - расскомментить!
      // TODO: добавить custom https://alligator.io/angular/preloading/ или показ загрузки
      preloadingStrategy: PreloadAllModules
    })
  ],
  declarations: [
    AppComponent,
    Page404Component,
  ],
  providers: [
    RestApiService,
    environment.ENV_PROVIDERS,
    {
      provide: LOCALE_ID,
      useValue: 'ru'
    },
    TemplateRef
  ]
})
export class AppModule {
}
