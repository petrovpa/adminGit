import { AfterContentInit, Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { Logger } from '@frontend/logger';

import 'rxjs/add/operator/filter';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/mergeMap';

@Component({
  selector: 'app',
  encapsulation: ViewEncapsulation.None,
  styleUrls: [
    './app.component.scss'
  ],
  templateUrl: './app.component.html'
})
export class AppComponent implements OnInit, AfterContentInit {
  public name = 'Angular Module';

  constructor(private activatedRoute: ActivatedRoute,
              private logger: Logger,
              private router: Router,
              private titleService: Title) {
  }

  ngOnInit() {
    this.router.events
      .filter((event) => event instanceof NavigationEnd)
      .map(() => this.activatedRoute)
      .map((route) => {
        while (route.firstChild) route = route.firstChild;
        return route;
      })
      .filter((route) => route.outlet === 'primary')
      .mergeMap((route) => route.data)
      .subscribe((event) => this.titleService.setTitle(event['title']));
  }

  ngAfterContentInit(): any {
    const getUrl = (router: Router) =>
      router.routerState.snapshot.url.slice(
        0,
        router.routerState.snapshot.url.indexOf('#')
      );

    let _prev = getUrl(this.router);
    const justDoIt = (event: any): void => {
      const _cur = getUrl(this.router);
      if (typeof PR !== 'undefined' && _prev !== _cur) {
        _prev = _cur;
        // google code-prettify
        PR.prettyPrint();
      }

      this.scrollTop();
    };

    this.router.events
      .filter(event => event instanceof NavigationEnd)
      .subscribe((event: any) => setTimeout(() => justDoIt(event), 50));
  }

  /**
   * Наверх страницы
   */
  scrollTop() {
    this.logger.info('Window scroll top');
    // FIXME: change to inject window
    window.scroll(0, 0);
  }
}
